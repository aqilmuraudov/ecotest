import { Product } from '../types';

// Ecolife.az saytından real kataloq (Kilo Code JSON export vasitəsilə çıxarılıb).
// Aşağıdakı sahələr avtomatik xam adlardan (name) çıxarılıb: güc (W), gərginlik (V),
// rəng temperaturu (K), IP dərəcəsi. Digər texniki spesifikasiyalar defolt dəyərlərlədir —
// admin paneldə hər məhsulu ayrıca redaktə edərək dəqiqləşdirmək olar.
export const ecolifeAllProducts: Product[] = [
  {
    "id": "6a266508fbd6aeb43d48b3ce",
    "slug": "6a266508fbd6aeb43d48b3ce",
    "name": "Magnetic Rail 3m 11mm",
    "code": "A0000012459",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1MZG9gJw_W_4rz1I7GmAxAe6DzF6EoHpS&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1MZG9gJw_W_4rz1I7GmAxAe6DzF6EoHpS&sz=w800"
    ],
    "description": {
      "az": "Magnetic Rail 3m 11mm — Ecolife | Kod: A0000012459",
      "en": "Magnetic Rail 3m 11mm — Ecolife | Code: A0000012459",
      "ru": "Magnetic Rail 3m 11mm — Ecolife | Код: A0000012459"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651895ae6ad287ef917c",
    "slug": "6a43651895ae6ad287ef917c",
    "name": "LED Driver 20W 85-265V for 3D",
    "code": "A0000012303",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "LED Driver 20W 85-265V for 3D — Ecolife | Kod: A0000012303",
      "en": "LED Driver 20W 85-265V for 3D — Ecolife | Code: A0000012303",
      "ru": "LED Driver 20W 85-265V for 3D — Ecolife | Код: A0000012303"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—",
      "power": "20W",
      "voltage": "265V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f93344a6fa762906b2490",
    "slug": "6a2f93344a6fa762906b2490",
    "name": "Flexstrip 220V 6000K 120L/M",
    "code": "A0000000374",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1UNhrk24xwX_JtqmVZ1n7hRgeImAiiaby&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1UNhrk24xwX_JtqmVZ1n7hRgeImAiiaby&sz=w800"
    ],
    "description": {
      "az": "Flexstrip 220V 6000K 120L/M — Ecolife | Kod: A0000000374",
      "en": "Flexstrip 220V 6000K 120L/M — Ecolife | Code: A0000000374",
      "ru": "Flexstrip 220V 6000K 120L/M — Ecolife | Код: A0000000374"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "cct": "6000K",
      "voltage": "220V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266500a32bf8c58755fcf1",
    "slug": "6a266500a32bf8c58755fcf1",
    "name": "Magnetic Tracklight Line D30 48V 20W 4000K 35mm",
    "code": "A0000001664",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1lUYWkApMqtVpJ5SwNPqMaSet4c1sRzeX&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1lUYWkApMqtVpJ5SwNPqMaSet4c1sRzeX&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight Line D30 48V 20W 4000K 35mm — Ecolife | Kod: A0000001664",
      "en": "Magnetic Tracklight Line D30 48V 20W 4000K 35mm — Ecolife | Code: A0000001664",
      "ru": "Magnetic Tracklight Line D30 48V 20W 4000K 35mm — Ecolife | Код: A0000001664"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "20W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664febac8158df6d99a94",
    "slug": "6a2664febac8158df6d99a94",
    "name": "Magnetic Acessuar",
    "code": "A0000001670",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1_Z2IHAMijMvktUyyrO35a1ewsJJzzHpd&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1_Z2IHAMijMvktUyyrO35a1ewsJJzzHpd&sz=w800"
    ],
    "description": {
      "az": "Magnetic Acessuar — Ecolife | Kod: A0000001670",
      "en": "Magnetic Acessuar — Ecolife | Code: A0000001670",
      "ru": "Magnetic Acessuar — Ecolife | Код: A0000001670"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a436518031a849a6400e450",
    "slug": "6a436518031a849a6400e450",
    "name": "1500 DRIVER 120W amper current IP67",
    "code": "A0000016586",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "1500 DRIVER 120W amper current IP67 — Ecolife | Kod: A0000016586",
      "en": "1500 DRIVER 120W amper current IP67 — Ecolife | Code: A0000016586",
      "ru": "1500 DRIVER 120W amper current IP67 — Ecolife | Код: A0000016586"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP67",
      "mounting": "—",
      "power": "120W"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651ab778008c7c94b6b8",
    "slug": "6a43651ab778008c7c94b6b8",
    "name": "DRIVER 12V 72W 6A IP21",
    "code": "A0000000560",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 12V 72W 6A IP21 — Ecolife | Kod: A0000000560",
      "en": "DRIVER 12V 72W 6A IP21 — Ecolife | Code: A0000000560",
      "ru": "DRIVER 12V 72W 6A IP21 — Ecolife | Код: A0000000560"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "72W",
      "voltage": "12V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe957bca684ccfe834905",
    "slug": "6a2fe957bca684ccfe834905",
    "name": "Downlight 3X10W 3500K Square White Grill",
    "code": "A0000012430",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1WJ0T9OktXRTx1in4tXpGGm_w4EoU6lfl&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1WJ0T9OktXRTx1in4tXpGGm_w4EoU6lfl&sz=w800"
    ],
    "description": {
      "az": "Downlight 3X10W 3500K Square White Grill — Ecolife | Kod: A0000012430",
      "en": "Downlight 3X10W 3500K Square White Grill — Ecolife | Code: A0000012430",
      "ru": "Downlight 3X10W 3500K Square White Grill — Ecolife | Код: A0000012430"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fb731fd604e1ab157f",
    "slug": "6a2664fb731fd604e1ab157f",
    "name": "Ultra Magnetic Tracklight Line D60 48V 24W 4000K 20mm",
    "code": "A0000001692",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1j_ocJlsOCy0eg-po5jeMGN9HqQC1DqtV&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1j_ocJlsOCy0eg-po5jeMGN9HqQC1DqtV&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic Tracklight Line D60 48V 24W 4000K 20mm — Ecolife | Kod: A0000001692",
      "en": "Ultra Magnetic Tracklight Line D60 48V 24W 4000K 20mm — Ecolife | Code: A0000001692",
      "ru": "Ultra Magnetic Tracklight Line D60 48V 24W 4000K 20mm — Ecolife | Код: A0000001692"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "24W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651ce85f4b5c1dd22123",
    "slug": "6a43651ce85f4b5c1dd22123",
    "name": "DRIVER 24V 60W 2,5A IP21",
    "code": "A0000011533",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 60W 2,5A IP21 — Ecolife | Kod: A0000011533",
      "en": "DRIVER 24V 60W 2,5A IP21 — Ecolife | Code: A0000011533",
      "ru": "DRIVER 24V 60W 2,5A IP21 — Ecolife | Код: A0000011533"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "60W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651ed3bbe95a64aaccce",
    "slug": "6a43651ed3bbe95a64aaccce",
    "name": "DRIVER 48V 150W 3,13A IP21 kod_048150/3,13A",
    "code": "A0000000595",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 48V 150W 3,13A IP21 kod_048150/3,13A — Ecolife | Kod: A0000000595",
      "en": "DRIVER 48V 150W 3,13A IP21 kod_048150/3,13A — Ecolife | Code: A0000000595",
      "ru": "DRIVER 48V 150W 3,13A IP21 kod_048150/3,13A — Ecolife | Код: A0000000595"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "150W",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651e2b2a47586ead7973",
    "slug": "6a43651e2b2a47586ead7973",
    "name": "DRIVER 48V 200W 4,17A IP21 kod_048200/4,17A",
    "code": "A0000000596",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 48V 200W 4,17A IP21 kod_048200/4,17A — Ecolife | Kod: A0000000596",
      "en": "DRIVER 48V 200W 4,17A IP21 kod_048200/4,17A — Ecolife | Code: A0000000596",
      "ru": "DRIVER 48V 200W 4,17A IP21 kod_048200/4,17A — Ecolife | Код: A0000000596"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "200W",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a4365166a146685b8e8223a",
    "slug": "6a4365166a146685b8e8223a",
    "name": "Dimmer 12/24 DC Air control",
    "code": "A0000000482",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "Dimmer 12/24 DC Air control — Ecolife | Kod: A0000000482",
      "en": "Dimmer 12/24 DC Air control — Ecolife | Code: A0000000482",
      "ru": "Dimmer 12/24 DC Air control — Ecolife | Код: A0000000482"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651b4a71c06ece0e9a98",
    "slug": "6a43651b4a71c06ece0e9a98",
    "name": "DRIVER 24V 48W 2A IP21",
    "code": "A0000011531",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 48W 2A IP21 — Ecolife | Kod: A0000011531",
      "en": "DRIVER 24V 48W 2A IP21 — Ecolife | Code: A0000011531",
      "ru": "DRIVER 24V 48W 2A IP21 — Ecolife | Код: A0000011531"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "48W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26651e7588ab8d95e62f4e",
    "slug": "6a26651e7588ab8d95e62f4e",
    "name": "Tracklight 50W 3000K B",
    "code": "A0000011573",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1NdXy2at60uzFWEERZPpSrupk8KQaJ2lc&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1NdXy2at60uzFWEERZPpSrupk8KQaJ2lc&sz=w800"
    ],
    "description": {
      "az": "Tracklight 50W 3000K B — Ecolife | Kod: A0000011573",
      "en": "Tracklight 50W 3000K B — Ecolife | Code: A0000011573",
      "ru": "Tracklight 50W 3000K B — Ecolife | Код: A0000011573"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "50W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651f1dd7dd00713a2690",
    "slug": "6a43651f1dd7dd00713a2690",
    "name": "DRIVER 250mA 18-36W COCO",
    "code": "A0000000463",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 250mA 18-36W COCO — Ecolife | Kod: A0000000463",
      "en": "DRIVER 250mA 18-36W COCO — Ecolife | Code: A0000000463",
      "ru": "DRIVER 250mA 18-36W COCO — Ecolife | Код: A0000000463"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—",
      "power": "36W"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af288e4890ae44f57d2",
    "slug": "6a265af288e4890ae44f57d2",
    "name": "Panel 18W 4000K Square White 3D",
    "code": "A0000001965",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1_VNXu55knZI9TKTJzYxvpbx8sS6tq_9Y&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1_VNXu55knZI9TKTJzYxvpbx8sS6tq_9Y&sz=w800"
    ],
    "description": {
      "az": "Panel 18W 4000K Square White 3D — Ecolife | Kod: A0000001965",
      "en": "Panel 18W 4000K Square White 3D — Ecolife | Code: A0000001965",
      "ru": "Panel 18W 4000K Square White 3D — Ecolife | Код: A0000001965"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "18W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a436516047bd21657b54761",
    "slug": "6a436516047bd21657b54761",
    "name": "Dimmer 12/24 DC",
    "code": "A0000000481",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "Dimmer 12/24 DC — Ecolife | Kod: A0000000481",
      "en": "Dimmer 12/24 DC — Ecolife | Code: A0000000481",
      "ru": "Dimmer 12/24 DC — Ecolife | Код: A0000000481"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a4365175858697ad9629233",
    "slug": "6a4365175858697ad9629233",
    "name": "Emergency Modul With Battery (Ecolife) 3,7V 3-50W",
    "code": "A0000000473",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "Emergency Modul With Battery (Ecolife) 3,7V 3-50W — Ecolife | Kod: A0000000473",
      "en": "Emergency Modul With Battery (Ecolife) 3,7V 3-50W — Ecolife | Code: A0000000473",
      "ru": "Emergency Modul With Battery (Ecolife) 3,7V 3-50W — Ecolife | Код: A0000000473"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—",
      "power": "50W",
      "voltage": "3,7V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266503cb6b89925b9b0337",
    "slug": "6a266503cb6b89925b9b0337",
    "name": "Magnetic TrackLight 20W 4000K Spot",
    "code": "A0000012476",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1CpQ7nHVyT1OjAl4OygcrTjhhXCH2wpH3&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1CpQ7nHVyT1OjAl4OygcrTjhhXCH2wpH3&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 20W 4000K Spot — Ecolife | Kod: A0000012476",
      "en": "Magnetic TrackLight 20W 4000K Spot — Ecolife | Code: A0000012476",
      "ru": "Magnetic TrackLight 20W 4000K Spot — Ecolife | Код: A0000012476"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "20W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe955c655f415d1346e4f",
    "slug": "6a2fe955c655f415d1346e4f",
    "name": "Downlight 07W 4000K COB",
    "code": "A0000015613",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=13m1Agk0QPUC7GzYAJCoHPNiniajKDk1o&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=13m1Agk0QPUC7GzYAJCoHPNiniajKDk1o&sz=w800"
    ],
    "description": {
      "az": "Downlight 07W 4000K COB — Ecolife | Kod: A0000015613",
      "en": "Downlight 07W 4000K COB — Ecolife | Code: A0000015613",
      "ru": "Downlight 07W 4000K COB — Ecolife | Код: A0000015613"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "07W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9ada129904ab2b8e0d1",
    "slug": "6a26b9ada129904ab2b8e0d1",
    "name": "LED Bulb 3500K 10W with driver",
    "code": "A0000011937",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1r6BHEUoLULZeOjQfs_F2wIb6UiCjP3gp&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1r6BHEUoLULZeOjQfs_F2wIb6UiCjP3gp&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 3500K 10W with driver — Ecolife | Kod: A0000011937",
      "en": "LED Bulb 3500K 10W with driver — Ecolife | Code: A0000011937",
      "ru": "LED Bulb 3500K 10W with driver — Ecolife | Код: A0000011937"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "10W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a4365183b334a7f097326a7",
    "slug": "6a4365183b334a7f097326a7",
    "name": "DRIVER for Panel 36-40W",
    "code": "A0000000468",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER for Panel 36-40W — Ecolife | Kod: A0000000468",
      "en": "DRIVER for Panel 36-40W — Ecolife | Code: A0000000468",
      "ru": "DRIVER for Panel 36-40W — Ecolife | Код: A0000000468"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—",
      "power": "40W"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26650a6b3485095a8d6657",
    "slug": "6a26650a6b3485095a8d6657",
    "name": "Magnetic Tracklight SR18 48V 20W 3500K 25mm Motion",
    "code": "A0000012362",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1-HBtmKNw9K6IpRC-MzV81q1ey_hWpe2e&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1-HBtmKNw9K6IpRC-MzV81q1ey_hWpe2e&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight SR18 48V 20W 3500K 25mm Motion — Ecolife | Kod: A0000012362",
      "en": "Magnetic Tracklight SR18 48V 20W 3500K 25mm Motion — Ecolife | Code: A0000012362",
      "ru": "Magnetic Tracklight SR18 48V 20W 3500K 25mm Motion — Ecolife | Код: A0000012362"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "20W",
      "cct": "3500K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266502ebe3cf169e5c2d95",
    "slug": "6a266502ebe3cf169e5c2d95",
    "name": "Magnetic TrackLight 12W 4000K D22 Motion",
    "code": "A0000012480",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1wtl3K9GXr_jPG_KEB3qIMYVwn8JIVajt&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1wtl3K9GXr_jPG_KEB3qIMYVwn8JIVajt&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 12W 4000K D22 Motion — Ecolife | Kod: A0000012480",
      "en": "Magnetic TrackLight 12W 4000K D22 Motion — Ecolife | Code: A0000012480",
      "ru": "Magnetic TrackLight 12W 4000K D22 Motion — Ecolife | Код: A0000012480"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "12W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266523c0821accf6e57050",
    "slug": "6a266523c0821accf6e57050",
    "name": "Tracklight Rail 3m B",
    "code": "A0000006913",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1JUwCV1bJMCCaJtqq_nkbT6wdcUY9lTBJ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1JUwCV1bJMCCaJtqq_nkbT6wdcUY9lTBJ&sz=w800"
    ],
    "description": {
      "az": "Tracklight Rail 3m B — Ecolife | Kod: A0000006913",
      "en": "Tracklight Rail 3m B — Ecolife | Code: A0000006913",
      "ru": "Tracklight Rail 3m B — Ecolife | Код: A0000006913"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9546e488fed7c46aaa1",
    "slug": "6a2fe9546e488fed7c46aaa1",
    "name": "Downlight 20W 3000K COB",
    "code": "A0000015629",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1kxE1t6o_I3IWJox905tMY5UQSHZ8mlcI&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1kxE1t6o_I3IWJox905tMY5UQSHZ8mlcI&sz=w800"
    ],
    "description": {
      "az": "Downlight 20W 3000K COB — Ecolife | Kod: A0000015629",
      "en": "Downlight 20W 3000K COB — Ecolife | Code: A0000015629",
      "ru": "Downlight 20W 3000K COB — Ecolife | Код: A0000015629"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "20W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94e1716b7af9528e363",
    "slug": "6a2fe94e1716b7af9528e363",
    "name": "Downlight 1xGU10 Round White Cylinder",
    "code": "A0000002276",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1Co-7cXoT6Eevv8HggKpnmpMKhv_rPxGK&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Co-7cXoT6Eevv8HggKpnmpMKhv_rPxGK&sz=w800"
    ],
    "description": {
      "az": "Downlight 1xGU10 Round White Cylinder — Ecolife | Kod: A0000002276",
      "en": "Downlight 1xGU10 Round White Cylinder — Ecolife | Code: A0000002276",
      "ru": "Downlight 1xGU10 Round White Cylinder — Ecolife | Код: A0000002276"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fbedbb6859b1e26168",
    "slug": "6a2664fbedbb6859b1e26168",
    "name": "Ultra Magnetic Tracklight SR18 48V 18W 4000K 20mm",
    "code": "A0000001690",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1W2kEzhflhKia8LjWkm5N7u4piMzC_xQq&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1W2kEzhflhKia8LjWkm5N7u4piMzC_xQq&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic Tracklight SR18 48V 18W 4000K 20mm — Ecolife | Kod: A0000001690",
      "en": "Ultra Magnetic Tracklight SR18 48V 18W 4000K 20mm — Ecolife | Code: A0000001690",
      "ru": "Ultra Magnetic Tracklight SR18 48V 18W 4000K 20mm — Ecolife | Код: A0000001690"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "18W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9aedcb68684a5c07052",
    "slug": "6a26b9aedcb68684a5c07052",
    "name": "SpotModul 8W 3000K for GU10",
    "code": "A0000012411",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1HKdeckeByXrwAPm5sVx5yHalu5LjoXiE&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1HKdeckeByXrwAPm5sVx5yHalu5LjoXiE&sz=w800"
    ],
    "description": {
      "az": "SpotModul 8W 3000K for GU10 — Ecolife | Kod: A0000012411",
      "en": "SpotModul 8W 3000K for GU10 — Ecolife | Code: A0000012411",
      "ru": "SpotModul 8W 3000K for GU10 — Ecolife | Код: A0000012411"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "8W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe957bf0ee419dba301f9",
    "slug": "6a2fe957bf0ee419dba301f9",
    "name": "Downlight 2X7W 3500K Square Black Grill",
    "code": "A0000012427",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1BHKfoyjkMZVhCI6FV5fqWKodxTolnopW&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1BHKfoyjkMZVhCI6FV5fqWKodxTolnopW&sz=w800"
    ],
    "description": {
      "az": "Downlight 2X7W 3500K Square Black Grill — Ecolife | Kod: A0000012427",
      "en": "Downlight 2X7W 3500K Square Black Grill — Ecolife | Code: A0000012427",
      "ru": "Downlight 2X7W 3500K Square Black Grill — Ecolife | Код: A0000012427"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fc17f2eaebbd4c940f",
    "slug": "6a2664fc17f2eaebbd4c940f",
    "name": "Ultra Magnetic Rail 20mm 2m",
    "code": "A0000001684",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1V4DRPaovNb1q6R0muUk1ASx0ZrLTR7cH&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1V4DRPaovNb1q6R0muUk1ASx0ZrLTR7cH&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic Rail 20mm 2m — Ecolife | Kod: A0000001684",
      "en": "Ultra Magnetic Rail 20mm 2m — Ecolife | Code: A0000001684",
      "ru": "Ultra Magnetic Rail 20mm 2m — Ecolife | Код: A0000001684"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aec6e535dbcaacaa9dc",
    "slug": "6a265aec6e535dbcaacaa9dc",
    "name": "Panel 18W 4000K Round White 3D",
    "code": "A0000001963",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1Rxa2JOegevFuYKMp95BbagvE34-Mnczn&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Rxa2JOegevFuYKMp95BbagvE34-Mnczn&sz=w800"
    ],
    "description": {
      "az": "Panel 18W 4000K Round White 3D — Ecolife | Kod: A0000001963",
      "en": "Panel 18W 4000K Round White 3D — Ecolife | Code: A0000001963",
      "ru": "Panel 18W 4000K Round White 3D — Ecolife | Код: A0000001963"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "18W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a4365198e89398298167e84",
    "slug": "6a4365198e89398298167e84",
    "name": "DRIVER 24V 150W IP67",
    "code": "A0000000569",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 150W IP67 — Ecolife | Kod: A0000000569",
      "en": "DRIVER 24V 150W IP67 — Ecolife | Code: A0000000569",
      "ru": "DRIVER 24V 150W IP67 — Ecolife | Код: A0000000569"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP67",
      "mounting": "—",
      "power": "150W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265fc9849f1e734885cd73",
    "slug": "6a265fc9849f1e734885cd73",
    "name": "LED Driver 36W 300Ma TINA 3D",
    "code": "A0000016455",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://drive.google.com/thumbnail?id=1Ri6afd9EtAug8kpqgxQjbwtRO2im7vHC&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Ri6afd9EtAug8kpqgxQjbwtRO2im7vHC&sz=w800"
    ],
    "description": {
      "az": "LED Driver 36W 300Ma TINA 3D — Ecolife | Kod: A0000016455",
      "en": "LED Driver 36W 300Ma TINA 3D — Ecolife | Code: A0000016455",
      "ru": "LED Driver 36W 300Ma TINA 3D — Ecolife | Код: A0000016455"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—",
      "power": "36W"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265fc96f5e4d4d9d4c82cd",
    "slug": "6a265fc96f5e4d4d9d4c82cd",
    "name": "ECL_WNG/A570",
    "code": "A0000000570",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://drive.google.com/thumbnail?id=1RlFQxs6kvg258FYM5fVmeq5u6f92ggrR&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1RlFQxs6kvg258FYM5fVmeq5u6f92ggrR&sz=w800"
    ],
    "description": {
      "az": "ECL_WNG/A570 — Ecolife | Kod: A0000000570",
      "en": "ECL_WNG/A570 — Ecolife | Code: A0000000570",
      "ru": "ECL_WNG/A570 — Ecolife | Код: A0000000570"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664ffc43ecd24f1d40e9d",
    "slug": "6a2664ffc43ecd24f1d40e9d",
    "name": "Magnetic PowerConnector Flexible",
    "code": "A0000001653",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1X0Uawzh9UIG4QSPGk2OzP6JH2EZ1jLtV&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1X0Uawzh9UIG4QSPGk2OzP6JH2EZ1jLtV&sz=w800"
    ],
    "description": {
      "az": "Magnetic PowerConnector Flexible — Ecolife | Kod: A0000001653",
      "en": "Magnetic PowerConnector Flexible — Ecolife | Code: A0000001653",
      "ru": "Magnetic PowerConnector Flexible — Ecolife | Код: A0000001653"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a22b2d4c2291691c676b3d1",
    "slug": "6a22b2d4c2291691c676b3d1",
    "name": "Magnetic Surface Acces Corner MZ20 90° 2Pin",
    "code": "A0000012470",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1nhCk1UJXCb3VMnyQb50e_0MCqksx4JSe&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1nhCk1UJXCb3VMnyQb50e_0MCqksx4JSe&sz=w800"
    ],
    "description": {
      "az": "Magnetic Surface Acces Corner MZ20 90° 2Pin — Ecolife | Kod: A0000012470",
      "en": "Magnetic Surface Acces Corner MZ20 90° 2Pin — Ecolife | Code: A0000012470",
      "ru": "Magnetic Surface Acces Corner MZ20 90° 2Pin — Ecolife | Код: A0000012470"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9af5c9626723fecff35",
    "slug": "6a26b9af5c9626723fecff35",
    "name": "LED Spotlamp 6000K 8W GU5.3",
    "code": "A0000002148",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1DIGXGU7pv0skFi8WepsIYTJ6vRWNSxjr&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1DIGXGU7pv0skFi8WepsIYTJ6vRWNSxjr&sz=w800"
    ],
    "description": {
      "az": "LED Spotlamp 6000K 8W GU5.3 — Ecolife | Kod: A0000002148",
      "en": "LED Spotlamp 6000K 8W GU5.3 — Ecolife | Code: A0000002148",
      "ru": "LED Spotlamp 6000K 8W GU5.3 — Ecolife | Код: A0000002148"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "8W",
      "cct": "6000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265fc84f14089b0e66290a",
    "slug": "6a265fc84f14089b0e66290a",
    "name": "ECL_WNG/A15826",
    "code": "A0000015826",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://drive.google.com/thumbnail?id=1haKrCoGECiERsukY3KPBX1R4mAJBq4kf&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1haKrCoGECiERsukY3KPBX1R4mAJBq4kf&sz=w800"
    ],
    "description": {
      "az": "ECL_WNG/A15826 — Ecolife | Kod: A0000015826",
      "en": "ECL_WNG/A15826 — Ecolife | Code: A0000015826",
      "ru": "ECL_WNG/A15826 — Ecolife | Код: A0000015826"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9537ea899353b8c456a",
    "slug": "6a2fe9537ea899353b8c456a",
    "name": "Downlight 30W 3000K COB",
    "code": "A0000015631",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1Ty9DcBFd7NdI-BD4rEe9NnmDqRV-aPmZ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Ty9DcBFd7NdI-BD4rEe9NnmDqRV-aPmZ&sz=w800"
    ],
    "description": {
      "az": "Downlight 30W 3000K COB — Ecolife | Kod: A0000015631",
      "en": "Downlight 30W 3000K COB — Ecolife | Code: A0000015631",
      "ru": "Downlight 30W 3000K COB — Ecolife | Код: A0000015631"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "30W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94ecc169e58f41f6dac",
    "slug": "6a2fe94ecc169e58f41f6dac",
    "name": "Downlight GU10 Round White",
    "code": "A0000002198",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1H_MyIs9DlkZDNs8DLfv0Rzrff9ZjNl14&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1H_MyIs9DlkZDNs8DLfv0Rzrff9ZjNl14&sz=w800"
    ],
    "description": {
      "az": "Downlight GU10 Round White — Ecolife | Kod: A0000002198",
      "en": "Downlight GU10 Round White — Ecolife | Code: A0000002198",
      "ru": "Downlight GU10 Round White — Ecolife | Код: A0000002198"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b1de2181ca74b3f886",
    "slug": "6a26b9b1de2181ca74b3f886",
    "name": "LED Bulb 160-240V 3000K E27 24W A70",
    "code": "A0000002047",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=11yWKxHLu-edPpJJT_c1_D24MLbHmC3Pv&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=11yWKxHLu-edPpJJT_c1_D24MLbHmC3Pv&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 3000K E27 24W A70 — Ecolife | Kod: A0000002047",
      "en": "LED Bulb 160-240V 3000K E27 24W A70 — Ecolife | Code: A0000002047",
      "ru": "LED Bulb 160-240V 3000K E27 24W A70 — Ecolife | Код: A0000002047"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "24W",
      "cct": "3000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9af5fd441619ea4e586",
    "slug": "6a26b9af5fd441619ea4e586",
    "name": "LED Par Bulb 4000K 35W E27 Black",
    "code": "A0000002124",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=16MM8-k5jGfPUbql9HAum19drT8nYbZ8K&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=16MM8-k5jGfPUbql9HAum19drT8nYbZ8K&sz=w800"
    ],
    "description": {
      "az": "LED Par Bulb 4000K 35W E27 Black — Ecolife | Kod: A0000002124",
      "en": "LED Par Bulb 4000K 35W E27 Black — Ecolife | Code: A0000002124",
      "ru": "LED Par Bulb 4000K 35W E27 Black — Ecolife | Код: A0000002124"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "35W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94b8b1a080f55d83d4e",
    "slug": "6a2fe94b8b1a080f55d83d4e",
    "name": "Downlight 30W 3500K COB",
    "code": "A0000012425",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1c1SXaoYb0_jMDs0DWJ3nzI466uW8d8yL&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1c1SXaoYb0_jMDs0DWJ3nzI466uW8d8yL&sz=w800"
    ],
    "description": {
      "az": "Downlight 30W 3500K COB — Ecolife | Kod: A0000012425",
      "en": "Downlight 30W 3500K COB — Ecolife | Code: A0000012425",
      "ru": "Downlight 30W 3500K COB — Ecolife | Код: A0000012425"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "30W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665064d8cac4345dd9f99",
    "slug": "6a2665064d8cac4345dd9f99",
    "name": "Magnetic Acces Input module 0.5m",
    "code": "A0000012464",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1n_XnYd9rhLuBsm-rlJ8_hlTa7AOKYS59&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1n_XnYd9rhLuBsm-rlJ8_hlTa7AOKYS59&sz=w800"
    ],
    "description": {
      "az": "Magnetic Acces Input module 0.5m — Ecolife | Kod: A0000012464",
      "en": "Magnetic Acces Input module 0.5m — Ecolife | Code: A0000012464",
      "ru": "Magnetic Acces Input module 0.5m — Ecolife | Код: A0000012464"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265fc93e806a50f96dcb76",
    "slug": "6a265fc93e806a50f96dcb76",
    "name": "ECL_WNG/A11541",
    "code": "A0000011541",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://drive.google.com/thumbnail?id=1q9d16AXxDekoaL0tKcOPoUantPcnndjB&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1q9d16AXxDekoaL0tKcOPoUantPcnndjB&sz=w800"
    ],
    "description": {
      "az": "ECL_WNG/A11541 — Ecolife | Kod: A0000011541",
      "en": "ECL_WNG/A11541 — Ecolife | Code: A0000011541",
      "ru": "ECL_WNG/A11541 — Ecolife | Код: A0000011541"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664ffa9f17fb2f9a08519",
    "slug": "6a2664ffa9f17fb2f9a08519",
    "name": "Magnetic Rail 35mm 3m",
    "code": "A0000001652",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1nOEz-6pi_3UtO_r4qhlyYXaYw6BqU69g&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1nOEz-6pi_3UtO_r4qhlyYXaYw6BqU69g&sz=w800"
    ],
    "description": {
      "az": "Magnetic Rail 35mm 3m — Ecolife | Kod: A0000001652",
      "en": "Magnetic Rail 35mm 3m — Ecolife | Code: A0000001652",
      "ru": "Magnetic Rail 35mm 3m — Ecolife | Код: A0000001652"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651d86f05682ea64a9b3",
    "slug": "6a43651d86f05682ea64a9b3",
    "name": "DRIVER 48V 250W 5,21A IP21 kod_048250/5,21A",
    "code": "A0000000597",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 48V 250W 5,21A IP21 kod_048250/5,21A — Ecolife | Kod: A0000000597",
      "en": "DRIVER 48V 250W 5,21A IP21 kod_048250/5,21A — Ecolife | Code: A0000000597",
      "ru": "DRIVER 48V 250W 5,21A IP21 kod_048250/5,21A — Ecolife | Код: A0000000597"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "250W",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266521e585f8fd2a159092",
    "slug": "6a266521e585f8fd2a159092",
    "name": "Tracklight 35W 3500K Black",
    "code": "A0000001501",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1plaQ96hkrNenfjlJxAVv7Ztg_861bzBy&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1plaQ96hkrNenfjlJxAVv7Ztg_861bzBy&sz=w800"
    ],
    "description": {
      "az": "Tracklight 35W 3500K Black — Ecolife | Kod: A0000001501",
      "en": "Tracklight 35W 3500K Black — Ecolife | Code: A0000001501",
      "ru": "Tracklight 35W 3500K Black — Ecolife | Код: A0000001501"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "35W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe958e1f36a2935850e20",
    "slug": "6a2fe958e1f36a2935850e20",
    "name": "Downlight 1x10W 3500K Square White Grill",
    "code": "A0000012429",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=16wr6HrDPZI7lerV4xMpVTcaEnmbUas2l&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=16wr6HrDPZI7lerV4xMpVTcaEnmbUas2l&sz=w800"
    ],
    "description": {
      "az": "Downlight 1x10W 3500K Square White Grill — Ecolife | Kod: A0000012429",
      "en": "Downlight 1x10W 3500K Square White Grill — Ecolife | Code: A0000012429",
      "ru": "Downlight 1x10W 3500K Square White Grill — Ecolife | Код: A0000012429"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af44b13dfd3637366f1",
    "slug": "6a265af44b13dfd3637366f1",
    "name": "Panel 24W 4000K Square White 3D",
    "code": "A0000001979",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=16LzgVm_mWVoSpsxClnjh79KbnpUjUleF&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=16LzgVm_mWVoSpsxClnjh79KbnpUjUleF&sz=w800"
    ],
    "description": {
      "az": "Panel 24W 4000K Square White 3D — Ecolife | Kod: A0000001979",
      "en": "Panel 24W 4000K Square White 3D — Ecolife | Code: A0000001979",
      "ru": "Panel 24W 4000K Square White 3D — Ecolife | Код: A0000001979"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "24W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664f907bac7a4781fe2d4",
    "slug": "6a2664f907bac7a4781fe2d4",
    "name": "Ultra Magnetic PowerConnector 180°",
    "code": "A0000001681",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=15itOAuWN-zHSrbfpIVfxMVVascC8WybI&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=15itOAuWN-zHSrbfpIVfxMVVascC8WybI&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic PowerConnector 180° — Ecolife | Kod: A0000001681",
      "en": "Ultra Magnetic PowerConnector 180° — Ecolife | Code: A0000001681",
      "ru": "Ultra Magnetic PowerConnector 180° — Ecolife | Код: A0000001681"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b540c1c51f3b21e396",
    "slug": "6a26b9b540c1c51f3b21e396",
    "name": "LED Spotlamp 6000K 6W GU10",
    "code": "A0000002144",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1r70rrYkQ5IV6zSDEUFcQF8id2azsOgIX&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1r70rrYkQ5IV6zSDEUFcQF8id2azsOgIX&sz=w800"
    ],
    "description": {
      "az": "LED Spotlamp 6000K 6W GU10 — Ecolife | Kod: A0000002144",
      "en": "LED Spotlamp 6000K 6W GU10 — Ecolife | Code: A0000002144",
      "ru": "LED Spotlamp 6000K 6W GU10 — Ecolife | Код: A0000002144"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "6W",
      "cct": "6000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266521d961ae59c31f3429",
    "slug": "6a266521d961ae59c31f3429",
    "name": "Tracklight 30W 4000K W Bridgelux",
    "code": "A0000011840",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1cW2gnzR5ddZcWoiCoDHDLmIeq6NuvQQV&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1cW2gnzR5ddZcWoiCoDHDLmIeq6NuvQQV&sz=w800"
    ],
    "description": {
      "az": "Tracklight 30W 4000K W Bridgelux — Ecolife | Kod: A0000011840",
      "en": "Tracklight 30W 4000K W Bridgelux — Ecolife | Code: A0000011840",
      "ru": "Tracklight 30W 4000K W Bridgelux — Ecolife | Код: A0000011840"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "30W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26650011555a187931947e",
    "slug": "6a26650011555a187931947e",
    "name": "Magnetic Tracklight Line D60 48V 30W 4000K 35mm",
    "code": "A0000001666",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1gXKpSk1bJA5Y_qv8HlhB6LXTKZrlwFuW&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1gXKpSk1bJA5Y_qv8HlhB6LXTKZrlwFuW&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight Line D60 48V 30W 4000K 35mm — Ecolife | Kod: A0000001666",
      "en": "Magnetic Tracklight Line D60 48V 30W 4000K 35mm — Ecolife | Code: A0000001666",
      "ru": "Magnetic Tracklight Line D60 48V 30W 4000K 35mm — Ecolife | Код: A0000001666"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "30W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aed5c8078b06469baaa",
    "slug": "6a265aed5c8078b06469baaa",
    "name": "Panel 15W 3000K Round Sidelit",
    "code": "A0000003052",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1stT7qJSYeO_TLwcg_e5FrunJGhi2hywL&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1stT7qJSYeO_TLwcg_e5FrunJGhi2hywL&sz=w800"
    ],
    "description": {
      "az": "Panel 15W 3000K Round Sidelit — Ecolife | Kod: A0000003052",
      "en": "Panel 15W 3000K Round Sidelit — Ecolife | Code: A0000003052",
      "ru": "Panel 15W 3000K Round Sidelit — Ecolife | Код: A0000003052"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "15W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266502ecd5093d66c75276",
    "slug": "6a266502ecd5093d66c75276",
    "name": "Magnetic TrackLight 18W 4000K D33 Motion",
    "code": "A0000012481",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1S5s2HONw3tXj0VvYBzLKAn8swKffK9Is&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1S5s2HONw3tXj0VvYBzLKAn8swKffK9Is&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 18W 4000K D33 Motion — Ecolife | Kod: A0000012481",
      "en": "Magnetic TrackLight 18W 4000K D33 Motion — Ecolife | Code: A0000012481",
      "ru": "Magnetic TrackLight 18W 4000K D33 Motion — Ecolife | Код: A0000012481"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "18W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f9338d9170f5f671e7865",
    "slug": "6a2f9338d9170f5f671e7865",
    "name": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K",
    "code": "A0000000406",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=18lXh9fCsZz0CF4NjJky_gkuSBicDsuKJ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=18lXh9fCsZz0CF4NjJky_gkuSBicDsuKJ&sz=w800"
    ],
    "description": {
      "az": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K — Ecolife | Kod: A0000000406",
      "en": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K — Ecolife | Code: A0000000406",
      "ru": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K — Ecolife | Код: A0000000406"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "10W",
      "cct": "6000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266509576d9a8cb9f79774",
    "slug": "6a266509576d9a8cb9f79774",
    "name": "Magnetic Tracklight Spot 48V 20W 3500K 25-35mm",
    "code": "A0000012366",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1BfSZBLpnAUBRCYBcNEd49KeXnKCmmRpC&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1BfSZBLpnAUBRCYBcNEd49KeXnKCmmRpC&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight Spot 48V 20W 3500K 25-35mm — Ecolife | Kod: A0000012366",
      "en": "Magnetic Tracklight Spot 48V 20W 3500K 25-35mm — Ecolife | Code: A0000012366",
      "ru": "Magnetic Tracklight Spot 48V 20W 3500K 25-35mm — Ecolife | Код: A0000012366"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "20W",
      "cct": "3500K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa733562e85bb9aa9b210",
    "slug": "6a2fa733562e85bb9aa9b210",
    "name": "12292 PCB SANAN 32W 4000K 1,5m 216 led 240Lum/W",
    "code": "A0000016342",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1pojoGIgdf-i5pz9fzlsr1azQLWBfvtN-&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1pojoGIgdf-i5pz9fzlsr1azQLWBfvtN-&sz=w800"
    ],
    "description": {
      "az": "12292 PCB SANAN 32W 4000K 1,5m 216 led 240Lum/W — Ecolife | Kod: A0000016342",
      "en": "12292 PCB SANAN 32W 4000K 1,5m 216 led 240Lum/W — Ecolife | Code: A0000016342",
      "ru": "12292 PCB SANAN 32W 4000K 1,5m 216 led 240Lum/W — Ecolife | Код: A0000016342"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "32W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26650588e15d866a774751",
    "slug": "6a26650588e15d866a774751",
    "name": "Magnetic TrackLight 24W 4000K D60",
    "code": "A0000012468",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1tTVYUMwEJnp9j-KA6cvKZvOfB3uxGVJQ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1tTVYUMwEJnp9j-KA6cvKZvOfB3uxGVJQ&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 24W 4000K D60 — Ecolife | Kod: A0000012468",
      "en": "Magnetic TrackLight 24W 4000K D60 — Ecolife | Code: A0000012468",
      "ru": "Magnetic TrackLight 24W 4000K D60 — Ecolife | Код: A0000012468"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "24W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933acc6ad9f93de35fc2",
    "slug": "6a2f933acc6ad9f93de35fc2",
    "name": "Flexstrip OSRAM 24V 24W 144chip 2line 15mm 5000K",
    "code": "A0000000422",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1weNIOrL523PQk1z6wl6mD0Pe3t4gG2eX&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1weNIOrL523PQk1z6wl6mD0Pe3t4gG2eX&sz=w800"
    ],
    "description": {
      "az": "Flexstrip OSRAM 24V 24W 144chip 2line 15mm 5000K — Ecolife | Kod: A0000000422",
      "en": "Flexstrip OSRAM 24V 24W 144chip 2line 15mm 5000K — Ecolife | Code: A0000000422",
      "ru": "Flexstrip OSRAM 24V 24W 144chip 2line 15mm 5000K — Ecolife | Код: A0000000422"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "24W",
      "cct": "5000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26650341711191a9486af8",
    "slug": "6a26650341711191a9486af8",
    "name": "Magnetic TrackLight 10W 4000K Spot",
    "code": "A0000012475",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1ApxH6vj7K7of1vkn5xrsytYkRy5s5vK6&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1ApxH6vj7K7of1vkn5xrsytYkRy5s5vK6&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 10W 4000K Spot — Ecolife | Kod: A0000012475",
      "en": "Magnetic TrackLight 10W 4000K Spot — Ecolife | Code: A0000012475",
      "ru": "Magnetic TrackLight 10W 4000K Spot — Ecolife | Код: A0000012475"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "10W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9577474798bdf251832",
    "slug": "6a2fe9577474798bdf251832",
    "name": "Downlight 3x10W 3500K Square Black Grill",
    "code": "A0000002357",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1hPWXA7G5BunGTwVK_p9djsfUnlr7CNMq&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1hPWXA7G5BunGTwVK_p9djsfUnlr7CNMq&sz=w800"
    ],
    "description": {
      "az": "Downlight 3x10W 3500K Square Black Grill — Ecolife | Kod: A0000002357",
      "en": "Downlight 3x10W 3500K Square Black Grill — Ecolife | Code: A0000002357",
      "ru": "Downlight 3x10W 3500K Square Black Grill — Ecolife | Код: A0000002357"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266504668bf1d5d076f3b0",
    "slug": "6a266504668bf1d5d076f3b0",
    "name": "Magnetic TrackLight 12W 4000K reflector",
    "code": "A0000012472",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1sOXlEuI5yBE6r6ypG9GcwVbvEQ6qcoR3&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1sOXlEuI5yBE6r6ypG9GcwVbvEQ6qcoR3&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 12W 4000K reflector — Ecolife | Kod: A0000012472",
      "en": "Magnetic TrackLight 12W 4000K reflector — Ecolife | Code: A0000012472",
      "ru": "Magnetic TrackLight 12W 4000K reflector — Ecolife | Код: A0000012472"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "12W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26651f08a9bd7103fefe00",
    "slug": "6a26651f08a9bd7103fefe00",
    "name": "Tracklight 300D 20W 4000K B",
    "code": "A0000001513",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1PfaMlfhJlCTPYrj2ZAqXhZ_1FLK5XxFG&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1PfaMlfhJlCTPYrj2ZAqXhZ_1FLK5XxFG&sz=w800"
    ],
    "description": {
      "az": "Tracklight 300D 20W 4000K B — Ecolife | Kod: A0000001513",
      "en": "Tracklight 300D 20W 4000K B — Ecolife | Code: A0000001513",
      "ru": "Tracklight 300D 20W 4000K B — Ecolife | Код: A0000001513"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "20W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af02cf9486ceb1992ac",
    "slug": "6a265af02cf9486ceb1992ac",
    "name": "Panel 22W 4000K Square White 3D Surface",
    "code": "A0000001901",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=17qiyaaG74G82PmGyQusN40TfvFYSTA8s&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=17qiyaaG74G82PmGyQusN40TfvFYSTA8s&sz=w800"
    ],
    "description": {
      "az": "Panel 22W 4000K Square White 3D Surface — Ecolife | Kod: A0000001901",
      "en": "Panel 22W 4000K Square White 3D Surface — Ecolife | Code: A0000001901",
      "ru": "Panel 22W 4000K Square White 3D Surface — Ecolife | Код: A0000001901"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "22W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651a6987181f4a0cf2db",
    "slug": "6a43651a6987181f4a0cf2db",
    "name": "DRIVER 12V 200W 16,67A IP21",
    "code": "A0000000559",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 12V 200W 16,67A IP21 — Ecolife | Kod: A0000000559",
      "en": "DRIVER 12V 200W 16,67A IP21 — Ecolife | Code: A0000000559",
      "ru": "DRIVER 12V 200W 16,67A IP21 — Ecolife | Код: A0000000559"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "200W",
      "voltage": "12V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9568a11e9dc93b251d5",
    "slug": "6a2fe9568a11e9dc93b251d5",
    "name": "Downlight 3x7W 3500K Square Black Grill",
    "code": "A0000012432",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1bzZuf5oN7jSp7ckbzcDvPuXhoAp7t2c-&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1bzZuf5oN7jSp7ckbzcDvPuXhoAp7t2c-&sz=w800"
    ],
    "description": {
      "az": "Downlight 3x7W 3500K Square Black Grill — Ecolife | Kod: A0000012432",
      "en": "Downlight 3x7W 3500K Square Black Grill — Ecolife | Code: A0000012432",
      "ru": "Downlight 3x7W 3500K Square Black Grill — Ecolife | Код: A0000012432"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94db1fa1f1a0b56afdc",
    "slug": "6a2fe94db1fa1f1a0b56afdc",
    "name": "Downlight 25W 3000K Round White Cylinder",
    "code": "A0000002419",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1XUMu0QNOzMXpO0oVW6SQU36i9q26GxYO&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1XUMu0QNOzMXpO0oVW6SQU36i9q26GxYO&sz=w800"
    ],
    "description": {
      "az": "Downlight 25W 3000K Round White Cylinder — Ecolife | Kod: A0000002419",
      "en": "Downlight 25W 3000K Round White Cylinder — Ecolife | Code: A0000002419",
      "ru": "Downlight 25W 3000K Round White Cylinder — Ecolife | Код: A0000002419"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "25W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665222abcfebb8eb5ab1a",
    "slug": "6a2665222abcfebb8eb5ab1a",
    "name": "Tracklight 10W 3500K W",
    "code": "A0000001499",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1g26iWXEF1NJnRQaLR_NJCc8b0ha1MisR&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1g26iWXEF1NJnRQaLR_NJCc8b0ha1MisR&sz=w800"
    ],
    "description": {
      "az": "Tracklight 10W 3500K W — Ecolife | Kod: A0000001499",
      "en": "Tracklight 10W 3500K W — Ecolife | Code: A0000001499",
      "ru": "Tracklight 10W 3500K W — Ecolife | Код: A0000001499"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "10W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94c9ca25110d98d56d7",
    "slug": "6a2fe94c9ca25110d98d56d7",
    "name": "Downlight 12W 3500K Round White Cylinder",
    "code": "A0000002412",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1Zu6wFYsv-gmv7z8DlyH0DtA1ek4g8FHZ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Zu6wFYsv-gmv7z8DlyH0DtA1ek4g8FHZ&sz=w800"
    ],
    "description": {
      "az": "Downlight 12W 3500K Round White Cylinder — Ecolife | Kod: A0000002412",
      "en": "Downlight 12W 3500K Round White Cylinder — Ecolife | Code: A0000002412",
      "ru": "Downlight 12W 3500K Round White Cylinder — Ecolife | Код: A0000002412"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "12W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe95426d679167830272e",
    "slug": "6a2fe95426d679167830272e",
    "name": "Downlight 20W 4000K COB",
    "code": "A0000015628",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1c8k8KkHTIqqfIR72ZXUrGwsgxmcH4Xs8&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1c8k8KkHTIqqfIR72ZXUrGwsgxmcH4Xs8&sz=w800"
    ],
    "description": {
      "az": "Downlight 20W 4000K COB — Ecolife | Kod: A0000015628",
      "en": "Downlight 20W 4000K COB — Ecolife | Code: A0000015628",
      "ru": "Downlight 20W 4000K COB — Ecolife | Код: A0000015628"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "20W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9ae2d4a533bfe084257",
    "slug": "6a26b9ae2d4a533bfe084257",
    "name": "SpotModul 8W 4000K for GU10",
    "code": "A0000012412",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1S9a71w8MwnVF1Mi3xFXkRDhDhz6wS_oZ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1S9a71w8MwnVF1Mi3xFXkRDhDhz6wS_oZ&sz=w800"
    ],
    "description": {
      "az": "SpotModul 8W 4000K for GU10 — Ecolife | Kod: A0000012412",
      "en": "SpotModul 8W 4000K for GU10 — Ecolife | Code: A0000012412",
      "ru": "SpotModul 8W 4000K for GU10 — Ecolife | Код: A0000012412"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "8W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651b342578a55b6c5f67",
    "slug": "6a43651b342578a55b6c5f67",
    "name": "DRIVER 24V 250W IP67",
    "code": "A0000011661",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 250W IP67 — Ecolife | Kod: A0000011661",
      "en": "DRIVER 24V 250W IP67 — Ecolife | Code: A0000011661",
      "ru": "DRIVER 24V 250W IP67 — Ecolife | Код: A0000011661"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP67",
      "mounting": "—",
      "power": "250W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266506ee0047139001ebf7",
    "slug": "6a266506ee0047139001ebf7",
    "name": "Magnetic TrackLight 12W 4000K D30 25mm",
    "code": "A0000012467",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1M0wWNcZZjTBxbEZG2W9IEbJHLUMRwTNJ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1M0wWNcZZjTBxbEZG2W9IEbJHLUMRwTNJ&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 12W 4000K D30 25mm — Ecolife | Kod: A0000012467",
      "en": "Magnetic TrackLight 12W 4000K D30 25mm — Ecolife | Code: A0000012467",
      "ru": "Magnetic TrackLight 12W 4000K D30 25mm — Ecolife | Код: A0000012467"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "12W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665009a9feb0880823b9c",
    "slug": "6a2665009a9feb0880823b9c",
    "name": "Magnetic Tracklight SR10 48V 20W 4000K 35mm",
    "code": "A0000001660",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1cOHkloi59Qi-1t1xe92ZPvvYQ5fSs_Is&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1cOHkloi59Qi-1t1xe92ZPvvYQ5fSs_Is&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight SR10 48V 20W 4000K 35mm — Ecolife | Kod: A0000001660",
      "en": "Magnetic Tracklight SR10 48V 20W 4000K 35mm — Ecolife | Code: A0000001660",
      "ru": "Magnetic Tracklight SR10 48V 20W 4000K 35mm — Ecolife | Код: A0000001660"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "20W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f9338afffadf70cc5fbe6",
    "slug": "6a2f9338afffadf70cc5fbe6",
    "name": "Flexstrip EPISTAR 24V 10W 336chip COB 5000K",
    "code": "A0000000410",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1LXCOQhJjKIfDOJeqppgtewVIBxnFKI5z&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1LXCOQhJjKIfDOJeqppgtewVIBxnFKI5z&sz=w800"
    ],
    "description": {
      "az": "Flexstrip EPISTAR 24V 10W 336chip COB 5000K — Ecolife | Kod: A0000000410",
      "en": "Flexstrip EPISTAR 24V 10W 336chip COB 5000K — Ecolife | Code: A0000000410",
      "ru": "Flexstrip EPISTAR 24V 10W 336chip COB 5000K — Ecolife | Код: A0000000410"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "10W",
      "cct": "5000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f9336acc0f37162cd46c1",
    "slug": "6a2f9336acc0f37162cd46c1",
    "name": "Flexstrip OSRAM 24V 24W 3500K 144chip 2line 15mm",
    "code": "A0000000420",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1Ipj24bFAbuF-h6SKYKxYXjIFslIQouxC&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Ipj24bFAbuF-h6SKYKxYXjIFslIQouxC&sz=w800"
    ],
    "description": {
      "az": "Flexstrip OSRAM 24V 24W 3500K 144chip 2line 15mm — Ecolife | Kod: A0000000420",
      "en": "Flexstrip OSRAM 24V 24W 3500K 144chip 2line 15mm — Ecolife | Code: A0000000420",
      "ru": "Flexstrip OSRAM 24V 24W 3500K 144chip 2line 15mm — Ecolife | Код: A0000000420"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "24W",
      "cct": "3500K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665016656b4c1257d5dde",
    "slug": "6a2665016656b4c1257d5dde",
    "name": "Magnetic Acces Corner TH20 90° 2Pin",
    "code": "A0000012491",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1PhZ0Q6u49pI20zAdGSanLh4TSqOP_CcD&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1PhZ0Q6u49pI20zAdGSanLh4TSqOP_CcD&sz=w800"
    ],
    "description": {
      "az": "Magnetic Acces Corner TH20 90° 2Pin — Ecolife | Kod: A0000012491",
      "en": "Magnetic Acces Corner TH20 90° 2Pin — Ecolife | Code: A0000012491",
      "ru": "Magnetic Acces Corner TH20 90° 2Pin — Ecolife | Код: A0000012491"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94cece38292b8ae192c",
    "slug": "6a2fe94cece38292b8ae192c",
    "name": "Downlight 12W 3500K Round Black Cylinder",
    "code": "A0000002411",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1bpxrGLnEUInhbzHOykCnm37ooWZr8K5m&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1bpxrGLnEUInhbzHOykCnm37ooWZr8K5m&sz=w800"
    ],
    "description": {
      "az": "Downlight 12W 3500K Round Black Cylinder — Ecolife | Kod: A0000002411",
      "en": "Downlight 12W 3500K Round Black Cylinder — Ecolife | Code: A0000002411",
      "ru": "Downlight 12W 3500K Round Black Cylinder — Ecolife | Код: A0000002411"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "12W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266503411c5e0405bf187d",
    "slug": "6a266503411c5e0405bf187d",
    "name": "Magnetic TrackLight 06W 4000K Reflector Motion",
    "code": "A0000012477",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1bwd-jTwyTRixb5lMiH9fzoK52Z8XyGjk&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1bwd-jTwyTRixb5lMiH9fzoK52Z8XyGjk&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 06W 4000K Reflector Motion — Ecolife | Kod: A0000012477",
      "en": "Magnetic TrackLight 06W 4000K Reflector Motion — Ecolife | Code: A0000012477",
      "ru": "Magnetic TrackLight 06W 4000K Reflector Motion — Ecolife | Код: A0000012477"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "06W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fa3f8e9f8120b77f9e",
    "slug": "6a2664fa3f8e9f8120b77f9e",
    "name": "Ultra Magnetic PowerConnector 90°",
    "code": "A0000001677",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1Jlui0iUCKP8ipYBWlIUqQ4hQ0ridqYlD&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Jlui0iUCKP8ipYBWlIUqQ4hQ0ridqYlD&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic PowerConnector 90° — Ecolife | Kod: A0000001677",
      "en": "Ultra Magnetic PowerConnector 90° — Ecolife | Code: A0000001677",
      "ru": "Ultra Magnetic PowerConnector 90° — Ecolife | Код: A0000001677"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa734be4d0c0d474b53ae",
    "slug": "6a2fa734be4d0c0d474b53ae",
    "name": "12291 PCB SANAN 22W 6500K 1,2m 144 led 160Lum/W",
    "code": "A0000015822",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1F8HnZizzYRgDy9oV5IH5gXENpRm-7uou&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1F8HnZizzYRgDy9oV5IH5gXENpRm-7uou&sz=w800"
    ],
    "description": {
      "az": "12291 PCB SANAN 22W 6500K 1,2m 144 led 160Lum/W — Ecolife | Kod: A0000015822",
      "en": "12291 PCB SANAN 22W 6500K 1,2m 144 led 160Lum/W — Ecolife | Code: A0000015822",
      "ru": "12291 PCB SANAN 22W 6500K 1,2m 144 led 160Lum/W — Ecolife | Код: A0000015822"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "22W",
      "cct": "6500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26650ba7691b7ffbe05ec0",
    "slug": "6a26650ba7691b7ffbe05ec0",
    "name": "Magnetic Tracklight Spot 48V 10W 3500K 25-35mm",
    "code": "A0000012358",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=145p5Se6oKZZL094ZQMUWrvH8s0CmO8yF&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=145p5Se6oKZZL094ZQMUWrvH8s0CmO8yF&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight Spot 48V 10W 3500K 25-35mm — Ecolife | Kod: A0000012358",
      "en": "Magnetic Tracklight Spot 48V 10W 3500K 25-35mm — Ecolife | Code: A0000012358",
      "ru": "Magnetic Tracklight Spot 48V 10W 3500K 25-35mm — Ecolife | Код: A0000012358"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "10W",
      "cct": "3500K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651f4703c927f7fa02fe",
    "slug": "6a43651f4703c927f7fa02fe",
    "name": "DRIVER 36W 24V IP54",
    "code": "A0000000537",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 36W 24V IP54 — Ecolife | Kod: A0000000537",
      "en": "DRIVER 36W 24V IP54 — Ecolife | Code: A0000000537",
      "ru": "DRIVER 36W 24V IP54 — Ecolife | Код: A0000000537"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP54",
      "mounting": "—",
      "power": "36W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9499546c21566d300b1",
    "slug": "6a2fe9499546c21566d300b1",
    "name": "Downlight 3x10W 3000K Square Black Grill",
    "code": "A0000002355",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=14-tC8X3m3bpfWMJNJ18zGtA2-wVzayP_&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=14-tC8X3m3bpfWMJNJ18zGtA2-wVzayP_&sz=w800"
    ],
    "description": {
      "az": "Downlight 3x10W 3000K Square Black Grill — Ecolife | Kod: A0000002355",
      "en": "Downlight 3x10W 3000K Square Black Grill — Ecolife | Code: A0000002355",
      "ru": "Downlight 3x10W 3000K Square Black Grill — Ecolife | Код: A0000002355"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe951038ddc3c6de469c9",
    "slug": "6a2fe951038ddc3c6de469c9",
    "name": "Downlight 2xGU10 Square White",
    "code": "A0000002273",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=106kGOaQHQ7ZFtipXZrONFZZJzTsJMq3w&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=106kGOaQHQ7ZFtipXZrONFZZJzTsJMq3w&sz=w800"
    ],
    "description": {
      "az": "Downlight 2xGU10 Square White — Ecolife | Kod: A0000002273",
      "en": "Downlight 2xGU10 Square White — Ecolife | Code: A0000002273",
      "ru": "Downlight 2xGU10 Square White — Ecolife | Код: A0000002273"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b567879b3864a2dd0c",
    "slug": "6a26b9b567879b3864a2dd0c",
    "name": "LED Bulb 160-240V 6000K E14 6.5W R50",
    "code": "A0000002067",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1jAypZ_qRegqsF2HiLaHbpO_UTML9bofp&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1jAypZ_qRegqsF2HiLaHbpO_UTML9bofp&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 6000K E14 6.5W R50 — Ecolife | Kod: A0000002067",
      "en": "LED Bulb 160-240V 6000K E14 6.5W R50 — Ecolife | Code: A0000002067",
      "ru": "LED Bulb 160-240V 6000K E14 6.5W R50 — Ecolife | Код: A0000002067"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "6.5W",
      "cct": "6000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a27ef1d7ed4d47c46eff095",
    "slug": "6a27ef1d7ed4d47c46eff095",
    "name": "Floodlight 300W 6500K 120lum/w PF>0.9 IP65",
    "code": "A0000012385",
    "category": "decorative",
    "categoryName": {
      "az": "Dekorativ",
      "en": "Decorative",
      "ru": "Декоративные"
    },
    "subtitle": {
      "az": "Dekorativ",
      "en": "Decorative",
      "ru": "Декоративные"
    },
    "image": "https://drive.google.com/thumbnail?id=1oHippRWJw7RdhPj5zDGltbdow0FOhZys&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1oHippRWJw7RdhPj5zDGltbdow0FOhZys&sz=w800"
    ],
    "description": {
      "az": "Floodlight 300W 6500K 120lum/w PF>0.9 IP65 — Ecolife | Kod: A0000012385",
      "en": "Floodlight 300W 6500K 120lum/w PF>0.9 IP65 — Ecolife | Code: A0000012385",
      "ru": "Floodlight 300W 6500K 120lum/w PF>0.9 IP65 — Ecolife | Код: A0000012385"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP65",
      "mounting": "Səthə / Asma",
      "power": "300W",
      "cct": "6500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94a1b3f67c30e9773d1",
    "slug": "6a2fe94a1b3f67c30e9773d1",
    "name": "Downlight 2x10W 3000K Square Black Grill",
    "code": "A0000002354",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1IzIhCT79p0i9udXeMfI2m4K1TIM3ML7H&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1IzIhCT79p0i9udXeMfI2m4K1TIM3ML7H&sz=w800"
    ],
    "description": {
      "az": "Downlight 2x10W 3000K Square Black Grill — Ecolife | Kod: A0000002354",
      "en": "Downlight 2x10W 3000K Square Black Grill — Ecolife | Code: A0000002354",
      "ru": "Downlight 2x10W 3000K Square Black Grill — Ecolife | Код: A0000002354"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b6bf434ac50f6e0d6b",
    "slug": "6a26b9b6bf434ac50f6e0d6b",
    "name": "LED Bulb 160-240V 4000K E27 6.5W Q45",
    "code": "A0000002060",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1RfL9OADxRsXt9QwW0x7ovNuxGNgkpka8&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1RfL9OADxRsXt9QwW0x7ovNuxGNgkpka8&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 4000K E27 6.5W Q45 — Ecolife | Kod: A0000002060",
      "en": "LED Bulb 160-240V 4000K E27 6.5W Q45 — Ecolife | Code: A0000002060",
      "ru": "LED Bulb 160-240V 4000K E27 6.5W Q45 — Ecolife | Код: A0000002060"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "6.5W",
      "cct": "4000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9af7b90bcb9bd5b1eac",
    "slug": "6a26b9af7b90bcb9bd5b1eac",
    "name": "Bulb GU10 9W 170-240V 3000K",
    "code": "A0000012382",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=12ZYhmPbHbG09OwTzGyaixi-3v8Uqnbto&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=12ZYhmPbHbG09OwTzGyaixi-3v8Uqnbto&sz=w800"
    ],
    "description": {
      "az": "Bulb GU10 9W 170-240V 3000K — Ecolife | Kod: A0000012382",
      "en": "Bulb GU10 9W 170-240V 3000K — Ecolife | Code: A0000012382",
      "ru": "Bulb GU10 9W 170-240V 3000K — Ecolife | Код: A0000012382"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "9W",
      "cct": "3000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94897c0db5aa151d27c",
    "slug": "6a2fe94897c0db5aa151d27c",
    "name": "Downlight 2X7W 3000K Square Black Grill",
    "code": "A0000002831",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1uDM7x87V5FNGOjP0Fi5-X1CkIGgIwEvi&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1uDM7x87V5FNGOjP0Fi5-X1CkIGgIwEvi&sz=w800"
    ],
    "description": {
      "az": "Downlight 2X7W 3000K Square Black Grill — Ecolife | Kod: A0000002831",
      "en": "Downlight 2X7W 3000K Square Black Grill — Ecolife | Code: A0000002831",
      "ru": "Downlight 2X7W 3000K Square Black Grill — Ecolife | Код: A0000002831"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fe2289d2b84b258b4b",
    "slug": "6a2664fe2289d2b84b258b4b",
    "name": "Magnetic Driver 48V 100W 35mm",
    "code": "A0000001672",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1sKLsIvHAjTYeoMZoIpeLATu4fN7iRnqu&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1sKLsIvHAjTYeoMZoIpeLATu4fN7iRnqu&sz=w800"
    ],
    "description": {
      "az": "Magnetic Driver 48V 100W 35mm — Ecolife | Kod: A0000001672",
      "en": "Magnetic Driver 48V 100W 35mm — Ecolife | Code: A0000001672",
      "ru": "Magnetic Driver 48V 100W 35mm — Ecolife | Код: A0000001672"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "100W",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fd6724452b0eba0e4b",
    "slug": "6a2664fd6724452b0eba0e4b",
    "name": "Magnetic Rail 25mm 3m",
    "code": "A0000001651",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=15isio7H76-IdHpdC7Cb5oHCzcTzVEiJ7&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=15isio7H76-IdHpdC7Cb5oHCzcTzVEiJ7&sz=w800"
    ],
    "description": {
      "az": "Magnetic Rail 25mm 3m — Ecolife | Kod: A0000001651",
      "en": "Magnetic Rail 25mm 3m — Ecolife | Code: A0000001651",
      "ru": "Magnetic Rail 25mm 3m — Ecolife | Код: A0000001651"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26652082d94ce35c5e04f0",
    "slug": "6a26652082d94ce35c5e04f0",
    "name": "Tracklight Body Jupiter B METAL and PLAST",
    "code": "A0000001568",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1axPSyY7T0qczGvSwWPnG-ahrZQ8hyOpm&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1axPSyY7T0qczGvSwWPnG-ahrZQ8hyOpm&sz=w800"
    ],
    "description": {
      "az": "Tracklight Body Jupiter B METAL and PLAST — Ecolife | Kod: A0000001568",
      "en": "Tracklight Body Jupiter B METAL and PLAST — Ecolife | Code: A0000001568",
      "ru": "Tracklight Body Jupiter B METAL and PLAST — Ecolife | Код: A0000001568"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af1f01844902c2ced8f",
    "slug": "6a265af1f01844902c2ced8f",
    "name": "Panel 36W 4000K Square White 3D",
    "code": "A0000001994",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1Q6L7RhaFKxc9xVxetUfqZYSAHJobTbIg&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Q6L7RhaFKxc9xVxetUfqZYSAHJobTbIg&sz=w800"
    ],
    "description": {
      "az": "Panel 36W 4000K Square White 3D — Ecolife | Kod: A0000001994",
      "en": "Panel 36W 4000K Square White 3D — Ecolife | Code: A0000001994",
      "ru": "Panel 36W 4000K Square White 3D — Ecolife | Код: A0000001994"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "36W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aef49b3eca2dc7b898f",
    "slug": "6a265aef49b3eca2dc7b898f",
    "name": "Panel 6W 3000K Round Sidelit",
    "code": "A0000001906",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1JDVWGObd1eA-z8xLEpmL34xLOfxNtMqI&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1JDVWGObd1eA-z8xLEpmL34xLOfxNtMqI&sz=w800"
    ],
    "description": {
      "az": "Panel 6W 3000K Round Sidelit — Ecolife | Kod: A0000001906",
      "en": "Panel 6W 3000K Round Sidelit — Ecolife | Code: A0000001906",
      "ru": "Panel 6W 3000K Round Sidelit — Ecolife | Код: A0000001906"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "6W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fb0f4b417846b92cfbb65",
    "slug": "6a2fb0f4b417846b92cfbb65",
    "name": "PCB SET 6 IN 1 AND DRIVER 55W 60sm 3000K",
    "code": "A0000000298",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1vNMTVmvTZfA6b4Z9WOyRbwp5GWofhdO4&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1vNMTVmvTZfA6b4Z9WOyRbwp5GWofhdO4&sz=w800"
    ],
    "description": {
      "az": "PCB SET 6 IN 1 AND DRIVER 55W 60sm 3000K — Ecolife | Kod: A0000000298",
      "en": "PCB SET 6 IN 1 AND DRIVER 55W 60sm 3000K — Ecolife | Code: A0000000298",
      "ru": "PCB SET 6 IN 1 AND DRIVER 55W 60sm 3000K — Ecolife | Код: A0000000298"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "55W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664f8c68b63376c20222b",
    "slug": "6a2664f8c68b63376c20222b",
    "name": "Magnetic Tracklight SR06 48V 6W 3000K 25mm Motion",
    "code": "A0000011637",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1KhhgkW1-6K0InihsL9LnI2dNCsytVEgB&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1KhhgkW1-6K0InihsL9LnI2dNCsytVEgB&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight SR06 48V 6W 3000K 25mm Motion — Ecolife | Kod: A0000011637",
      "en": "Magnetic Tracklight SR06 48V 6W 3000K 25mm Motion — Ecolife | Code: A0000011637",
      "ru": "Magnetic Tracklight SR06 48V 6W 3000K 25mm Motion — Ecolife | Код: A0000011637"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "6W",
      "cct": "3000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa737f88c2acefe2f4d7d",
    "slug": "6a2fa737f88c2acefe2f4d7d",
    "name": "PCB EPISTAR 110V 18W 96chip 6000K 112sm",
    "code": "A0000000439",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1-uJN3gSTU13n-fVYlQHR2EBmoSC-PCow&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1-uJN3gSTU13n-fVYlQHR2EBmoSC-PCow&sz=w800"
    ],
    "description": {
      "az": "PCB EPISTAR 110V 18W 96chip 6000K 112sm — Ecolife | Kod: A0000000439",
      "en": "PCB EPISTAR 110V 18W 96chip 6000K 112sm — Ecolife | Code: A0000000439",
      "ru": "PCB EPISTAR 110V 18W 96chip 6000K 112sm — Ecolife | Код: A0000000439"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "18W",
      "cct": "6000K",
      "voltage": "110V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651755ac76ee451f4e15",
    "slug": "6a43651755ac76ee451f4e15",
    "name": "Emergency Modul With Battery (Ecolife) 3,7V 3-50W DOB",
    "code": "A0000011956",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "Emergency Modul With Battery (Ecolife) 3,7V 3-50W DOB — Ecolife | Kod: A0000011956",
      "en": "Emergency Modul With Battery (Ecolife) 3,7V 3-50W DOB — Ecolife | Code: A0000011956",
      "ru": "Emergency Modul With Battery (Ecolife) 3,7V 3-50W DOB — Ecolife | Код: A0000011956"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—",
      "power": "50W",
      "voltage": "3,7V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266524b952ecb60110359b",
    "slug": "6a266524b952ecb60110359b",
    "name": "Tracklight Rail 1m W",
    "code": "A0000001605",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1_NmoPyLKemWKO9n6Mrdx_QE53Sfbbyv6&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1_NmoPyLKemWKO9n6Mrdx_QE53Sfbbyv6&sz=w800"
    ],
    "description": {
      "az": "Tracklight Rail 1m W — Ecolife | Kod: A0000001605",
      "en": "Tracklight Rail 1m W — Ecolife | Code: A0000001605",
      "ru": "Tracklight Rail 1m W — Ecolife | Код: A0000001605"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b481c1960e019d41bd",
    "slug": "6a26b9b481c1960e019d41bd",
    "name": "LED Spotlamp 6000K 6W GU10",
    "code": "A0000002145",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1cGH3GYXcckTyox6eNkF6zH2uhs6HkIP1&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1cGH3GYXcckTyox6eNkF6zH2uhs6HkIP1&sz=w800"
    ],
    "description": {
      "az": "LED Spotlamp 6000K 6W GU10 — Ecolife | Kod: A0000002145",
      "en": "LED Spotlamp 6000K 6W GU10 — Ecolife | Code: A0000002145",
      "ru": "LED Spotlamp 6000K 6W GU10 — Ecolife | Код: A0000002145"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "6W",
      "cct": "6000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aeff57ceae7ee9f9815",
    "slug": "6a265aeff57ceae7ee9f9815",
    "name": "Panel 22W 4000K Round White 3D Surface",
    "code": "A0000001900",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=130WB7orwiarMONK61x2LwSSshPxlD5Q5&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=130WB7orwiarMONK61x2LwSSshPxlD5Q5&sz=w800"
    ],
    "description": {
      "az": "Panel 22W 4000K Round White 3D Surface — Ecolife | Kod: A0000001900",
      "en": "Panel 22W 4000K Round White 3D Surface — Ecolife | Code: A0000001900",
      "ru": "Panel 22W 4000K Round White 3D Surface — Ecolife | Код: A0000001900"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "22W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af36a775ed1d4416bd8",
    "slug": "6a265af36a775ed1d4416bd8",
    "name": "Panel 48W 4000K Square White 3D Surface",
    "code": "A0000001904",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1CYBXN1PNEtqWXBkFF-wbDq5YLLPeIaW7&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1CYBXN1PNEtqWXBkFF-wbDq5YLLPeIaW7&sz=w800"
    ],
    "description": {
      "az": "Panel 48W 4000K Square White 3D Surface — Ecolife | Kod: A0000001904",
      "en": "Panel 48W 4000K Square White 3D Surface — Ecolife | Code: A0000001904",
      "ru": "Panel 48W 4000K Square White 3D Surface — Ecolife | Код: A0000001904"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "48W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9567299bd9226100db0",
    "slug": "6a2fe9567299bd9226100db0",
    "name": "Downlight 1x7W 3500K Round White Grill",
    "code": "A0000012428",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1j1x7Q_0aPR6vaTzOHkNLWdqXuz3AIv1J&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1j1x7Q_0aPR6vaTzOHkNLWdqXuz3AIv1J&sz=w800"
    ],
    "description": {
      "az": "Downlight 1x7W 3500K Round White Grill — Ecolife | Kod: A0000012428",
      "en": "Downlight 1x7W 3500K Round White Grill — Ecolife | Code: A0000012428",
      "ru": "Downlight 1x7W 3500K Round White Grill — Ecolife | Код: A0000012428"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a4365195de705243593706a",
    "slug": "6a4365195de705243593706a",
    "name": "DRIVER 24V 100W IP67",
    "code": "A0000000564",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 100W IP67 — Ecolife | Kod: A0000000564",
      "en": "DRIVER 24V 100W IP67 — Ecolife | Code: A0000000564",
      "ru": "DRIVER 24V 100W IP67 — Ecolife | Код: A0000000564"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP67",
      "mounting": "—",
      "power": "100W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933534d83e30487f2994",
    "slug": "6a2f933534d83e30487f2994",
    "name": "Flexstrip OSRAM 24V 28W 4000K 96 pcs 6m 15mm",
    "code": "A0000000425",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1kHX_PEjb6moFNyWAwex7IdEkAhJDQiP8&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1kHX_PEjb6moFNyWAwex7IdEkAhJDQiP8&sz=w800"
    ],
    "description": {
      "az": "Flexstrip OSRAM 24V 28W 4000K 96 pcs 6m 15mm — Ecolife | Kod: A0000000425",
      "en": "Flexstrip OSRAM 24V 28W 4000K 96 pcs 6m 15mm — Ecolife | Code: A0000000425",
      "ru": "Flexstrip OSRAM 24V 28W 4000K 96 pcs 6m 15mm — Ecolife | Код: A0000000425"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "28W",
      "cct": "4000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a27ef26e57ac834735bb924",
    "slug": "6a27ef26e57ac834735bb924",
    "name": "Solar Garden Light 1200lumen 3CCT",
    "code": "A0000012381",
    "category": "spot-downlight",
    "categoryName": {
      "az": "Spot & Downlight",
      "en": "Spot & Downlight",
      "ru": "Споты и даунлайты"
    },
    "subtitle": {
      "az": "Spot & Downlight",
      "en": "Spot & Downlight",
      "ru": "Споты и даунлайты"
    },
    "image": "https://drive.google.com/thumbnail?id=1PjmfCz9b7MGJWxiuUwDrcV7PcOtbuDtw&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1PjmfCz9b7MGJWxiuUwDrcV7PcOtbuDtw&sz=w800"
    ],
    "description": {
      "az": "Solar Garden Light 1200lumen 3CCT — Ecolife | Kod: A0000012381",
      "en": "Solar Garden Light 1200lumen 3CCT — Ecolife | Code: A0000012381",
      "ru": "Solar Garden Light 1200lumen 3CCT — Ecolife | Код: A0000012381"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə / Səthə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fa9fc41cbcb1687439",
    "slug": "6a2664fa9fc41cbcb1687439",
    "name": "Ultra Magnetic Tracklight SR6 48V 6W 4000K 20mm",
    "code": "A0000001687",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1WL-dYfGy_BE82ZSnSGLL1Zv79OcSxYen&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1WL-dYfGy_BE82ZSnSGLL1Zv79OcSxYen&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic Tracklight SR6 48V 6W 4000K 20mm — Ecolife | Kod: A0000001687",
      "en": "Ultra Magnetic Tracklight SR6 48V 6W 4000K 20mm — Ecolife | Code: A0000001687",
      "ru": "Ultra Magnetic Tracklight SR6 48V 6W 4000K 20mm — Ecolife | Код: A0000001687"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "6W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94563e695b495597be4",
    "slug": "6a2fe94563e695b495597be4",
    "name": "Underground Downlight 3W 3000K IP65",
    "code": "A0000003182",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1W4up9fw_ahrT1NOeosWi-3sbzxfeLf45&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1W4up9fw_ahrT1NOeosWi-3sbzxfeLf45&sz=w800"
    ],
    "description": {
      "az": "Underground Downlight 3W 3000K IP65 — Ecolife | Kod: A0000003182",
      "en": "Underground Downlight 3W 3000K IP65 — Ecolife | Code: A0000003182",
      "ru": "Underground Downlight 3W 3000K IP65 — Ecolife | Код: A0000003182"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP65",
      "mounting": "Trek relsi üzərində",
      "power": "3W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26651f673d3928cec7d1ca",
    "slug": "6a26651f673d3928cec7d1ca",
    "name": "Tracklight 8x3W 4000K B Motion",
    "code": "A0000001518",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=16J4ZNQGxW6K61h7bdDdfIxsnnIbIInW7&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=16J4ZNQGxW6K61h7bdDdfIxsnnIbIInW7&sz=w800"
    ],
    "description": {
      "az": "Tracklight 8x3W 4000K B Motion — Ecolife | Kod: A0000001518",
      "en": "Tracklight 8x3W 4000K B Motion — Ecolife | Code: A0000001518",
      "ru": "Tracklight 8x3W 4000K B Motion — Ecolife | Код: A0000001518"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "3W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94f491b9eec82d6ea2f",
    "slug": "6a2fe94f491b9eec82d6ea2f",
    "name": "Downlight 1xGU10 Round Black",
    "code": "A0000002262",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1aEtOrCWUWi0GoMdaD7jJJ6rAC5FcFm7w&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1aEtOrCWUWi0GoMdaD7jJJ6rAC5FcFm7w&sz=w800"
    ],
    "description": {
      "az": "Downlight 1xGU10 Round Black — Ecolife | Kod: A0000002262",
      "en": "Downlight 1xGU10 Round Black — Ecolife | Code: A0000002262",
      "ru": "Downlight 1xGU10 Round Black — Ecolife | Код: A0000002262"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651a01812853e3ff55f8",
    "slug": "6a43651a01812853e3ff55f8",
    "name": "DRIVER 12V 120W 10A IP21",
    "code": "A0000000558",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 12V 120W 10A IP21 — Ecolife | Kod: A0000000558",
      "en": "DRIVER 12V 120W 10A IP21 — Ecolife | Code: A0000000558",
      "ru": "DRIVER 12V 120W 10A IP21 — Ecolife | Код: A0000000558"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "120W",
      "voltage": "12V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af14914740b4b822882",
    "slug": "6a265af14914740b4b822882",
    "name": "Panel 15W 4000K Round White Sidelit",
    "code": "A0000003053",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1_PWee7Q_uI8AEKnF8UqXvbdsFaKLk1LM&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1_PWee7Q_uI8AEKnF8UqXvbdsFaKLk1LM&sz=w800"
    ],
    "description": {
      "az": "Panel 15W 4000K Round White Sidelit — Ecolife | Kod: A0000003053",
      "en": "Panel 15W 4000K Round White Sidelit — Ecolife | Code: A0000003053",
      "ru": "Panel 15W 4000K Round White Sidelit — Ecolife | Код: A0000003053"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "15W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266507fae3a50b8f691753",
    "slug": "6a266507fae3a50b8f691753",
    "name": "Magnetic Acces Tros",
    "code": "A0000012461",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1MtM1-7e5hfdFsUxCXLmH25DfRdiHjj_L&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1MtM1-7e5hfdFsUxCXLmH25DfRdiHjj_L&sz=w800"
    ],
    "description": {
      "az": "Magnetic Acces Tros — Ecolife | Kod: A0000012461",
      "en": "Magnetic Acces Tros — Ecolife | Code: A0000012461",
      "ru": "Magnetic Acces Tros — Ecolife | Код: A0000012461"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9479546c21566d300ae",
    "slug": "6a2fe9479546c21566d300ae",
    "name": "Downlight 2X7W 3000K Square White Grill",
    "code": "A0000002835",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1ekRTzrzlzZUXhxFQE4v1Js93QHirEe26&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1ekRTzrzlzZUXhxFQE4v1Js93QHirEe26&sz=w800"
    ],
    "description": {
      "az": "Downlight 2X7W 3000K Square White Grill — Ecolife | Kod: A0000002835",
      "en": "Downlight 2X7W 3000K Square White Grill — Ecolife | Code: A0000002835",
      "ru": "Downlight 2X7W 3000K Square White Grill — Ecolife | Код: A0000002835"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664f8570c40fb67c59102",
    "slug": "6a2664f8570c40fb67c59102",
    "name": "Ultra Magnetic Driver 48V 200W mm",
    "code": "A0000001694",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1z4skbN-xX9iRk2pZyq-uJ2vUvv3BfWjS&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1z4skbN-xX9iRk2pZyq-uJ2vUvv3BfWjS&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic Driver 48V 200W mm — Ecolife | Kod: A0000001694",
      "en": "Ultra Magnetic Driver 48V 200W mm — Ecolife | Code: A0000001694",
      "ru": "Ultra Magnetic Driver 48V 200W mm — Ecolife | Код: A0000001694"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "200W",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa7351f564d51925b4d32",
    "slug": "6a2fa7351f564d51925b4d32",
    "name": "PCB OSRAM 24V 60W 40*1.5M 4000K 96 pcs 20mm",
    "code": "A0000011946",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1LCUgzexnVQAOyH7yvcykHfQjLspFwfcT&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1LCUgzexnVQAOyH7yvcykHfQjLspFwfcT&sz=w800"
    ],
    "description": {
      "az": "PCB OSRAM 24V 60W 40*1.5M 4000K 96 pcs 20mm — Ecolife | Kod: A0000011946",
      "en": "PCB OSRAM 24V 60W 40*1.5M 4000K 96 pcs 20mm — Ecolife | Code: A0000011946",
      "ru": "PCB OSRAM 24V 60W 40*1.5M 4000K 96 pcs 20mm — Ecolife | Код: A0000011946"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "60W",
      "cct": "4000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b0fba6bd47c74c9b95",
    "slug": "6a26b9b0fba6bd47c74c9b95",
    "name": "LED Candle 160-240V 3000K E14 9W C37",
    "code": "A0000002103",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1L6E8bBwzerwubu3wbBHW4lCL4vp69vC-&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1L6E8bBwzerwubu3wbBHW4lCL4vp69vC-&sz=w800"
    ],
    "description": {
      "az": "LED Candle 160-240V 3000K E14 9W C37 — Ecolife | Kod: A0000002103",
      "en": "LED Candle 160-240V 3000K E14 9W C37 — Ecolife | Code: A0000002103",
      "ru": "LED Candle 160-240V 3000K E14 9W C37 — Ecolife | Код: A0000002103"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "9W",
      "cct": "3000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266501085db9f59887ba92",
    "slug": "6a266501085db9f59887ba92",
    "name": "Magnetic TrackLight 40W 4000K D120",
    "code": "A0000012490",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=12q49CY124WqylEeTASKNEI3M5hu_MfMZ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=12q49CY124WqylEeTASKNEI3M5hu_MfMZ&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 40W 4000K D120 — Ecolife | Kod: A0000012490",
      "en": "Magnetic TrackLight 40W 4000K D120 — Ecolife | Code: A0000012490",
      "ru": "Magnetic TrackLight 40W 4000K D120 — Ecolife | Код: A0000012490"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "40W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26652043202dbbff2cb4c9",
    "slug": "6a26652043202dbbff2cb4c9",
    "name": "Tracklight 40W 4000K B CRI>90",
    "code": "A0000001508",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1YstTzqZYaSCvGTKZVFumyKSQFr9xa3-2&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1YstTzqZYaSCvGTKZVFumyKSQFr9xa3-2&sz=w800"
    ],
    "description": {
      "az": "Tracklight 40W 4000K B CRI>90 — Ecolife | Kod: A0000001508",
      "en": "Tracklight 40W 4000K B CRI>90 — Ecolife | Code: A0000001508",
      "ru": "Tracklight 40W 4000K B CRI>90 — Ecolife | Код: A0000001508"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "40W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af28b26aa32c55c4cc0",
    "slug": "6a265af28b26aa32c55c4cc0",
    "name": "Panel 60W 3000K 600x6000 Backlit",
    "code": "A0000016393",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1UHf0yRqzVcP7E6KZJ1Lzo_qOO5cXA443&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1UHf0yRqzVcP7E6KZJ1Lzo_qOO5cXA443&sz=w800"
    ],
    "description": {
      "az": "Panel 60W 3000K 600x6000 Backlit — Ecolife | Kod: A0000016393",
      "en": "Panel 60W 3000K 600x6000 Backlit — Ecolife | Code: A0000016393",
      "ru": "Panel 60W 3000K 600x6000 Backlit — Ecolife | Код: A0000016393"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "60W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe946082c015c40b2122d",
    "slug": "6a2fe946082c015c40b2122d",
    "name": "Downlight 1x7W 3000K Square White Grill",
    "code": "A0000002838",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1UK6Nj1STRk8QZtuJvpdE97q76UjQKXmB&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1UK6Nj1STRk8QZtuJvpdE97q76UjQKXmB&sz=w800"
    ],
    "description": {
      "az": "Downlight 1x7W 3000K Square White Grill — Ecolife | Kod: A0000002838",
      "en": "Downlight 1x7W 3000K Square White Grill — Ecolife | Code: A0000002838",
      "ru": "Downlight 1x7W 3000K Square White Grill — Ecolife | Код: A0000002838"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665090de0cf9fccf15ea1",
    "slug": "6a2665090de0cf9fccf15ea1",
    "name": "Magnetic Tracklight Line D120 48V 40W 3500K 25mm",
    "code": "A0000012363",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1y3OjN3P2ic6sqvUo8Df4UfpCaDS0yPiw&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1y3OjN3P2ic6sqvUo8Df4UfpCaDS0yPiw&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight Line D120 48V 40W 3500K 25mm — Ecolife | Kod: A0000012363",
      "en": "Magnetic Tracklight Line D120 48V 40W 3500K 25mm — Ecolife | Code: A0000012363",
      "ru": "Magnetic Tracklight Line D120 48V 40W 3500K 25mm — Ecolife | Код: A0000012363"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "40W",
      "cct": "3500K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b2bbb77d00a35916e7",
    "slug": "6a26b9b2bbb77d00a35916e7",
    "name": "LED Bulb 160-240V 4000K E27 8W Q45 ECO",
    "code": "A0000002062",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1yZr1MW5fMa9trWN_Suz_EMz-QzNoKcNc&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1yZr1MW5fMa9trWN_Suz_EMz-QzNoKcNc&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 4000K E27 8W Q45 ECO — Ecolife | Kod: A0000002062",
      "en": "LED Bulb 160-240V 4000K E27 8W Q45 ECO — Ecolife | Code: A0000002062",
      "ru": "LED Bulb 160-240V 4000K E27 8W Q45 ECO — Ecolife | Код: A0000002062"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "8W",
      "cct": "4000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa735b3a7110784b0debc",
    "slug": "6a2fa735b3a7110784b0debc",
    "name": "12291 PCB SANAN 22W 4000K 1,2m 144 led 240Lum/W",
    "code": "A0000015819",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1nx6lmSwPK9B3982_kwSvkbeYbHmXLNuH&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1nx6lmSwPK9B3982_kwSvkbeYbHmXLNuH&sz=w800"
    ],
    "description": {
      "az": "12291 PCB SANAN 22W 4000K 1,2m 144 led 240Lum/W — Ecolife | Kod: A0000015819",
      "en": "12291 PCB SANAN 22W 4000K 1,2m 144 led 240Lum/W — Ecolife | Code: A0000015819",
      "ru": "12291 PCB SANAN 22W 4000K 1,2m 144 led 240Lum/W — Ecolife | Код: A0000015819"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "22W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af416014e6e7cbe71b2",
    "slug": "6a265af416014e6e7cbe71b2",
    "name": "Panel 36W 4000K Round White 3D",
    "code": "A0000001992",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1BP9MP-gHO4uU0bYLxzVoCGpheblchceN&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1BP9MP-gHO4uU0bYLxzVoCGpheblchceN&sz=w800"
    ],
    "description": {
      "az": "Panel 36W 4000K Round White 3D — Ecolife | Kod: A0000001992",
      "en": "Panel 36W 4000K Round White 3D — Ecolife | Code: A0000001992",
      "ru": "Panel 36W 4000K Round White 3D — Ecolife | Код: A0000001992"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "36W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe958e298b14301ef1dd6",
    "slug": "6a2fe958e298b14301ef1dd6",
    "name": "Downlight 1x10W 3500K Square Black Grill",
    "code": "A0000012438",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1JWRFzXzlkdvjahbU1YrTjZAvR-uahZbZ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1JWRFzXzlkdvjahbU1YrTjZAvR-uahZbZ&sz=w800"
    ],
    "description": {
      "az": "Downlight 1x10W 3500K Square Black Grill — Ecolife | Kod: A0000012438",
      "en": "Downlight 1x10W 3500K Square Black Grill — Ecolife | Code: A0000012438",
      "ru": "Downlight 1x10W 3500K Square Black Grill — Ecolife | Код: A0000012438"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9ae98069389a53012b2",
    "slug": "6a26b9ae98069389a53012b2",
    "name": "Bulb GU10 9W 170-240V 4000K",
    "code": "A0000012383",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1sDNq5sdWSkeb1vhfK8_RmKRruCm7lxkq&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1sDNq5sdWSkeb1vhfK8_RmKRruCm7lxkq&sz=w800"
    ],
    "description": {
      "az": "Bulb GU10 9W 170-240V 4000K — Ecolife | Kod: A0000012383",
      "en": "Bulb GU10 9W 170-240V 4000K — Ecolife | Code: A0000012383",
      "ru": "Bulb GU10 9W 170-240V 4000K — Ecolife | Код: A0000012383"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "9W",
      "cct": "4000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266504500d7dcf28e0fdbd",
    "slug": "6a266504500d7dcf28e0fdbd",
    "name": "Magnetic TrackLight 18W 4000K Reflector",
    "code": "A0000012473",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=19ltmLuOKqNZTbhl1LDi1lO-TlHHFs_-0&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=19ltmLuOKqNZTbhl1LDi1lO-TlHHFs_-0&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 18W 4000K Reflector — Ecolife | Kod: A0000012473",
      "en": "Magnetic TrackLight 18W 4000K Reflector — Ecolife | Code: A0000012473",
      "ru": "Magnetic TrackLight 18W 4000K Reflector — Ecolife | Код: A0000012473"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "18W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266502901e068171983e4d",
    "slug": "6a266502901e068171983e4d",
    "name": "Magnetic TrackLight 12W 4000K Reflector Motion",
    "code": "A0000012478",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1DRWcsJzcgQ-olcblJ5rAHF4WytFaPEk4&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1DRWcsJzcgQ-olcblJ5rAHF4WytFaPEk4&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 12W 4000K Reflector Motion — Ecolife | Kod: A0000012478",
      "en": "Magnetic TrackLight 12W 4000K Reflector Motion — Ecolife | Code: A0000012478",
      "ru": "Magnetic TrackLight 12W 4000K Reflector Motion — Ecolife | Код: A0000012478"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "12W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265fcaaadedcc2af3e82e1",
    "slug": "6a265fcaaadedcc2af3e82e1",
    "name": "LED Driver 36W 210Ma TINA 3D",
    "code": "A0000016454",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://drive.google.com/thumbnail?id=1ysBO4b3DlTDrjl3PSWANSC98Tu2BnQTq&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1ysBO4b3DlTDrjl3PSWANSC98Tu2BnQTq&sz=w800"
    ],
    "description": {
      "az": "LED Driver 36W 210Ma TINA 3D — Ecolife | Kod: A0000016454",
      "en": "LED Driver 36W 210Ma TINA 3D — Ecolife | Code: A0000016454",
      "ru": "LED Driver 36W 210Ma TINA 3D — Ecolife | Код: A0000016454"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—",
      "power": "36W"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933553978dd32fbe3573",
    "slug": "6a2f933553978dd32fbe3573",
    "name": "Flexstrip OSRAM 24V 28W 3500K 96 pcs 6m 15mm",
    "code": "A0000000424",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1_KmBhNDi3FnPytHNlk2Tov3itJjsRPSU&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1_KmBhNDi3FnPytHNlk2Tov3itJjsRPSU&sz=w800"
    ],
    "description": {
      "az": "Flexstrip OSRAM 24V 28W 3500K 96 pcs 6m 15mm — Ecolife | Kod: A0000000424",
      "en": "Flexstrip OSRAM 24V 28W 3500K 96 pcs 6m 15mm — Ecolife | Code: A0000000424",
      "ru": "Flexstrip OSRAM 24V 28W 3500K 96 pcs 6m 15mm — Ecolife | Код: A0000000424"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "28W",
      "cct": "3500K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa73400d3e42098ec3a63",
    "slug": "6a2fa73400d3e42098ec3a63",
    "name": "12291 PCB SANAN 22W 3000K 1,2m 144 led 160Lum/W",
    "code": "A0000015821",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=15bzLhgeYE2FAvP1eAVM2P4QpnAdO-Ox9&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=15bzLhgeYE2FAvP1eAVM2P4QpnAdO-Ox9&sz=w800"
    ],
    "description": {
      "az": "12291 PCB SANAN 22W 3000K 1,2m 144 led 160Lum/W — Ecolife | Kod: A0000015821",
      "en": "12291 PCB SANAN 22W 3000K 1,2m 144 led 160Lum/W — Ecolife | Code: A0000015821",
      "ru": "12291 PCB SANAN 22W 3000K 1,2m 144 led 160Lum/W — Ecolife | Код: A0000015821"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "22W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933766e7c3784a3a4ba8",
    "slug": "6a2f933766e7c3784a3a4ba8",
    "name": "Flexstrip OSRAM 24V 24W 3000K 144chip 2line 15mm",
    "code": "A0000000419",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1Py-AzjMRA7DlWH6nZOOql8AnGtXF1F1D&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Py-AzjMRA7DlWH6nZOOql8AnGtXF1F1D&sz=w800"
    ],
    "description": {
      "az": "Flexstrip OSRAM 24V 24W 3000K 144chip 2line 15mm — Ecolife | Kod: A0000000419",
      "en": "Flexstrip OSRAM 24V 24W 3000K 144chip 2line 15mm — Ecolife | Code: A0000000419",
      "ru": "Flexstrip OSRAM 24V 24W 3000K 144chip 2line 15mm — Ecolife | Код: A0000000419"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "24W",
      "cct": "3000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26652581bc35f5b3a08a92",
    "slug": "6a26652581bc35f5b3a08a92",
    "name": "Tracklight Rail 1m B",
    "code": "A0000001597",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1cYnLgmb3GZFABkBojavmHxq40p4G1yKr&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1cYnLgmb3GZFABkBojavmHxq40p4G1yKr&sz=w800"
    ],
    "description": {
      "az": "Tracklight Rail 1m B — Ecolife | Kod: A0000001597",
      "en": "Tracklight Rail 1m B — Ecolife | Code: A0000001597",
      "ru": "Tracklight Rail 1m B — Ecolife | Код: A0000001597"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94ffb03d64eb3ef193d",
    "slug": "6a2fe94ffb03d64eb3ef193d",
    "name": "Downlight 1xGU10 Round White",
    "code": "A0000002267",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1bUKulWBKvHgug9_WNkvWt_K5SZ8NMbZB&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1bUKulWBKvHgug9_WNkvWt_K5SZ8NMbZB&sz=w800"
    ],
    "description": {
      "az": "Downlight 1xGU10 Round White — Ecolife | Kod: A0000002267",
      "en": "Downlight 1xGU10 Round White — Ecolife | Code: A0000002267",
      "ru": "Downlight 1xGU10 Round White — Ecolife | Код: A0000002267"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9af865dc24a1d95c50e",
    "slug": "6a26b9af865dc24a1d95c50e",
    "name": "LED Spotlamp 6000K 9W GU5.3",
    "code": "A0000002149",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1cDp8fDo8cQwEPf4xAHTxY3Wdv4Z3XLwj&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1cDp8fDo8cQwEPf4xAHTxY3Wdv4Z3XLwj&sz=w800"
    ],
    "description": {
      "az": "LED Spotlamp 6000K 9W GU5.3 — Ecolife | Kod: A0000002149",
      "en": "LED Spotlamp 6000K 9W GU5.3 — Ecolife | Code: A0000002149",
      "ru": "LED Spotlamp 6000K 9W GU5.3 — Ecolife | Код: A0000002149"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "9W",
      "cct": "6000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266505812a800bd4503729",
    "slug": "6a266505812a800bd4503729",
    "name": "Magnetic TrackLight 30W 4000K D90",
    "code": "A0000012469",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1rPfs39PNqBFQFN6KHnTIBlYRbM2tr72i&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1rPfs39PNqBFQFN6KHnTIBlYRbM2tr72i&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 30W 4000K D90 — Ecolife | Kod: A0000012469",
      "en": "Magnetic TrackLight 30W 4000K D90 — Ecolife | Code: A0000012469",
      "ru": "Magnetic TrackLight 30W 4000K D90 — Ecolife | Код: A0000012469"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "30W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f93343a7bfef959de8d2e",
    "slug": "6a2f93343a7bfef959de8d2e",
    "name": "Flexstrip 220V 3000K 180L/M",
    "code": "A0000000370",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1cVzOu4oezgZtIDgKDbfdpGNlWQfHiRgT&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1cVzOu4oezgZtIDgKDbfdpGNlWQfHiRgT&sz=w800"
    ],
    "description": {
      "az": "Flexstrip 220V 3000K 180L/M — Ecolife | Kod: A0000000370",
      "en": "Flexstrip 220V 3000K 180L/M — Ecolife | Code: A0000000370",
      "ru": "Flexstrip 220V 3000K 180L/M — Ecolife | Код: A0000000370"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "cct": "3000K",
      "voltage": "220V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933608671df5c8374755",
    "slug": "6a2f933608671df5c8374755",
    "name": "Flexstrip OSRAM 24V 24W 4000K 144chip 2line 15mm",
    "code": "A0000000421",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1oY2qNlIQGg-YLGtzwaJAIgGXxO1upqJN&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1oY2qNlIQGg-YLGtzwaJAIgGXxO1upqJN&sz=w800"
    ],
    "description": {
      "az": "Flexstrip OSRAM 24V 24W 4000K 144chip 2line 15mm — Ecolife | Kod: A0000000421",
      "en": "Flexstrip OSRAM 24V 24W 4000K 144chip 2line 15mm — Ecolife | Code: A0000000421",
      "ru": "Flexstrip OSRAM 24V 24W 4000K 144chip 2line 15mm — Ecolife | Код: A0000000421"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "24W",
      "cct": "4000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f93350e641fd7b2d65d1f",
    "slug": "6a2f93350e641fd7b2d65d1f",
    "name": "Flexstrip OSRAM 24V 28W 5000K 96 pcs 6m 15mm",
    "code": "A0000000426",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=16Zf-nkHKkxVWKn1JIVvAkZmMP6PJqzeg&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=16Zf-nkHKkxVWKn1JIVvAkZmMP6PJqzeg&sz=w800"
    ],
    "description": {
      "az": "Flexstrip OSRAM 24V 28W 5000K 96 pcs 6m 15mm — Ecolife | Kod: A0000000426",
      "en": "Flexstrip OSRAM 24V 28W 5000K 96 pcs 6m 15mm — Ecolife | Code: A0000000426",
      "ru": "Flexstrip OSRAM 24V 28W 5000K 96 pcs 6m 15mm — Ecolife | Код: A0000000426"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "28W",
      "cct": "5000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664f81139d642d28179fd",
    "slug": "6a2664f81139d642d28179fd",
    "name": "Ultra Magnetic Driver 48V 100W 20mm",
    "code": "A0000001693",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1QCl7qJ7Y4rIgB4wQAG5CURMDvIuWbPc7&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1QCl7qJ7Y4rIgB4wQAG5CURMDvIuWbPc7&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic Driver 48V 100W 20mm — Ecolife | Kod: A0000001693",
      "en": "Ultra Magnetic Driver 48V 100W 20mm — Ecolife | Code: A0000001693",
      "ru": "Ultra Magnetic Driver 48V 100W 20mm — Ecolife | Код: A0000001693"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "100W",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94972ac69bf05f95bca",
    "slug": "6a2fe94972ac69bf05f95bca",
    "name": "Downlight 3X10W 3000K Square White Grill",
    "code": "A0000002358",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1BGXdxBUI4X17bdJpc4gfIp0WS1is5yGD&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1BGXdxBUI4X17bdJpc4gfIp0WS1is5yGD&sz=w800"
    ],
    "description": {
      "az": "Downlight 3X10W 3000K Square White Grill — Ecolife | Kod: A0000002358",
      "en": "Downlight 3X10W 3000K Square White Grill — Ecolife | Code: A0000002358",
      "ru": "Downlight 3X10W 3000K Square White Grill — Ecolife | Код: A0000002358"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26651f973d6ff3c8690626",
    "slug": "6a26651f973d6ff3c8690626",
    "name": "Tracklight 12x3W 4000K B Motion",
    "code": "A0000001510",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=11bFF9M-9lEMboq752O0OtsMQGLDP5Y4f&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=11bFF9M-9lEMboq752O0OtsMQGLDP5Y4f&sz=w800"
    ],
    "description": {
      "az": "Tracklight 12x3W 4000K B Motion — Ecolife | Kod: A0000001510",
      "en": "Tracklight 12x3W 4000K B Motion — Ecolife | Code: A0000001510",
      "ru": "Tracklight 12x3W 4000K B Motion — Ecolife | Код: A0000001510"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "3W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665040f6c27ee9182c634",
    "slug": "6a2665040f6c27ee9182c634",
    "name": "Magnetic TrackLight 24W 4000K reflector",
    "code": "A0000012474",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=11CPARXKRY9lQ6DQkiiymC3fj_dKDQWmm&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=11CPARXKRY9lQ6DQkiiymC3fj_dKDQWmm&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 24W 4000K reflector — Ecolife | Kod: A0000012474",
      "en": "Magnetic TrackLight 24W 4000K reflector — Ecolife | Code: A0000012474",
      "ru": "Magnetic TrackLight 24W 4000K reflector — Ecolife | Код: A0000012474"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "24W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe95005fc8eafa6d4175c",
    "slug": "6a2fe95005fc8eafa6d4175c",
    "name": "Downlight 3xGU10 Square White",
    "code": "A0000002274",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1Koefc2MW47dNFm0YXkegv3UYysxh4zfh&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Koefc2MW47dNFm0YXkegv3UYysxh4zfh&sz=w800"
    ],
    "description": {
      "az": "Downlight 3xGU10 Square White — Ecolife | Kod: A0000002274",
      "en": "Downlight 3xGU10 Square White — Ecolife | Code: A0000002274",
      "ru": "Downlight 3xGU10 Square White — Ecolife | Код: A0000002274"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26650ab74be6142226e1fb",
    "slug": "6a26650ab74be6142226e1fb",
    "name": "Magnetic Tracklight Line D90 48V 40W 3500K 25mm",
    "code": "A0000012361",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1R-Up2Cxzd6coRyjEKeuDS2mnQDoc-0-p&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1R-Up2Cxzd6coRyjEKeuDS2mnQDoc-0-p&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight Line D90 48V 40W 3500K 25mm — Ecolife | Kod: A0000012361",
      "en": "Magnetic Tracklight Line D90 48V 40W 3500K 25mm — Ecolife | Code: A0000012361",
      "ru": "Magnetic Tracklight Line D90 48V 40W 3500K 25mm — Ecolife | Код: A0000012361"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "40W",
      "cct": "3500K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651f4410b1c27fcc57fe",
    "slug": "6a43651f4410b1c27fcc57fe",
    "name": "DRIVER 48W 24V IP54",
    "code": "A0000000549",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 48W 24V IP54 — Ecolife | Kod: A0000000549",
      "en": "DRIVER 48W 24V IP54 — Ecolife | Code: A0000000549",
      "ru": "DRIVER 48W 24V IP54 — Ecolife | Код: A0000000549"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP54",
      "mounting": "—",
      "power": "48W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664f9fe6c4f5c093337c1",
    "slug": "6a2664f9fe6c4f5c093337c1",
    "name": "Ultra Magnetic PowerConnector 180°",
    "code": "A0000001680",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1-Poi6v_XARcz-UQnUnNoZGs0T0PH6NC3&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1-Poi6v_XARcz-UQnUnNoZGs0T0PH6NC3&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic PowerConnector 180° — Ecolife | Kod: A0000001680",
      "en": "Ultra Magnetic PowerConnector 180° — Ecolife | Code: A0000001680",
      "ru": "Ultra Magnetic PowerConnector 180° — Ecolife | Код: A0000001680"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fc1c8e87d3ecc3ee7e",
    "slug": "6a2664fc1c8e87d3ecc3ee7e",
    "name": "Ultra Magnetic Rail 20mm 3m",
    "code": "A0000001685",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1OptZPG1IrovFK9HwSwNqA6bqmQkYMAjI&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1OptZPG1IrovFK9HwSwNqA6bqmQkYMAjI&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic Rail 20mm 3m — Ecolife | Kod: A0000001685",
      "en": "Ultra Magnetic Rail 20mm 3m — Ecolife | Code: A0000001685",
      "ru": "Ultra Magnetic Rail 20mm 3m — Ecolife | Код: A0000001685"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aee3b36a8163993ea5b",
    "slug": "6a265aee3b36a8163993ea5b",
    "name": "Panel 10W 3000K Round White Sidelit",
    "code": "A0000001905",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1osRgRsZ8v_ER6QVcNQo40-WOJPgJhVyD&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1osRgRsZ8v_ER6QVcNQo40-WOJPgJhVyD&sz=w800"
    ],
    "description": {
      "az": "Panel 10W 3000K Round White Sidelit — Ecolife | Kod: A0000001905",
      "en": "Panel 10W 3000K Round White Sidelit — Ecolife | Code: A0000001905",
      "ru": "Panel 10W 3000K Round White Sidelit — Ecolife | Код: A0000001905"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "10W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af18ff6c8cbae04511c",
    "slug": "6a265af18ff6c8cbae04511c",
    "name": "Panel 22W 4000K Round White Sidelit",
    "code": "A0000001908",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1t-ZHt4JEPtt7RONNf4X79NaxAxcTpA2H&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1t-ZHt4JEPtt7RONNf4X79NaxAxcTpA2H&sz=w800"
    ],
    "description": {
      "az": "Panel 22W 4000K Round White Sidelit — Ecolife | Kod: A0000001908",
      "en": "Panel 22W 4000K Round White Sidelit — Ecolife | Code: A0000001908",
      "ru": "Panel 22W 4000K Round White Sidelit — Ecolife | Код: A0000001908"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "22W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa73606d60f6bdbfdf3e7",
    "slug": "6a2fa73606d60f6bdbfdf3e7",
    "name": "PCB OSRAM 24V 40W 28*1.5M 4000K 96 pcs 20mm",
    "code": "A0000011562",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1JuRpc50QVX8Qapu3el7FcctDy1pleZFe&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1JuRpc50QVX8Qapu3el7FcctDy1pleZFe&sz=w800"
    ],
    "description": {
      "az": "PCB OSRAM 24V 40W 28*1.5M 4000K 96 pcs 20mm — Ecolife | Kod: A0000011562",
      "en": "PCB OSRAM 24V 40W 28*1.5M 4000K 96 pcs 20mm — Ecolife | Code: A0000011562",
      "ru": "PCB OSRAM 24V 40W 28*1.5M 4000K 96 pcs 20mm — Ecolife | Код: A0000011562"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "40W",
      "cct": "4000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94623a6c50b0f85452d",
    "slug": "6a2fe94623a6c50b0f85452d",
    "name": "Downlight 1x7W 3000K Round Black Grill",
    "code": "A0000002836",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1bmJxJCV16p_zYpvG0tuiFyRzxtStvefW&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1bmJxJCV16p_zYpvG0tuiFyRzxtStvefW&sz=w800"
    ],
    "description": {
      "az": "Downlight 1x7W 3000K Round Black Grill — Ecolife | Kod: A0000002836",
      "en": "Downlight 1x7W 3000K Round Black Grill — Ecolife | Code: A0000002836",
      "ru": "Downlight 1x7W 3000K Round Black Grill — Ecolife | Код: A0000002836"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651d75806be9f21914f1",
    "slug": "6a43651d75806be9f21914f1",
    "name": "DRIVER 24V 500W 20A IP21",
    "code": "A0000011557",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 500W 20A IP21 — Ecolife | Kod: A0000011557",
      "en": "DRIVER 24V 500W 20A IP21 — Ecolife | Code: A0000011557",
      "ru": "DRIVER 24V 500W 20A IP21 — Ecolife | Код: A0000011557"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "500W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266509de25a0cc8a08cb3b",
    "slug": "6a266509de25a0cc8a08cb3b",
    "name": "Magnetic Rail 35mm 3m Surface",
    "code": "A0000012367",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1rSkce7vTB9rlBAySnIEjhJlkXwjGXLQ6&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1rSkce7vTB9rlBAySnIEjhJlkXwjGXLQ6&sz=w800"
    ],
    "description": {
      "az": "Magnetic Rail 35mm 3m Surface — Ecolife | Kod: A0000012367",
      "en": "Magnetic Rail 35mm 3m Surface — Ecolife | Code: A0000012367",
      "ru": "Magnetic Rail 35mm 3m Surface — Ecolife | Код: A0000012367"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aef4fbc8da3cbe33ccc",
    "slug": "6a265aef4fbc8da3cbe33ccc",
    "name": "Panel 32W 4000K Round White 3D Surface",
    "code": "A0000001902",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1pNrvFsLbpzh0eu7LyVB1q6ORoNpfg0h9&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1pNrvFsLbpzh0eu7LyVB1q6ORoNpfg0h9&sz=w800"
    ],
    "description": {
      "az": "Panel 32W 4000K Round White 3D Surface — Ecolife | Kod: A0000001902",
      "en": "Panel 32W 4000K Round White 3D Surface — Ecolife | Code: A0000001902",
      "ru": "Panel 32W 4000K Round White 3D Surface — Ecolife | Код: A0000001902"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "32W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26651ee3c44c1ec9260a6e",
    "slug": "6a26651ee3c44c1ec9260a6e",
    "name": "Tracklight 40W 4000K G CRI>90 angle 60°",
    "code": "A0000011549",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1YRolPeH4z9WM_NnSKS_MmodcyFOHgxun&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1YRolPeH4z9WM_NnSKS_MmodcyFOHgxun&sz=w800"
    ],
    "description": {
      "az": "Tracklight 40W 4000K G CRI>90 angle 60° — Ecolife | Kod: A0000011549",
      "en": "Tracklight 40W 4000K G CRI>90 angle 60° — Ecolife | Code: A0000011549",
      "ru": "Tracklight 40W 4000K G CRI>90 angle 60° — Ecolife | Код: A0000011549"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "40W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b01cb10d0f900edf24",
    "slug": "6a26b9b01cb10d0f900edf24",
    "name": "LED Candle 160-240V 3000K E14 9W C37 Sharp",
    "code": "A0000002106",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1FBeWBBOLT659nuXaNqnc22C2nCINWXAD&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1FBeWBBOLT659nuXaNqnc22C2nCINWXAD&sz=w800"
    ],
    "description": {
      "az": "LED Candle 160-240V 3000K E14 9W C37 Sharp — Ecolife | Kod: A0000002106",
      "en": "LED Candle 160-240V 3000K E14 9W C37 Sharp — Ecolife | Code: A0000002106",
      "ru": "LED Candle 160-240V 3000K E14 9W C37 Sharp — Ecolife | Код: A0000002106"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "9W",
      "cct": "3000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26650aacbfb4add61f8a28",
    "slug": "6a26650aacbfb4add61f8a28",
    "name": "Magnetic Tracklight Line D60 48V 30W 3500K 25mm",
    "code": "A0000012360",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1y9E1zytxo1_ndN5EDw-CVcaLRqHhoO6Y&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1y9E1zytxo1_ndN5EDw-CVcaLRqHhoO6Y&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight Line D60 48V 30W 3500K 25mm — Ecolife | Kod: A0000012360",
      "en": "Magnetic Tracklight Line D60 48V 30W 3500K 25mm — Ecolife | Code: A0000012360",
      "ru": "Magnetic Tracklight Line D60 48V 30W 3500K 25mm — Ecolife | Код: A0000012360"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "30W",
      "cct": "3500K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651981bec6dbf1b32549",
    "slug": "6a43651981bec6dbf1b32549",
    "name": "DRIVER 24V 200W IP67",
    "code": "A0000000573",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 200W IP67 — Ecolife | Kod: A0000000573",
      "en": "DRIVER 24V 200W IP67 — Ecolife | Code: A0000000573",
      "ru": "DRIVER 24V 200W IP67 — Ecolife | Код: A0000000573"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP67",
      "mounting": "—",
      "power": "200W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fd1d3e04cf1ea2dc66",
    "slug": "6a2664fd1d3e04cf1ea2dc66",
    "name": "Magnetic Tracklight Special 48V 07W 4000K 25-35mm",
    "code": "A0000001668",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1ALZ7s6TBaaIKrK7HM5L5ozKoyW7wTL6E&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1ALZ7s6TBaaIKrK7HM5L5ozKoyW7wTL6E&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight Special 48V 07W 4000K 25-35mm — Ecolife | Kod: A0000001668",
      "en": "Magnetic Tracklight Special 48V 07W 4000K 25-35mm — Ecolife | Code: A0000001668",
      "ru": "Magnetic Tracklight Special 48V 07W 4000K 25-35mm — Ecolife | Код: A0000001668"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "07W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe95024b6ddfce3bcedaa",
    "slug": "6a2fe95024b6ddfce3bcedaa",
    "name": "Downlight 2xGU10 Round White+Black",
    "code": "A0000002264",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=15yGjz4v3XNWplPmc_gW5GUOrRlE4Dmlo&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=15yGjz4v3XNWplPmc_gW5GUOrRlE4Dmlo&sz=w800"
    ],
    "description": {
      "az": "Downlight 2xGU10 Round White+Black — Ecolife | Kod: A0000002264",
      "en": "Downlight 2xGU10 Round White+Black — Ecolife | Code: A0000002264",
      "ru": "Downlight 2xGU10 Round White+Black — Ecolife | Код: A0000002264"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a0ecdb4aab0869581bef7c4",
    "slug": "6a0ecdb4aab0869581bef7c4",
    "name": "ECL_ FMS/A1746_TP1746",
    "code": "A0000001746",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1ER7c4ucPpDMmWNE4AJBLKn3BlcCLSQ6B&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1ER7c4ucPpDMmWNE4AJBLKn3BlcCLSQ6B&sz=w800"
    ],
    "description": {
      "az": "ECL_ FMS/A1746_TP1746 — Ecolife | Kod: A0000001746",
      "en": "ECL_ FMS/A1746_TP1746 — Ecolife | Code: A0000001746",
      "ru": "ECL_ FMS/A1746_TP1746 — Ecolife | Код: A0000001746"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651c44ab6ccd8f63aac5",
    "slug": "6a43651c44ab6ccd8f63aac5",
    "name": "DRIVER 24V 30W 1,25A IP21",
    "code": "A0000011529",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 30W 1,25A IP21 — Ecolife | Kod: A0000011529",
      "en": "DRIVER 24V 30W 1,25A IP21 — Ecolife | Code: A0000011529",
      "ru": "DRIVER 24V 30W 1,25A IP21 — Ecolife | Код: A0000011529"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "30W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651b44d3c0c4dc23007f",
    "slug": "6a43651b44d3c0c4dc23007f",
    "name": "DRIVER 24V 72W IP21 kod_ 33024072/3A",
    "code": "A0000011532",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 72W IP21 kod_ 33024072/3A — Ecolife | Kod: A0000011532",
      "en": "DRIVER 24V 72W IP21 kod_ 33024072/3A — Ecolife | Code: A0000011532",
      "ru": "DRIVER 24V 72W IP21 kod_ 33024072/3A — Ecolife | Код: A0000011532"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "72W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f9338326adc062895d197",
    "slug": "6a2f9338326adc062895d197",
    "name": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K ONE STEP",
    "code": "A0000000407",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1CZCjqcWMmpbJXYjIUWBgNqalZjYHBzvP&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1CZCjqcWMmpbJXYjIUWBgNqalZjYHBzvP&sz=w800"
    ],
    "description": {
      "az": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K ONE STEP — Ecolife | Kod: A0000000407",
      "en": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K ONE STEP — Ecolife | Code: A0000000407",
      "ru": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K ONE STEP — Ecolife | Код: A0000000407"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "10W",
      "cct": "6000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933af2aee8868e8ac8f8",
    "slug": "6a2f933af2aee8868e8ac8f8",
    "name": "Flexstrip EPISTAR 24V 18W 48chip 10mm 6500K ONE STEP LENS",
    "code": "A0000012400",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=11qUu-FlNCQAEjiu_LeEnMqnjFy0-iOWc&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=11qUu-FlNCQAEjiu_LeEnMqnjFy0-iOWc&sz=w800"
    ],
    "description": {
      "az": "Flexstrip EPISTAR 24V 18W 48chip 10mm 6500K ONE STEP LENS — Ecolife | Kod: A0000012400",
      "en": "Flexstrip EPISTAR 24V 18W 48chip 10mm 6500K ONE STEP LENS — Ecolife | Code: A0000012400",
      "ru": "Flexstrip EPISTAR 24V 18W 48chip 10mm 6500K ONE STEP LENS — Ecolife | Код: A0000012400"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "18W",
      "cct": "6500K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa735726e3ee0b57e03db",
    "slug": "6a2fa735726e3ee0b57e03db",
    "name": "PCB SET 6 IN 1 AND DRIVER 55W 60sm 4000K",
    "code": "A0000000297",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1Qw6o1YqhBmiETFDu2dTm3SP2YzMPgamW&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Qw6o1YqhBmiETFDu2dTm3SP2YzMPgamW&sz=w800"
    ],
    "description": {
      "az": "PCB SET 6 IN 1 AND DRIVER 55W 60sm 4000K — Ecolife | Kod: A0000000297",
      "en": "PCB SET 6 IN 1 AND DRIVER 55W 60sm 4000K — Ecolife | Code: A0000000297",
      "ru": "PCB SET 6 IN 1 AND DRIVER 55W 60sm 4000K — Ecolife | Код: A0000000297"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "55W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fe302c1f0746457857",
    "slug": "6a2664fe302c1f0746457857",
    "name": "Magnetic Driver 48V 200W 35mm",
    "code": "A0000001674",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1GdA4bjm2wdogWAtLFSscmY_UbM_BCVek&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1GdA4bjm2wdogWAtLFSscmY_UbM_BCVek&sz=w800"
    ],
    "description": {
      "az": "Magnetic Driver 48V 200W 35mm — Ecolife | Kod: A0000001674",
      "en": "Magnetic Driver 48V 200W 35mm — Ecolife | Code: A0000001674",
      "ru": "Magnetic Driver 48V 200W 35mm — Ecolife | Код: A0000001674"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "200W",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665085b584b6187b83142",
    "slug": "6a2665085b584b6187b83142",
    "name": "Magnetic Tracklight SR08 48V 18W 4000K 35mm Motion",
    "code": "A0000012368",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=143nfRULl7D3JgIxvjt3yfWWaQOXI8Yak&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=143nfRULl7D3JgIxvjt3yfWWaQOXI8Yak&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight SR08 48V 18W 4000K 35mm Motion — Ecolife | Kod: A0000012368",
      "en": "Magnetic Tracklight SR08 48V 18W 4000K 35mm Motion — Ecolife | Code: A0000012368",
      "ru": "Magnetic Tracklight SR08 48V 18W 4000K 35mm Motion — Ecolife | Код: A0000012368"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "18W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26652324e7fcb554472e6a",
    "slug": "6a26652324e7fcb554472e6a",
    "name": "Tracklight Rail 3m W",
    "code": "A0000001608",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1yMA16_ianM9liOn3lK9uQEj6Lnl2OePZ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1yMA16_ianM9liOn3lK9uQEj6Lnl2OePZ&sz=w800"
    ],
    "description": {
      "az": "Tracklight Rail 3m W — Ecolife | Kod: A0000001608",
      "en": "Tracklight Rail 3m W — Ecolife | Code: A0000001608",
      "ru": "Tracklight Rail 3m W — Ecolife | Код: A0000001608"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665057fc3f162f2c69ed6",
    "slug": "6a2665057fc3f162f2c69ed6",
    "name": "Magnetic TrackLight 06W 4000K Reflector",
    "code": "A0000012471",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1kx9xMBgPS5EQVodq9sFY2eYrrtXs19df&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1kx9xMBgPS5EQVodq9sFY2eYrrtXs19df&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 06W 4000K Reflector — Ecolife | Kod: A0000012471",
      "en": "Magnetic TrackLight 06W 4000K Reflector — Ecolife | Code: A0000012471",
      "ru": "Magnetic TrackLight 06W 4000K Reflector — Ecolife | Код: A0000012471"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "06W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe947e7ab8011325f990b",
    "slug": "6a2fe947e7ab8011325f990b",
    "name": "Downlight 1x10W 3000K Square White Grill",
    "code": "A0000002832",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1q9NsBMAh1oJr5rVsFDcFkeEqJNT77_Cv&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1q9NsBMAh1oJr5rVsFDcFkeEqJNT77_Cv&sz=w800"
    ],
    "description": {
      "az": "Downlight 1x10W 3000K Square White Grill — Ecolife | Kod: A0000002832",
      "en": "Downlight 1x10W 3000K Square White Grill — Ecolife | Code: A0000002832",
      "ru": "Downlight 1x10W 3000K Square White Grill — Ecolife | Код: A0000002832"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9458b1a080f55d83d4c",
    "slug": "6a2fe9458b1a080f55d83d4c",
    "name": "Downlight 3X7W 3500K Square White Grill",
    "code": "A0000002841",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1wV6zN83oQR0vJXN1RKwZcOwKPHsviLzj&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1wV6zN83oQR0vJXN1RKwZcOwKPHsviLzj&sz=w800"
    ],
    "description": {
      "az": "Downlight 3X7W 3500K Square White Grill — Ecolife | Kod: A0000002841",
      "en": "Downlight 3X7W 3500K Square White Grill — Ecolife | Code: A0000002841",
      "ru": "Downlight 3X7W 3500K Square White Grill — Ecolife | Код: A0000002841"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f9334a22613006875acff",
    "slug": "6a2f9334a22613006875acff",
    "name": "FlexstrIp 220V 4000K 180L/M",
    "code": "A0000000373",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1dZNiBTz-Pw7iM6a9attlAyj-aApgawj2&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1dZNiBTz-Pw7iM6a9attlAyj-aApgawj2&sz=w800"
    ],
    "description": {
      "az": "FlexstrIp 220V 4000K 180L/M — Ecolife | Kod: A0000000373",
      "en": "FlexstrIp 220V 4000K 180L/M — Ecolife | Code: A0000000373",
      "ru": "FlexstrIp 220V 4000K 180L/M — Ecolife | Код: A0000000373"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "cct": "4000K",
      "voltage": "220V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe956384c9a2448f7bd53",
    "slug": "6a2fe956384c9a2448f7bd53",
    "name": "Downlight 2x7W 3500K Square White Grill",
    "code": "A0000012431",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1ap6Z6RnxnxubF1oU0D_XQIZysU5Pnnn5&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1ap6Z6RnxnxubF1oU0D_XQIZysU5Pnnn5&sz=w800"
    ],
    "description": {
      "az": "Downlight 2x7W 3500K Square White Grill — Ecolife | Kod: A0000012431",
      "en": "Downlight 2x7W 3500K Square White Grill — Ecolife | Code: A0000012431",
      "ru": "Downlight 2x7W 3500K Square White Grill — Ecolife | Код: A0000012431"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe952fcbefbe4404c0c3b",
    "slug": "6a2fe952fcbefbe4404c0c3b",
    "name": "Downlight 1xGU10 Square White",
    "code": "A0000002272",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1OziaF8KdErbcC0LHmTE9d3D9WEyVcETN&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1OziaF8KdErbcC0LHmTE9d3D9WEyVcETN&sz=w800"
    ],
    "description": {
      "az": "Downlight 1xGU10 Square White — Ecolife | Kod: A0000002272",
      "en": "Downlight 1xGU10 Square White — Ecolife | Code: A0000002272",
      "ru": "Downlight 1xGU10 Square White — Ecolife | Код: A0000002272"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265fc90915aabd8578f2d5",
    "slug": "6a265fc90915aabd8578f2d5",
    "name": "ECL_WNG/A11962",
    "code": "A0000011962",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://drive.google.com/thumbnail?id=14BNR6-nepTuCc4Kg5_yzVvocR4hPvWRT&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=14BNR6-nepTuCc4Kg5_yzVvocR4hPvWRT&sz=w800"
    ],
    "description": {
      "az": "ECL_WNG/A11962 — Ecolife | Kod: A0000011962",
      "en": "ECL_WNG/A11962 — Ecolife | Code: A0000011962",
      "ru": "ECL_WNG/A11962 — Ecolife | Код: A0000011962"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fc2102ee3dfed3d7cf",
    "slug": "6a2664fc2102ee3dfed3d7cf",
    "name": "Ultra Magnetic Tracklight Spot 48V 10W 4000K 20mm",
    "code": "A0000001688",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1Q1id4COQeuezaiZaEHAykikF133Uj-41&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Q1id4COQeuezaiZaEHAykikF133Uj-41&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic Tracklight Spot 48V 10W 4000K 20mm — Ecolife | Kod: A0000001688",
      "en": "Ultra Magnetic Tracklight Spot 48V 10W 4000K 20mm — Ecolife | Code: A0000001688",
      "ru": "Ultra Magnetic Tracklight Spot 48V 10W 4000K 20mm — Ecolife | Код: A0000001688"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "10W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664f8ccb5c9832a4e9e1d",
    "slug": "6a2664f8ccb5c9832a4e9e1d",
    "name": "Magnetic Tracklight SR06 48V 6W 4000K 25mm Motion",
    "code": "A0000011638",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1ubcEWJVD_Sfp8i7DaAG53KJI6IYe3LzJ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1ubcEWJVD_Sfp8i7DaAG53KJI6IYe3LzJ&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight SR06 48V 6W 4000K 25mm Motion — Ecolife | Kod: A0000011638",
      "en": "Magnetic Tracklight SR06 48V 6W 4000K 25mm Motion — Ecolife | Code: A0000011638",
      "ru": "Magnetic Tracklight SR06 48V 6W 4000K 25mm Motion — Ecolife | Код: A0000011638"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "6W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af28120f02cd62a2c95",
    "slug": "6a265af28120f02cd62a2c95",
    "name": "Panel 60W 6500K 600x6000 Backlit",
    "code": "A0000016394",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1f4fBMOhEJxgJ_wG_WwaiLEQa_AxoXrmR&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1f4fBMOhEJxgJ_wG_WwaiLEQa_AxoXrmR&sz=w800"
    ],
    "description": {
      "az": "Panel 60W 6500K 600x6000 Backlit — Ecolife | Kod: A0000016394",
      "en": "Panel 60W 6500K 600x6000 Backlit — Ecolife | Code: A0000016394",
      "ru": "Panel 60W 6500K 600x6000 Backlit — Ecolife | Код: A0000016394"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "60W",
      "cct": "6500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a27ef1e18f78d02cf939302",
    "slug": "6a27ef1e18f78d02cf939302",
    "name": "Floodlight 200W 6500K 120lum/w PF>0.9 IP65",
    "code": "A0000012384",
    "category": "decorative",
    "categoryName": {
      "az": "Dekorativ",
      "en": "Decorative",
      "ru": "Декоративные"
    },
    "subtitle": {
      "az": "Dekorativ",
      "en": "Decorative",
      "ru": "Декоративные"
    },
    "image": "https://drive.google.com/thumbnail?id=15pJizXer0cSGJk5UFdKrqKN1BhPnhKs8&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=15pJizXer0cSGJk5UFdKrqKN1BhPnhKs8&sz=w800"
    ],
    "description": {
      "az": "Floodlight 200W 6500K 120lum/w PF>0.9 IP65 — Ecolife | Kod: A0000012384",
      "en": "Floodlight 200W 6500K 120lum/w PF>0.9 IP65 — Ecolife | Code: A0000012384",
      "ru": "Floodlight 200W 6500K 120lum/w PF>0.9 IP65 — Ecolife | Код: A0000012384"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP65",
      "mounting": "Səthə / Asma",
      "power": "200W",
      "cct": "6500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa73456429a081845b1bd",
    "slug": "6a2fa73456429a081845b1bd",
    "name": "12292 PCB SANAN 32W 4000K 1,5m 216 led 160Lum/W",
    "code": "A0000015820",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1m0sB3_5vF2MzctWqYvZgbzBK0w1Yi8B7&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1m0sB3_5vF2MzctWqYvZgbzBK0w1Yi8B7&sz=w800"
    ],
    "description": {
      "az": "12292 PCB SANAN 32W 4000K 1,5m 216 led 160Lum/W — Ecolife | Kod: A0000015820",
      "en": "12292 PCB SANAN 32W 4000K 1,5m 216 led 160Lum/W — Ecolife | Code: A0000015820",
      "ru": "12292 PCB SANAN 32W 4000K 1,5m 216 led 160Lum/W — Ecolife | Код: A0000015820"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "32W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266524c3f7d434282b7dcc",
    "slug": "6a266524c3f7d434282b7dcc",
    "name": "Tracklight Rail 2m W",
    "code": "A0000001606",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1d7atIsMyQwcZRnHb3VXvsqjNImb5bgZt&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1d7atIsMyQwcZRnHb3VXvsqjNImb5bgZt&sz=w800"
    ],
    "description": {
      "az": "Tracklight Rail 2m W — Ecolife | Kod: A0000001606",
      "en": "Tracklight Rail 2m W — Ecolife | Code: A0000001606",
      "ru": "Tracklight Rail 2m W — Ecolife | Код: A0000001606"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe95410f213c9b58b06f5",
    "slug": "6a2fe95410f213c9b58b06f5",
    "name": "Downlight 10W 4000K COB",
    "code": "A0000015627",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1uecchQQKwoBXJ7m6bXhduQ2YVSPFnAx3&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1uecchQQKwoBXJ7m6bXhduQ2YVSPFnAx3&sz=w800"
    ],
    "description": {
      "az": "Downlight 10W 4000K COB — Ecolife | Kod: A0000015627",
      "en": "Downlight 10W 4000K COB — Ecolife | Code: A0000015627",
      "ru": "Downlight 10W 4000K COB — Ecolife | Код: A0000015627"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe955fb35d68aa5fa89d6",
    "slug": "6a2fe955fb35d68aa5fa89d6",
    "name": "Downlight 10W 3000K COB",
    "code": "A0000015624",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1BKiNZrnw6HEldJTvFIBWE7reVzYA3jfV&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1BKiNZrnw6HEldJTvFIBWE7reVzYA3jfV&sz=w800"
    ],
    "description": {
      "az": "Downlight 10W 3000K COB — Ecolife | Kod: A0000015624",
      "en": "Downlight 10W 3000K COB — Ecolife | Code: A0000015624",
      "ru": "Downlight 10W 3000K COB — Ecolife | Код: A0000015624"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933b2eff0b327cadfd43",
    "slug": "6a2f933b2eff0b327cadfd43",
    "name": "Flexstrip EPISTAR 24V 18W 48chip 10mm 3000K ONE STEP LENS",
    "code": "A0000012399",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1nuCrWFhuWamylzWowNyDxrc_0JrHKmP-&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1nuCrWFhuWamylzWowNyDxrc_0JrHKmP-&sz=w800"
    ],
    "description": {
      "az": "Flexstrip EPISTAR 24V 18W 48chip 10mm 3000K ONE STEP LENS — Ecolife | Kod: A0000012399",
      "en": "Flexstrip EPISTAR 24V 18W 48chip 10mm 3000K ONE STEP LENS — Ecolife | Code: A0000012399",
      "ru": "Flexstrip EPISTAR 24V 18W 48chip 10mm 3000K ONE STEP LENS — Ecolife | Код: A0000012399"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "18W",
      "cct": "3000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f9339d740c58a24b19c61",
    "slug": "6a2f9339d740c58a24b19c61",
    "name": "Flexstrip EPISTAR 12V 10W 120chip 8mm 6000K",
    "code": "A0000000396",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1EMaGez0LfezacK4fTrBqcKN2FbdRrODY&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1EMaGez0LfezacK4fTrBqcKN2FbdRrODY&sz=w800"
    ],
    "description": {
      "az": "Flexstrip EPISTAR 12V 10W 120chip 8mm 6000K — Ecolife | Kod: A0000000396",
      "en": "Flexstrip EPISTAR 12V 10W 120chip 8mm 6000K — Ecolife | Code: A0000000396",
      "ru": "Flexstrip EPISTAR 12V 10W 120chip 8mm 6000K — Ecolife | Код: A0000000396"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "10W",
      "cct": "6000K",
      "voltage": "12V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26652239b73046a2defd42",
    "slug": "6a26652239b73046a2defd42",
    "name": "Tracklight 10W 3500K B",
    "code": "A0000001498",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1jW09f-Juet0UYC9UlNxg50qUQikbvTS6&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1jW09f-Juet0UYC9UlNxg50qUQikbvTS6&sz=w800"
    ],
    "description": {
      "az": "Tracklight 10W 3500K B — Ecolife | Kod: A0000001498",
      "en": "Tracklight 10W 3500K B — Ecolife | Code: A0000001498",
      "ru": "Tracklight 10W 3500K B — Ecolife | Код: A0000001498"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "10W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933ae9bad65c5b85e0e5",
    "slug": "6a2f933ae9bad65c5b85e0e5",
    "name": "Flexstrip OSRAM 24V 28W 192 chip 15mm 3000/5000K 2colors",
    "code": "A0000000413",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1gf5maYgy_3zookDiF9o90Adjoj6aVBde&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1gf5maYgy_3zookDiF9o90Adjoj6aVBde&sz=w800"
    ],
    "description": {
      "az": "Flexstrip OSRAM 24V 28W 192 chip 15mm 3000/5000K 2colors — Ecolife | Kod: A0000000413",
      "en": "Flexstrip OSRAM 24V 28W 192 chip 15mm 3000/5000K 2colors — Ecolife | Code: A0000000413",
      "ru": "Flexstrip OSRAM 24V 28W 192 chip 15mm 3000/5000K 2colors — Ecolife | Код: A0000000413"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "28W",
      "cct": "5000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af45d45c4109a7c866d",
    "slug": "6a265af45d45c4109a7c866d",
    "name": "Panel Body Square White 3D",
    "code": "A0000002001",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=11HXHPqoQ03nEZ5i9068zw7gbJwngR8KD&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=11HXHPqoQ03nEZ5i9068zw7gbJwngR8KD&sz=w800"
    ],
    "description": {
      "az": "Panel Body Square White 3D — Ecolife | Kod: A0000002001",
      "en": "Panel Body Square White 3D — Ecolife | Code: A0000002001",
      "ru": "Panel Body Square White 3D — Ecolife | Код: A0000002001"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651c154dce6613933fce",
    "slug": "6a43651c154dce6613933fce",
    "name": "DRIVER 24V 36W 1,5A IP21",
    "code": "A0000011530",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 36W 1,5A IP21 — Ecolife | Kod: A0000011530",
      "en": "DRIVER 24V 36W 1,5A IP21 — Ecolife | Code: A0000011530",
      "ru": "DRIVER 24V 36W 1,5A IP21 — Ecolife | Код: A0000011530"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "36W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664ffd1d44644d09a39f4",
    "slug": "6a2664ffd1d44644d09a39f4",
    "name": "Magnetic EndCap",
    "code": "A0000001655",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1FXL1SrsUaeSifTGsP0y7LJaELbyu7OZB&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1FXL1SrsUaeSifTGsP0y7LJaELbyu7OZB&sz=w800"
    ],
    "description": {
      "az": "Magnetic EndCap — Ecolife | Kod: A0000001655",
      "en": "Magnetic EndCap — Ecolife | Code: A0000001655",
      "ru": "Magnetic EndCap — Ecolife | Код: A0000001655"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fdd31ebdad889e1948",
    "slug": "6a2664fdd31ebdad889e1948",
    "name": "Magnetic Tracklight SR20 48V 40W 4000K 35",
    "code": "A0000001656",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1en5o7VCRColDBeHM8r0TD8HtfjUTwz-T&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1en5o7VCRColDBeHM8r0TD8HtfjUTwz-T&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight SR20 48V 40W 4000K 35 — Ecolife | Kod: A0000001656",
      "en": "Magnetic Tracklight SR20 48V 40W 4000K 35 — Ecolife | Code: A0000001656",
      "ru": "Magnetic Tracklight SR20 48V 40W 4000K 35 — Ecolife | Код: A0000001656"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "40W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9484aaa45fb2f798c32",
    "slug": "6a2fe9484aaa45fb2f798c32",
    "name": "Downlight 1x10W 3000K Square Black Grill",
    "code": "A0000002828",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1lMCijm5QAcXTAX6ifGZVLAWiSzGklOfE&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1lMCijm5QAcXTAX6ifGZVLAWiSzGklOfE&sz=w800"
    ],
    "description": {
      "az": "Downlight 1x10W 3000K Square Black Grill — Ecolife | Kod: A0000002828",
      "en": "Downlight 1x10W 3000K Square Black Grill — Ecolife | Code: A0000002828",
      "ru": "Downlight 1x10W 3000K Square Black Grill — Ecolife | Код: A0000002828"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa73328c1df4eee4617c6",
    "slug": "6a2fa73328c1df4eee4617c6",
    "name": "12292 PCB SANAN 32W 3000K 1,5m 216 led 160Lum/W",
    "code": "A0000015823",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1HRpe71-pXXbNcxVHMlrMbXD7mybbOvvZ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1HRpe71-pXXbNcxVHMlrMbXD7mybbOvvZ&sz=w800"
    ],
    "description": {
      "az": "12292 PCB SANAN 32W 3000K 1,5m 216 led 160Lum/W — Ecolife | Kod: A0000015823",
      "en": "12292 PCB SANAN 32W 3000K 1,5m 216 led 160Lum/W — Ecolife | Code: A0000015823",
      "ru": "12292 PCB SANAN 32W 3000K 1,5m 216 led 160Lum/W — Ecolife | Код: A0000015823"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "32W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94be494caad9d71a415",
    "slug": "6a2fe94be494caad9d71a415",
    "name": "Downlight 20W 3500K COB",
    "code": "A0000012422",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1yjTKELQ4R9MHnV9Wiw4fUrMIf7DANN5X&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1yjTKELQ4R9MHnV9Wiw4fUrMIf7DANN5X&sz=w800"
    ],
    "description": {
      "az": "Downlight 20W 3500K COB — Ecolife | Kod: A0000012422",
      "en": "Downlight 20W 3500K COB — Ecolife | Code: A0000012422",
      "ru": "Downlight 20W 3500K COB — Ecolife | Код: A0000012422"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "20W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266523afd0eddab1a88b41",
    "slug": "6a266523afd0eddab1a88b41",
    "name": "Tracklight 10W 3000K Surface",
    "code": "A0000001503",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1U-DrLpp7vI6csyD4b_DYtGQiWwKmQJZC&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1U-DrLpp7vI6csyD4b_DYtGQiWwKmQJZC&sz=w800"
    ],
    "description": {
      "az": "Tracklight 10W 3000K Surface — Ecolife | Kod: A0000001503",
      "en": "Tracklight 10W 3000K Surface — Ecolife | Code: A0000001503",
      "ru": "Tracklight 10W 3000K Surface — Ecolife | Код: A0000001503"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "10W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a4365180478b7951c0fa4f7",
    "slug": "6a4365180478b7951c0fa4f7",
    "name": "12291 Driver LIFUD 25W/22",
    "code": "A0000015825",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "12291 Driver LIFUD 25W/22 — Ecolife | Kod: A0000015825",
      "en": "12291 Driver LIFUD 25W/22 — Ecolife | Code: A0000015825",
      "ru": "12291 Driver LIFUD 25W/22 — Ecolife | Код: A0000015825"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—",
      "power": "25W"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266507608afa8d3a1202b1",
    "slug": "6a266507608afa8d3a1202b1",
    "name": "Magnetic Acces Spring TH20 RailRecessed 2pc",
    "code": "A0000012463",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1QSwQI-RC6ExjtztlKhKoITEmnrklNd6y&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1QSwQI-RC6ExjtztlKhKoITEmnrklNd6y&sz=w800"
    ],
    "description": {
      "az": "Magnetic Acces Spring TH20 RailRecessed 2pc — Ecolife | Kod: A0000012463",
      "en": "Magnetic Acces Spring TH20 RailRecessed 2pc — Ecolife | Code: A0000012463",
      "ru": "Magnetic Acces Spring TH20 RailRecessed 2pc — Ecolife | Код: A0000012463"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa736f6838310aa14bc24",
    "slug": "6a2fa736f6838310aa14bc24",
    "name": "PCB SR5 OSRAM 5050 5X2W 3000K SET REFLECTOR",
    "code": "A0000000445",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1qqSq0w6B__jTkZN-8qKcYbYp9CS2Lfux&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1qqSq0w6B__jTkZN-8qKcYbYp9CS2Lfux&sz=w800"
    ],
    "description": {
      "az": "PCB SR5 OSRAM 5050 5X2W 3000K SET REFLECTOR — Ecolife | Kod: A0000000445",
      "en": "PCB SR5 OSRAM 5050 5X2W 3000K SET REFLECTOR — Ecolife | Code: A0000000445",
      "ru": "PCB SR5 OSRAM 5050 5X2W 3000K SET REFLECTOR — Ecolife | Код: A0000000445"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "2W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af5191f3c7ff5e3a113",
    "slug": "6a265af5191f3c7ff5e3a113",
    "name": "Panel 24W 4000K Round White 3D",
    "code": "A0000001977",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=10eLysL64-jvxkFPpVTOOKxnDVHXwT1ht&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=10eLysL64-jvxkFPpVTOOKxnDVHXwT1ht&sz=w800"
    ],
    "description": {
      "az": "Panel 24W 4000K Round White 3D — Ecolife | Kod: A0000001977",
      "en": "Panel 24W 4000K Round White 3D — Ecolife | Code: A0000001977",
      "ru": "Panel 24W 4000K Round White 3D — Ecolife | Код: A0000001977"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "24W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665070363ddf73bba2781",
    "slug": "6a2665070363ddf73bba2781",
    "name": "Magnetic Rail 3m",
    "code": "A0000012462",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=10BXpYqD0CpUWi85keE2CbvDcNfFl8kvl&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=10BXpYqD0CpUWi85keE2CbvDcNfFl8kvl&sz=w800"
    ],
    "description": {
      "az": "Magnetic Rail 3m — Ecolife | Kod: A0000012462",
      "en": "Magnetic Rail 3m — Ecolife | Code: A0000012462",
      "ru": "Magnetic Rail 3m — Ecolife | Код: A0000012462"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266506f2cd3efd9c006dbf",
    "slug": "6a266506f2cd3efd9c006dbf",
    "name": "Magnetic Acces Power connector 90°",
    "code": "A0000012466",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=16czGInWvZ4NsUCYo6dbPI7e_TJbj3MIb&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=16czGInWvZ4NsUCYo6dbPI7e_TJbj3MIb&sz=w800"
    ],
    "description": {
      "az": "Magnetic Acces Power connector 90° — Ecolife | Kod: A0000012466",
      "en": "Magnetic Acces Power connector 90° — Ecolife | Code: A0000012466",
      "ru": "Magnetic Acces Power connector 90° — Ecolife | Код: A0000012466"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa737ed09a17a70806ee2",
    "slug": "6a2fa737ed09a17a70806ee2",
    "name": "1500 PCB KIT SANAN 30W 5000K 30sm 40led 150Lum/W",
    "code": "A0000016585",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1j4Sd-rdawaS5Oq0xiuUBygA3XTlq0-0_&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1j4Sd-rdawaS5Oq0xiuUBygA3XTlq0-0_&sz=w800"
    ],
    "description": {
      "az": "1500 PCB KIT SANAN 30W 5000K 30sm 40led 150Lum/W — Ecolife | Kod: A0000016585",
      "en": "1500 PCB KIT SANAN 30W 5000K 30sm 40led 150Lum/W — Ecolife | Code: A0000016585",
      "ru": "1500 PCB KIT SANAN 30W 5000K 30sm 40led 150Lum/W — Ecolife | Код: A0000016585"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "30W",
      "cct": "5000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26650b7eeb162d134b0a52",
    "slug": "6a26650b7eeb162d134b0a52",
    "name": "Magnetic Tracklight Line D30 48V 20W 3500K 25mm",
    "code": "A0000012359",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1elNgQKXP8BDHERSkL7AYYaMTz9OloJJ2&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1elNgQKXP8BDHERSkL7AYYaMTz9OloJJ2&sz=w800"
    ],
    "description": {
      "az": "Magnetic Tracklight Line D30 48V 20W 3500K 25mm — Ecolife | Kod: A0000012359",
      "en": "Magnetic Tracklight Line D30 48V 20W 3500K 25mm — Ecolife | Code: A0000012359",
      "ru": "Magnetic Tracklight Line D30 48V 20W 3500K 25mm — Ecolife | Код: A0000012359"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "20W",
      "cct": "3500K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aef2f35a3a48eccdc0f",
    "slug": "6a265aef2f35a3a48eccdc0f",
    "name": "Panel 32W 4000K Square White 3D Surface",
    "code": "A0000001903",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1JBp5ZC4ErpSB0qymKh0oUkjbjMLG1P--&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1JBp5ZC4ErpSB0qymKh0oUkjbjMLG1P--&sz=w800"
    ],
    "description": {
      "az": "Panel 32W 4000K Square White 3D Surface — Ecolife | Kod: A0000001903",
      "en": "Panel 32W 4000K Square White 3D Surface — Ecolife | Code: A0000001903",
      "ru": "Panel 32W 4000K Square White 3D Surface — Ecolife | Код: A0000001903"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "32W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26651fe602c6485800f0a6",
    "slug": "6a26651fe602c6485800f0a6",
    "name": "Tracklight Rail 2m W",
    "code": "A0000001607",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1Ugmc3O2diWDwpYeL6ChPbU5zwhlb4cGZ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Ugmc3O2diWDwpYeL6ChPbU5zwhlb4cGZ&sz=w800"
    ],
    "description": {
      "az": "Tracklight Rail 2m W — Ecolife | Kod: A0000001607",
      "en": "Tracklight Rail 2m W — Ecolife | Code: A0000001607",
      "ru": "Tracklight Rail 2m W — Ecolife | Код: A0000001607"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b3d8ccf69bf0930d65",
    "slug": "6a26b9b3d8ccf69bf0930d65",
    "name": "LED Bulb 160-240V 3000K E14 6.5W Q45",
    "code": "A0000002039",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1md_LbNofwFy9KxV1grMYHxxIP_wvx4EF&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1md_LbNofwFy9KxV1grMYHxxIP_wvx4EF&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 3000K E14 6.5W Q45 — Ecolife | Kod: A0000002039",
      "en": "LED Bulb 160-240V 3000K E14 6.5W Q45 — Ecolife | Code: A0000002039",
      "ru": "LED Bulb 160-240V 3000K E14 6.5W Q45 — Ecolife | Код: A0000002039"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "6.5W",
      "cct": "3000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a27ef26a6e6d1fcd560b2cd",
    "slug": "6a27ef26a6e6d1fcd560b2cd",
    "name": "Solar Floodlight 1600lumen 4000K",
    "code": "A0000012380",
    "category": "spot-downlight",
    "categoryName": {
      "az": "Spot & Downlight",
      "en": "Spot & Downlight",
      "ru": "Споты и даунлайты"
    },
    "subtitle": {
      "az": "Spot & Downlight",
      "en": "Spot & Downlight",
      "ru": "Споты и даунлайты"
    },
    "image": "https://drive.google.com/thumbnail?id=1s5Uf1RrLbvo-w-K7w7zGuvSBfzBHI7jI&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1s5Uf1RrLbvo-w-K7w7zGuvSBfzBHI7jI&sz=w800"
    ],
    "description": {
      "az": "Solar Floodlight 1600lumen 4000K — Ecolife | Kod: A0000012380",
      "en": "Solar Floodlight 1600lumen 4000K — Ecolife | Code: A0000012380",
      "ru": "Solar Floodlight 1600lumen 4000K — Ecolife | Код: A0000012380"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə / Səthə",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266501873a157342e2f73c",
    "slug": "6a266501873a157342e2f73c",
    "name": "Magnetic TrackLight 06W D11 Motion 4000K",
    "code": "A0000012482",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1im2mtGGeZuCL1T8ZAvh77L_bOVWztDnG&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1im2mtGGeZuCL1T8ZAvh77L_bOVWztDnG&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 06W D11 Motion 4000K — Ecolife | Kod: A0000012482",
      "en": "Magnetic TrackLight 06W D11 Motion 4000K — Ecolife | Code: A0000012482",
      "ru": "Magnetic TrackLight 06W D11 Motion 4000K — Ecolife | Код: A0000012482"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "06W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af0e798794e5d2bf7f8",
    "slug": "6a265af0e798794e5d2bf7f8",
    "name": "Panel 32W 4000K Square White 3D",
    "code": "A0000001986",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1K_bF_2UHG0yGpspIdFl-1hCv80yEq8x0&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1K_bF_2UHG0yGpspIdFl-1hCv80yEq8x0&sz=w800"
    ],
    "description": {
      "az": "Panel 32W 4000K Square White 3D — Ecolife | Kod: A0000001986",
      "en": "Panel 32W 4000K Square White 3D — Ecolife | Code: A0000001986",
      "ru": "Panel 32W 4000K Square White 3D — Ecolife | Код: A0000001986"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "32W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94b5de4b2cc80a0e9c9",
    "slug": "6a2fe94b5de4b2cc80a0e9c9",
    "name": "Downlight 10W 3500K COB",
    "code": "A0000012424",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1CVIqFJCNgS1kUQ45qoZB9Li_KuBxJAmc&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1CVIqFJCNgS1kUQ45qoZB9Li_KuBxJAmc&sz=w800"
    ],
    "description": {
      "az": "Downlight 10W 3500K COB — Ecolife | Kod: A0000012424",
      "en": "Downlight 10W 3500K COB — Ecolife | Code: A0000012424",
      "ru": "Downlight 10W 3500K COB — Ecolife | Код: A0000012424"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94663e695b495597be7",
    "slug": "6a2fe94663e695b495597be7",
    "name": "Downlight 1x7W 3000K Round White Grill",
    "code": "A0000002839",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1X8W6XI-euMdQcjeDfAQb_HcYyLmbJNvL&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1X8W6XI-euMdQcjeDfAQb_HcYyLmbJNvL&sz=w800"
    ],
    "description": {
      "az": "Downlight 1x7W 3000K Round White Grill — Ecolife | Kod: A0000002839",
      "en": "Downlight 1x7W 3000K Round White Grill — Ecolife | Code: A0000002839",
      "ru": "Downlight 1x7W 3000K Round White Grill — Ecolife | Код: A0000002839"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933881cde1d057854339",
    "slug": "6a2f933881cde1d057854339",
    "name": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K IP65",
    "code": "A0000000405",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=15v2bB-qZQgBSsS4l6g4IV2rnTMQv-si-&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=15v2bB-qZQgBSsS4l6g4IV2rnTMQv-si-&sz=w800"
    ],
    "description": {
      "az": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K IP65 — Ecolife | Kod: A0000000405",
      "en": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K IP65 — Ecolife | Code: A0000000405",
      "ru": "Flexstrip EPISTAR 24V 10W 120chip 8mm 6000K IP65 — Ecolife | Код: A0000000405"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP65",
      "mounting": "Yapışqanlı lent",
      "power": "10W",
      "cct": "6000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fb8fa90530570f1d76",
    "slug": "6a2664fb8fa90530570f1d76",
    "name": "Ultra Magnetic Tracklight Line D23 48V 12W 4000K 20mm",
    "code": "A0000001691",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1TnRvEBf8yV4AfDd9I3T0ioOkC1GwOWw0&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1TnRvEBf8yV4AfDd9I3T0ioOkC1GwOWw0&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic Tracklight Line D23 48V 12W 4000K 20mm — Ecolife | Kod: A0000001691",
      "en": "Ultra Magnetic Tracklight Line D23 48V 12W 4000K 20mm — Ecolife | Code: A0000001691",
      "ru": "Ultra Magnetic Tracklight Line D23 48V 12W 4000K 20mm — Ecolife | Код: A0000001691"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "12W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b404a646fce7693632",
    "slug": "6a26b9b404a646fce7693632",
    "name": "LED Bulb 160-240V 4000K E14 6.5W Q45",
    "code": "A0000002055",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1W2eWRCBAyqgK0QbYtkKYtBiIpfzJx0N6&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1W2eWRCBAyqgK0QbYtkKYtBiIpfzJx0N6&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 4000K E14 6.5W Q45 — Ecolife | Kod: A0000002055",
      "en": "LED Bulb 160-240V 4000K E14 6.5W Q45 — Ecolife | Code: A0000002055",
      "ru": "LED Bulb 160-240V 4000K E14 6.5W Q45 — Ecolife | Код: A0000002055"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "6.5W",
      "cct": "4000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b1f6cd864e5c141511",
    "slug": "6a26b9b1f6cd864e5c141511",
    "name": "LED Bulb 160-240V 6000K E27 24W A70",
    "code": "A0000002075",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1s_WU1W6afpW3SdgRyVYmcCCBFVPMEHVC&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1s_WU1W6afpW3SdgRyVYmcCCBFVPMEHVC&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 6000K E27 24W A70 — Ecolife | Kod: A0000002075",
      "en": "LED Bulb 160-240V 6000K E27 24W A70 — Ecolife | Code: A0000002075",
      "ru": "LED Bulb 160-240V 6000K E27 24W A70 — Ecolife | Код: A0000002075"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "24W",
      "cct": "6000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266522a9f17fb2f9a0852b",
    "slug": "6a266522a9f17fb2f9a0852b",
    "name": "Tracklight 20W 3500K W",
    "code": "A0000011766",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=17xpjS_kAxHRqx0PglkFB6nb4hy6vxF7V&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=17xpjS_kAxHRqx0PglkFB6nb4hy6vxF7V&sz=w800"
    ],
    "description": {
      "az": "Tracklight 20W 3500K W — Ecolife | Kod: A0000011766",
      "en": "Tracklight 20W 3500K W — Ecolife | Code: A0000011766",
      "ru": "Tracklight 20W 3500K W — Ecolife | Код: A0000011766"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "20W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af5ae80c46a19e15041",
    "slug": "6a265af5ae80c46a19e15041",
    "name": "Panel Body Round White 3D",
    "code": "A0000002000",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1fNxjYeIBknkroG_EcM84BS8GEMTnBvis&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1fNxjYeIBknkroG_EcM84BS8GEMTnBvis&sz=w800"
    ],
    "description": {
      "az": "Panel Body Round White 3D — Ecolife | Kod: A0000002000",
      "en": "Panel Body Round White 3D — Ecolife | Code: A0000002000",
      "ru": "Panel Body Round White 3D — Ecolife | Код: A0000002000"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665065bb1eeddbcbf2d0c",
    "slug": "6a2665065bb1eeddbcbf2d0c",
    "name": "Magnetic Acces Power connector line",
    "code": "A0000012465",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1BdzbER353LGdHNNUZLRahT_1BhvDe7bi&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1BdzbER353LGdHNNUZLRahT_1BhvDe7bi&sz=w800"
    ],
    "description": {
      "az": "Magnetic Acces Power connector line — Ecolife | Kod: A0000012465",
      "en": "Magnetic Acces Power connector line — Ecolife | Code: A0000012465",
      "ru": "Magnetic Acces Power connector line — Ecolife | Код: A0000012465"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9554aebb05b9e2309e7",
    "slug": "6a2fe9554aebb05b9e2309e7",
    "name": "Downlight 07W 3000K COB",
    "code": "A0000015611",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1hPQos47qy2yclegzL5Dsh35bc09jqXOe&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1hPQos47qy2yclegzL5Dsh35bc09jqXOe&sz=w800"
    ],
    "description": {
      "az": "Downlight 07W 3000K COB — Ecolife | Kod: A0000015611",
      "en": "Downlight 07W 3000K COB — Ecolife | Code: A0000015611",
      "ru": "Downlight 07W 3000K COB — Ecolife | Код: A0000015611"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "07W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664f95fe26ca8000c41d4",
    "slug": "6a2664f95fe26ca8000c41d4",
    "name": "Ultra Magnetic PowerConnector 90°",
    "code": "A0000001682",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=19qb_t0Y4ayCEjJtFW_k0-LUXAWUyZx1d&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=19qb_t0Y4ayCEjJtFW_k0-LUXAWUyZx1d&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic PowerConnector 90° — Ecolife | Kod: A0000001682",
      "en": "Ultra Magnetic PowerConnector 90° — Ecolife | Code: A0000001682",
      "ru": "Ultra Magnetic PowerConnector 90° — Ecolife | Код: A0000001682"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651e3dd53e793da38178",
    "slug": "6a43651e3dd53e793da38178",
    "name": "DRIVER 24V 600W 25A IP21",
    "code": "A0000000589",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 600W 25A IP21 — Ecolife | Kod: A0000000589",
      "en": "DRIVER 24V 600W 25A IP21 — Ecolife | Code: A0000000589",
      "ru": "DRIVER 24V 600W 25A IP21 — Ecolife | Код: A0000000589"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "600W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a27ef1d232e87ea45630b89",
    "slug": "6a27ef1d232e87ea45630b89",
    "name": "HighBay 200W 6500K 160lum/w PF>0.9 IP65",
    "code": "A0000012386",
    "category": "decorative",
    "categoryName": {
      "az": "Dekorativ",
      "en": "Decorative",
      "ru": "Декоративные"
    },
    "subtitle": {
      "az": "Dekorativ",
      "en": "Decorative",
      "ru": "Декоративные"
    },
    "image": "https://drive.google.com/thumbnail?id=1mnCdgm4v0cJxeNRx5svIFUmpa1Xe_DcM&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1mnCdgm4v0cJxeNRx5svIFUmpa1Xe_DcM&sz=w800"
    ],
    "description": {
      "az": "HighBay 200W 6500K 160lum/w PF>0.9 IP65 — Ecolife | Kod: A0000012386",
      "en": "HighBay 200W 6500K 160lum/w PF>0.9 IP65 — Ecolife | Code: A0000012386",
      "ru": "HighBay 200W 6500K 160lum/w PF>0.9 IP65 — Ecolife | Код: A0000012386"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP65",
      "mounting": "Səthə / Asma",
      "power": "200W",
      "cct": "6500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b316c022d8ba79a018",
    "slug": "6a26b9b316c022d8ba79a018",
    "name": "LED Bulb 160-240V 3000K E27 20W A60",
    "code": "A0000002046",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1Y6qMmkDCbksFB1qo_Wxd19zxFJjwGPYc&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Y6qMmkDCbksFB1qo_Wxd19zxFJjwGPYc&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 3000K E27 20W A60 — Ecolife | Kod: A0000002046",
      "en": "LED Bulb 160-240V 3000K E27 20W A60 — Ecolife | Code: A0000002046",
      "ru": "LED Bulb 160-240V 3000K E27 20W A60 — Ecolife | Код: A0000002046"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "20W",
      "cct": "3000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266508500d7dcf28e0fdc0",
    "slug": "6a266508500d7dcf28e0fdc0",
    "name": "Magnetic Rail 3m Surface hanging",
    "code": "A0000012460",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1c-P4yh5Gghkg6L7lvb2vatGFSbbM2xpC&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1c-P4yh5Gghkg6L7lvb2vatGFSbbM2xpC&sz=w800"
    ],
    "description": {
      "az": "Magnetic Rail 3m Surface hanging — Ecolife | Kod: A0000012460",
      "en": "Magnetic Rail 3m Surface hanging — Ecolife | Code: A0000012460",
      "ru": "Magnetic Rail 3m Surface hanging — Ecolife | Код: A0000012460"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266502517b7c250cc3214a",
    "slug": "6a266502517b7c250cc3214a",
    "name": "Magnetic TrackLight 18W 4000K Reflrctor Motion",
    "code": "A0000012479",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1Azm8t1c7MlRyT_3-3uNXzMoIMm2iSuT9&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Azm8t1c7MlRyT_3-3uNXzMoIMm2iSuT9&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 18W 4000K Reflrctor Motion — Ecolife | Kod: A0000012479",
      "en": "Magnetic TrackLight 18W 4000K Reflrctor Motion — Ecolife | Code: A0000012479",
      "ru": "Magnetic TrackLight 18W 4000K Reflrctor Motion — Ecolife | Код: A0000012479"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "18W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b233db8c9c0422018a",
    "slug": "6a26b9b233db8c9c0422018a",
    "name": "LED Bulb 160-240V 4000K E27 8W Q45",
    "code": "A0000002061",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1YQxRqiJJbzk-7_noRjXxJO5Pa74RX5Li&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1YQxRqiJJbzk-7_noRjXxJO5Pa74RX5Li&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 4000K E27 8W Q45 — Ecolife | Kod: A0000002061",
      "en": "LED Bulb 160-240V 4000K E27 8W Q45 — Ecolife | Code: A0000002061",
      "ru": "LED Bulb 160-240V 4000K E27 8W Q45 — Ecolife | Код: A0000002061"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "8W",
      "cct": "4000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665213b8e9bec5c637099",
    "slug": "6a2665213b8e9bec5c637099",
    "name": "Tracklight 30W 4000K WHITE",
    "code": "A0000016405",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=11kWc4bNhBDEZFP50_s-pSJp3uBs2aG7N&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=11kWc4bNhBDEZFP50_s-pSJp3uBs2aG7N&sz=w800"
    ],
    "description": {
      "az": "Tracklight 30W 4000K WHITE — Ecolife | Kod: A0000016405",
      "en": "Tracklight 30W 4000K WHITE — Ecolife | Code: A0000016405",
      "ru": "Tracklight 30W 4000K WHITE — Ecolife | Код: A0000016405"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "30W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa736ec78095d0f6d0906",
    "slug": "6a2fa736ec78095d0f6d0906",
    "name": "PCB SR5 OSRAM 3535 5X2W 4000K SET REFLECTOR",
    "code": "A0000000442",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=18PgNyEeuuGUQAcPsJcutQl7-QP8A3TbD&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=18PgNyEeuuGUQAcPsJcutQl7-QP8A3TbD&sz=w800"
    ],
    "description": {
      "az": "PCB SR5 OSRAM 3535 5X2W 4000K SET REFLECTOR — Ecolife | Kod: A0000000442",
      "en": "PCB SR5 OSRAM 3535 5X2W 4000K SET REFLECTOR — Ecolife | Code: A0000000442",
      "ru": "PCB SR5 OSRAM 3535 5X2W 4000K SET REFLECTOR — Ecolife | Код: A0000000442"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "2W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fb9fc41cbcb168743b",
    "slug": "6a2664fb9fc41cbcb168743b",
    "name": "Ultra Magnetic Tracklight SR12 48V 12W 4000K 20mm",
    "code": "A0000001689",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1qNG0xF69SycFkq9jcYN3nGL2Bl9muxIk&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1qNG0xF69SycFkq9jcYN3nGL2Bl9muxIk&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic Tracklight SR12 48V 12W 4000K 20mm — Ecolife | Kod: A0000001689",
      "en": "Ultra Magnetic Tracklight SR12 48V 12W 4000K 20mm — Ecolife | Code: A0000001689",
      "ru": "Ultra Magnetic Tracklight SR12 48V 12W 4000K 20mm — Ecolife | Код: A0000001689"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "12W",
      "cct": "4000K",
      "voltage": "48V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe953a7ca55149bb9d3d1",
    "slug": "6a2fe953a7ca55149bb9d3d1",
    "name": "Downlight 30W 4000K COB",
    "code": "A0000015630",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1c4cm6shRC89bzuAKn9NZXyqDkl7Cysai&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1c4cm6shRC89bzuAKn9NZXyqDkl7Cysai&sz=w800"
    ],
    "description": {
      "az": "Downlight 30W 4000K COB — Ecolife | Kod: A0000015630",
      "en": "Downlight 30W 4000K COB — Ecolife | Code: A0000015630",
      "ru": "Downlight 30W 4000K COB — Ecolife | Код: A0000015630"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "30W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933757904e0f9be04c18",
    "slug": "6a2f933757904e0f9be04c18",
    "name": "Flexstrip EPISTAR 24V 10W 3000K 336chip COB",
    "code": "A0000000408",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=10T91WUllJp47EbN224r2pif_998rt1Lx&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=10T91WUllJp47EbN224r2pif_998rt1Lx&sz=w800"
    ],
    "description": {
      "az": "Flexstrip EPISTAR 24V 10W 3000K 336chip COB — Ecolife | Kod: A0000000408",
      "en": "Flexstrip EPISTAR 24V 10W 3000K 336chip COB — Ecolife | Code: A0000000408",
      "ru": "Flexstrip EPISTAR 24V 10W 3000K 336chip COB — Ecolife | Код: A0000000408"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "10W",
      "cct": "3000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe948c10ee49e9727a83f",
    "slug": "6a2fe948c10ee49e9727a83f",
    "name": "Downlight 10W 3000K Round White Cylinder",
    "code": "A0000002387",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1LZA4D_cVY1A0qlJUt9wxPdI03Gwf2DQb&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1LZA4D_cVY1A0qlJUt9wxPdI03Gwf2DQb&sz=w800"
    ],
    "description": {
      "az": "Downlight 10W 3000K Round White Cylinder — Ecolife | Kod: A0000002387",
      "en": "Downlight 10W 3000K Round White Cylinder — Ecolife | Code: A0000002387",
      "ru": "Downlight 10W 3000K Round White Cylinder — Ecolife | Код: A0000002387"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a43651f2ceabdea249d162d",
    "slug": "6a43651f2ceabdea249d162d",
    "name": "DRIVER 24V 400W 16,67A IP21",
    "code": "A0000000585",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "DRIVER 24V 400W 16,67A IP21 — Ecolife | Kod: A0000000585",
      "en": "DRIVER 24V 400W 16,67A IP21 — Ecolife | Code: A0000000585",
      "ru": "DRIVER 24V 400W 16,67A IP21 — Ecolife | Код: A0000000585"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP21",
      "mounting": "—",
      "power": "400W",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94973aee1fbef312447",
    "slug": "6a2fe94973aee1fbef312447",
    "name": "Downlight 2x10W 3000K Square White Grill",
    "code": "A0000002356",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1ptV650Ix1l7OKT5xgCh4TVBFxb5lZTjD&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1ptV650Ix1l7OKT5xgCh4TVBFxb5lZTjD&sz=w800"
    ],
    "description": {
      "az": "Downlight 2x10W 3000K Square White Grill — Ecolife | Kod: A0000002356",
      "en": "Downlight 2x10W 3000K Square White Grill — Ecolife | Code: A0000002356",
      "ru": "Downlight 2x10W 3000K Square White Grill — Ecolife | Код: A0000002356"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a266524c7df0058e7144b6c",
    "slug": "6a266524c7df0058e7144b6c",
    "name": "Tracklight Rail 2m B",
    "code": "A0000001600",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1UQvTgUzekSlUcwLYUbyXh62i3t0LbxXB&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1UQvTgUzekSlUcwLYUbyXh62i3t0LbxXB&sz=w800"
    ],
    "description": {
      "az": "Tracklight Rail 2m B — Ecolife | Kod: A0000001600",
      "en": "Tracklight Rail 2m B — Ecolife | Code: A0000001600",
      "ru": "Tracklight Rail 2m B — Ecolife | Код: A0000001600"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94e18fc13fd3d2db93a",
    "slug": "6a2fe94e18fc13fd3d2db93a",
    "name": "Downlight 1xGU10 Round Black Cylinder",
    "code": "A0000002275",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1D_ZL4A8uzYHXzkvC5R7hPZ17w8APJKRS&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1D_ZL4A8uzYHXzkvC5R7hPZ17w8APJKRS&sz=w800"
    ],
    "description": {
      "az": "Downlight 1xGU10 Round Black Cylinder — Ecolife | Kod: A0000002275",
      "en": "Downlight 1xGU10 Round Black Cylinder — Ecolife | Code: A0000002275",
      "ru": "Downlight 1xGU10 Round Black Cylinder — Ecolife | Код: A0000002275"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe952548180afb02ad5c7",
    "slug": "6a2fe952548180afb02ad5c7",
    "name": "Downlight 16W 6000K Square White",
    "code": "A0000002651",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1N4Oo05BDWLHauxna9q5L22KtQfCrUEJG&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1N4Oo05BDWLHauxna9q5L22KtQfCrUEJG&sz=w800"
    ],
    "description": {
      "az": "Downlight 16W 6000K Square White — Ecolife | Kod: A0000002651",
      "en": "Downlight 16W 6000K Square White — Ecolife | Code: A0000002651",
      "ru": "Downlight 16W 6000K Square White — Ecolife | Код: A0000002651"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "16W",
      "cct": "6000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fb0f5ccae944883b120d3",
    "slug": "6a2fb0f5ccae944883b120d3",
    "name": "PCB EPISTAR 110V 18W 96 chip 3000K 112cm",
    "code": "A0000000436",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=12voeNd_337AXEe_ZUhcIzz1dc-Da9OtQ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=12voeNd_337AXEe_ZUhcIzz1dc-Da9OtQ&sz=w800"
    ],
    "description": {
      "az": "PCB EPISTAR 110V 18W 96 chip 3000K 112cm — Ecolife | Kod: A0000000436",
      "en": "PCB EPISTAR 110V 18W 96 chip 3000K 112cm — Ecolife | Code: A0000000436",
      "ru": "PCB EPISTAR 110V 18W 96 chip 3000K 112cm — Ecolife | Код: A0000000436"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "18W",
      "cct": "3000K",
      "voltage": "110V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f9334b01f434a739b5d56",
    "slug": "6a2f9334b01f434a739b5d56",
    "name": "Flexstrip OSRAM 6W 24V 4000K 60 chip ZIG-ZAG",
    "code": "A0000000428",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "Flexstrip OSRAM 6W 24V 4000K 60 chip ZIG-ZAG — Ecolife | Kod: A0000000428",
      "en": "Flexstrip OSRAM 6W 24V 4000K 60 chip ZIG-ZAG — Ecolife | Code: A0000000428",
      "ru": "Flexstrip OSRAM 6W 24V 4000K 60 chip ZIG-ZAG — Ecolife | Код: A0000000428"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "6W",
      "cct": "4000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265fc8811d8a06edfda0a2",
    "slug": "6a265fc8811d8a06edfda0a2",
    "name": "ECL_WNG/A576",
    "code": "A0000000576",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://drive.google.com/thumbnail?id=16rD-SQyY0j76AGt25ot6zzd-Vso0usXV&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=16rD-SQyY0j76AGt25ot6zzd-Vso0usXV&sz=w800"
    ],
    "description": {
      "az": "ECL_WNG/A576 — Ecolife | Kod: A0000000576",
      "en": "ECL_WNG/A576 — Ecolife | Code: A0000000576",
      "ru": "ECL_WNG/A576 — Ecolife | Код: A0000000576"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933b72a77d998d4a933a",
    "slug": "6a2f933b72a77d998d4a933a",
    "name": "Flexstrip EPISTAR 24V 18W 48chip 10mm 4000K ONE STEP LENS",
    "code": "A0000012398",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1pw1j6VcAwTvlqN4tM__ZxHbH7wXiIwHv&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1pw1j6VcAwTvlqN4tM__ZxHbH7wXiIwHv&sz=w800"
    ],
    "description": {
      "az": "Flexstrip EPISTAR 24V 18W 48chip 10mm 4000K ONE STEP LENS — Ecolife | Kod: A0000012398",
      "en": "Flexstrip EPISTAR 24V 18W 48chip 10mm 4000K ONE STEP LENS — Ecolife | Code: A0000012398",
      "ru": "Flexstrip EPISTAR 24V 18W 48chip 10mm 4000K ONE STEP LENS — Ecolife | Код: A0000012398"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "18W",
      "cct": "4000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933732fa2b36cc2715df",
    "slug": "6a2f933732fa2b36cc2715df",
    "name": "Flexstrip OSRAM 24V 20W 4000K 120chip 2OZ 10MM",
    "code": "A0000011555",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1aKhIt1X_9BU6EyhZlVV3wIEeTYGUXfsr&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1aKhIt1X_9BU6EyhZlVV3wIEeTYGUXfsr&sz=w800"
    ],
    "description": {
      "az": "Flexstrip OSRAM 24V 20W 4000K 120chip 2OZ 10MM — Ecolife | Kod: A0000011555",
      "en": "Flexstrip OSRAM 24V 20W 4000K 120chip 2OZ 10MM — Ecolife | Code: A0000011555",
      "ru": "Flexstrip OSRAM 24V 20W 4000K 120chip 2OZ 10MM — Ecolife | Код: A0000011555"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "20W",
      "cct": "4000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b20a5b74870d2bd42f",
    "slug": "6a26b9b20a5b74870d2bd42f",
    "name": "LED Bulb 160-240V 4000K E27 45W T100",
    "code": "A0000002059",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1_GR8stUehrBimcBoKZMsBkr9AAYFJNnb&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1_GR8stUehrBimcBoKZMsBkr9AAYFJNnb&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 4000K E27 45W T100 — Ecolife | Kod: A0000002059",
      "en": "LED Bulb 160-240V 4000K E27 45W T100 — Ecolife | Code: A0000002059",
      "ru": "LED Bulb 160-240V 4000K E27 45W T100 — Ecolife | Код: A0000002059"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "45W",
      "cct": "4000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94a065b06daafcd36ac",
    "slug": "6a2fe94a065b06daafcd36ac",
    "name": "Downlight 7W 3500K Round White NEW",
    "code": "A0000002256",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1iyGQj991wEuy8AJqYQPW6IkviaEPuv73&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1iyGQj991wEuy8AJqYQPW6IkviaEPuv73&sz=w800"
    ],
    "description": {
      "az": "Downlight 7W 3500K Round White NEW — Ecolife | Kod: A0000002256",
      "en": "Downlight 7W 3500K Round White NEW — Ecolife | Code: A0000002256",
      "ru": "Downlight 7W 3500K Round White NEW — Ecolife | Код: A0000002256"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b3551b20663c292c30",
    "slug": "6a26b9b3551b20663c292c30",
    "name": "LED Bulb 160-240V 3000K E27 16W A60",
    "code": "A0000002045",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1HHXltOZjFl1iFuJyDNHN75aYjPtNcMrU&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1HHXltOZjFl1iFuJyDNHN75aYjPtNcMrU&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 3000K E27 16W A60 — Ecolife | Kod: A0000002045",
      "en": "LED Bulb 160-240V 3000K E27 16W A60 — Ecolife | Code: A0000002045",
      "ru": "LED Bulb 160-240V 3000K E27 16W A60 — Ecolife | Код: A0000002045"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "16W",
      "cct": "3000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af382b54259134e6d6f",
    "slug": "6a265af382b54259134e6d6f",
    "name": "Panel 60W 6500K 595x595 Backlit",
    "code": "A0000016391",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1oHwtqvOfYRQnHsqSCiSZR_t2e5N5dQjd&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1oHwtqvOfYRQnHsqSCiSZR_t2e5N5dQjd&sz=w800"
    ],
    "description": {
      "az": "Panel 60W 6500K 595x595 Backlit — Ecolife | Kod: A0000016391",
      "en": "Panel 60W 6500K 595x595 Backlit — Ecolife | Code: A0000016391",
      "ru": "Panel 60W 6500K 595x595 Backlit — Ecolife | Код: A0000016391"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "60W",
      "cct": "6500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b0e7ae489a8e1a47df",
    "slug": "6a26b9b0e7ae489a8e1a47df",
    "name": "LED Candle 160-240V 3000K E27 8W C37 Sharp",
    "code": "A0000002107",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1HuxGc7fOtAEUmJlVSP_oDToIzYNZJceo&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1HuxGc7fOtAEUmJlVSP_oDToIzYNZJceo&sz=w800"
    ],
    "description": {
      "az": "LED Candle 160-240V 3000K E27 8W C37 Sharp — Ecolife | Kod: A0000002107",
      "en": "LED Candle 160-240V 3000K E27 8W C37 Sharp — Ecolife | Code: A0000002107",
      "ru": "LED Candle 160-240V 3000K E27 8W C37 Sharp — Ecolife | Код: A0000002107"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "8W",
      "cct": "3000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9513dbd31cfa07e390f",
    "slug": "6a2fe9513dbd31cfa07e390f",
    "name": "Downlight 1xGU10 Square Black",
    "code": "A0000002269",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1Veyv1QFV-54ikdA0C8Rd2xSLFUGXLedb&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Veyv1QFV-54ikdA0C8Rd2xSLFUGXLedb&sz=w800"
    ],
    "description": {
      "az": "Downlight 1xGU10 Square Black — Ecolife | Kod: A0000002269",
      "en": "Downlight 1xGU10 Square Black — Ecolife | Code: A0000002269",
      "ru": "Downlight 1xGU10 Square Black — Ecolife | Код: A0000002269"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b4f702c0fd83b8f274",
    "slug": "6a26b9b4f702c0fd83b8f274",
    "name": "LED Bulb 160-240V 6000K E27 20W A60",
    "code": "A0000002073",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1-dCjbxkCiCTDzLW4PtTbLd1ryJHgy_ga&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1-dCjbxkCiCTDzLW4PtTbLd1ryJHgy_ga&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 6000K E27 20W A60 — Ecolife | Kod: A0000002073",
      "en": "LED Bulb 160-240V 6000K E27 20W A60 — Ecolife | Code: A0000002073",
      "ru": "LED Bulb 160-240V 6000K E27 20W A60 — Ecolife | Код: A0000002073"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "20W",
      "cct": "6000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94de600420c6f454072",
    "slug": "6a2fe94de600420c6f454072",
    "name": "Downlight GU10 Round White",
    "code": "A0000002215",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=11r6dxVxQBdRbX-g5KPBpIK0GhbF3TXpx&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=11r6dxVxQBdRbX-g5KPBpIK0GhbF3TXpx&sz=w800"
    ],
    "description": {
      "az": "Downlight GU10 Round White — Ecolife | Kod: A0000002215",
      "en": "Downlight GU10 Round White — Ecolife | Code: A0000002215",
      "ru": "Downlight GU10 Round White — Ecolife | Код: A0000002215"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe9523b623b6d238407ba",
    "slug": "6a2fe9523b623b6d238407ba",
    "name": "Downlight 2xGU10 Square Black",
    "code": "A0000002270",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1ICvRIJl-ck0YULdg5iDJhVLjkOmoZhfy&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1ICvRIJl-ck0YULdg5iDJhVLjkOmoZhfy&sz=w800"
    ],
    "description": {
      "az": "Downlight 2xGU10 Square Black — Ecolife | Kod: A0000002270",
      "en": "Downlight 2xGU10 Square Black — Ecolife | Code: A0000002270",
      "ru": "Downlight 2xGU10 Square Black — Ecolife | Код: A0000002270"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94db2504b54dac51980",
    "slug": "6a2fe94db2504b54dac51980",
    "name": "Downlight 25W 3000K Round Black Cylinder",
    "code": "A0000002418",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1--64VRVKTgRAStbQw5-vhJrYWS5Nrzlf&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1--64VRVKTgRAStbQw5-vhJrYWS5Nrzlf&sz=w800"
    ],
    "description": {
      "az": "Downlight 25W 3000K Round Black Cylinder — Ecolife | Kod: A0000002418",
      "en": "Downlight 25W 3000K Round Black Cylinder — Ecolife | Code: A0000002418",
      "ru": "Downlight 25W 3000K Round Black Cylinder — Ecolife | Код: A0000002418"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "25W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a0ecdb547ac54b2885cf481",
    "slug": "6a0ecdb547ac54b2885cf481",
    "name": "ECL_TINA/A16392",
    "code": "A0000016392",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1JoCxEfgUGDq_ipm9g6bYN_H6TsJelUko&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1JoCxEfgUGDq_ipm9g6bYN_H6TsJelUko&sz=w800"
    ],
    "description": {
      "az": "ECL_TINA/A16392 — Ecolife | Kod: A0000016392",
      "en": "ECL_TINA/A16392 — Ecolife | Code: A0000016392",
      "ru": "ECL_TINA/A16392 — Ecolife | Код: A0000016392"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa73783d2a9cd0dc8eb5f",
    "slug": "6a2fa73783d2a9cd0dc8eb5f",
    "name": "PCB SAMSUNG 7020 24V 24W 6000K 90*2 100sm",
    "code": "A0000000440",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=1w6PoGON0QmBJvw8SNeZNbe2Zg_For65I&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1w6PoGON0QmBJvw8SNeZNbe2Zg_For65I&sz=w800"
    ],
    "description": {
      "az": "PCB SAMSUNG 7020 24V 24W 6000K 90*2 100sm — Ecolife | Kod: A0000000440",
      "en": "PCB SAMSUNG 7020 24V 24W 6000K 90*2 100sm — Ecolife | Code: A0000000440",
      "ru": "PCB SAMSUNG 7020 24V 24W 6000K 90*2 100sm — Ecolife | Код: A0000000440"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "24W",
      "cct": "6000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b6ce1c55ad5117fa67",
    "slug": "6a26b9b6ce1c55ad5117fa67",
    "name": "LED Bulb 160-240V 6000K E27 12W R80",
    "code": "A0000002069",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1JASAbI4uS9QYrZsYHduel_PE5S_CX1W-&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1JASAbI4uS9QYrZsYHduel_PE5S_CX1W-&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 6000K E27 12W R80 — Ecolife | Kod: A0000002069",
      "en": "LED Bulb 160-240V 6000K E27 12W R80 — Ecolife | Code: A0000002069",
      "ru": "LED Bulb 160-240V 6000K E27 12W R80 — Ecolife | Код: A0000002069"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "12W",
      "cct": "6000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94da365b87123f2e3bd",
    "slug": "6a2fe94da365b87123f2e3bd",
    "name": "Downlight 1x7W 3000K Square Black Grill",
    "code": "A0000002837",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1BEAJE04GklmJV2rO0kGtej3i4D0E65k-&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1BEAJE04GklmJV2rO0kGtej3i4D0E65k-&sz=w800"
    ],
    "description": {
      "az": "Downlight 1x7W 3000K Square Black Grill — Ecolife | Kod: A0000002837",
      "en": "Downlight 1x7W 3000K Square Black Grill — Ecolife | Code: A0000002837",
      "ru": "Downlight 1x7W 3000K Square Black Grill — Ecolife | Код: A0000002837"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "7W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94c4b4d3c2ff21af945",
    "slug": "6a2fe94c4b4d3c2ff21af945",
    "name": "Downlight 10W 3500K Round Black Cylinder",
    "code": "A0000002388",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1YDAiL74PEgLMpLBBpo_QMJ9xnP1hrd2Y&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1YDAiL74PEgLMpLBBpo_QMJ9xnP1hrd2Y&sz=w800"
    ],
    "description": {
      "az": "Downlight 10W 3500K Round Black Cylinder — Ecolife | Kod: A0000002388",
      "en": "Downlight 10W 3500K Round Black Cylinder — Ecolife | Code: A0000002388",
      "ru": "Downlight 10W 3500K Round Black Cylinder — Ecolife | Код: A0000002388"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "10W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94f112bc6a4e80d7251",
    "slug": "6a2fe94f112bc6a4e80d7251",
    "name": "Downlight 1xGU10 Round White+Black",
    "code": "A0000002263",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1F0WXr8Y2fpBsA1f4oEZJK6j0f5pZiiKr&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1F0WXr8Y2fpBsA1f4oEZJK6j0f5pZiiKr&sz=w800"
    ],
    "description": {
      "az": "Downlight 1xGU10 Round White+Black — Ecolife | Kod: A0000002263",
      "en": "Downlight 1xGU10 Round White+Black — Ecolife | Code: A0000002263",
      "ru": "Downlight 1xGU10 Round White+Black — Ecolife | Код: A0000002263"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a0ecdb4de3e3aa048ad9bda",
    "slug": "6a0ecdb4de3e3aa048ad9bda",
    "name": "ECL_EVR/A12387_TP17-50W",
    "code": "A0000012387",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=15HAFLepSR18kN6qkAGVg33vL2iDASoh_&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=15HAFLepSR18kN6qkAGVg33vL2iDASoh_&sz=w800"
    ],
    "description": {
      "az": "ECL_EVR/A12387_TP17-50W — Ecolife | Kod: A0000012387",
      "en": "ECL_EVR/A12387_TP17-50W — Ecolife | Code: A0000012387",
      "ru": "ECL_EVR/A12387_TP17-50W — Ecolife | Код: A0000012387"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "50W"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aecee722993b6d6fd9f",
    "slug": "6a265aecee722993b6d6fd9f",
    "name": "Panel 60W 5000K Square White 595x595 Backlit",
    "code": "A0000011724",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1jvxVGIt_57oSJ1s2_6zafm6y3S-YENh3&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1jvxVGIt_57oSJ1s2_6zafm6y3S-YENh3&sz=w800"
    ],
    "description": {
      "az": "Panel 60W 5000K Square White 595x595 Backlit — Ecolife | Kod: A0000011724",
      "en": "Panel 60W 5000K Square White 595x595 Backlit — Ecolife | Code: A0000011724",
      "ru": "Panel 60W 5000K Square White 595x595 Backlit — Ecolife | Код: A0000011724"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "60W",
      "cct": "5000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f9339cc6ad9f93de35fc1",
    "slug": "6a2f9339cc6ad9f93de35fc1",
    "name": "Flexstrip 24V 18W 240chip 3OZ 10MM 4000K",
    "code": "A0000000434",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1I_rYmNJl0vkeEBgKsKvO7_iOkFWmO5Uf&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1I_rYmNJl0vkeEBgKsKvO7_iOkFWmO5Uf&sz=w800"
    ],
    "description": {
      "az": "Flexstrip 24V 18W 240chip 3OZ 10MM 4000K — Ecolife | Kod: A0000000434",
      "en": "Flexstrip 24V 18W 240chip 3OZ 10MM 4000K — Ecolife | Code: A0000000434",
      "ru": "Flexstrip 24V 18W 240chip 3OZ 10MM 4000K — Ecolife | Код: A0000000434"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "18W",
      "cct": "4000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9ad924ec118b0640a19",
    "slug": "6a26b9ad924ec118b0640a19",
    "name": "SpotModul 8W 3500K for GU10",
    "code": "A0000012433",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1kj6A5BYo8chrctRy8c3OyXY-ssUaaM37&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1kj6A5BYo8chrctRy8c3OyXY-ssUaaM37&sz=w800"
    ],
    "description": {
      "az": "SpotModul 8W 3500K for GU10 — Ecolife | Kod: A0000012433",
      "en": "SpotModul 8W 3500K for GU10 — Ecolife | Code: A0000012433",
      "ru": "SpotModul 8W 3500K for GU10 — Ecolife | Код: A0000012433"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "8W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe950599ffc93917fe41c",
    "slug": "6a2fe950599ffc93917fe41c",
    "name": "Downlight 1xGU10 Square White",
    "code": "A0000002268",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1NY5pZJx03BZ0-zIcI3SyvP1n-9ZQ0rpt&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1NY5pZJx03BZ0-zIcI3SyvP1n-9ZQ0rpt&sz=w800"
    ],
    "description": {
      "az": "Downlight 1xGU10 Square White — Ecolife | Kod: A0000002268",
      "en": "Downlight 1xGU10 Square White — Ecolife | Code: A0000002268",
      "ru": "Downlight 1xGU10 Square White — Ecolife | Код: A0000002268"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b163b30d7cf911be53",
    "slug": "6a26b9b163b30d7cf911be53",
    "name": "LED Candle 160-240V 3000K E14 9W C37 Filament Sharp",
    "code": "A0000002105",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1duWrOcmkZnOmPWlsmZHeiJU1nqQTV64g&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1duWrOcmkZnOmPWlsmZHeiJU1nqQTV64g&sz=w800"
    ],
    "description": {
      "az": "LED Candle 160-240V 3000K E14 9W C37 Filament Sharp — Ecolife | Kod: A0000002105",
      "en": "LED Candle 160-240V 3000K E14 9W C37 Filament Sharp — Ecolife | Code: A0000002105",
      "ru": "LED Candle 160-240V 3000K E14 9W C37 Filament Sharp — Ecolife | Код: A0000002105"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "9W",
      "cct": "3000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f933996cf19df9965eb68",
    "slug": "6a2f933996cf19df9965eb68",
    "name": "Flexstrip 12V 18W 240chip 3OZ 10MM 4000K",
    "code": "A0000000432",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=14Oh7Rhw0krMLnpggXuHmCgULzeMkPsFo&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=14Oh7Rhw0krMLnpggXuHmCgULzeMkPsFo&sz=w800"
    ],
    "description": {
      "az": "Flexstrip 12V 18W 240chip 3OZ 10MM 4000K — Ecolife | Kod: A0000000432",
      "en": "Flexstrip 12V 18W 240chip 3OZ 10MM 4000K — Ecolife | Code: A0000000432",
      "ru": "Flexstrip 12V 18W 240chip 3OZ 10MM 4000K — Ecolife | Код: A0000000432"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "18W",
      "cct": "4000K",
      "voltage": "12V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe94aa6eecc4e29331db1",
    "slug": "6a2fe94aa6eecc4e29331db1",
    "name": "Downlight 07W 3500K COB",
    "code": "A0000012426",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=189FSp5RbalkrzSh3w45a4TwTJl_30HCG&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=189FSp5RbalkrzSh3w45a4TwTJl_30HCG&sz=w800"
    ],
    "description": {
      "az": "Downlight 07W 3500K COB — Ecolife | Kod: A0000012426",
      "en": "Downlight 07W 3500K COB — Ecolife | Code: A0000012426",
      "ru": "Downlight 07W 3500K COB — Ecolife | Код: A0000012426"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində",
      "power": "07W",
      "cct": "3500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a4365171081baffd4aca8a3",
    "slug": "6a4365171081baffd4aca8a3",
    "name": "Dimmer 12/24 DC Air control+2colors",
    "code": "A0000000483",
    "category": "drivers",
    "categoryName": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "subtitle": {
      "az": "Driver",
      "en": "Drivers",
      "ru": "Блоки питания"
    },
    "image": "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1000&q=80"
    ],
    "description": {
      "az": "Dimmer 12/24 DC Air control+2colors — Ecolife | Kod: A0000000483",
      "en": "Dimmer 12/24 DC Air control+2colors — Ecolife | Code: A0000000483",
      "ru": "Dimmer 12/24 DC Air control+2colors — Ecolife | Код: A0000000483"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "—"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a26b9b5430694be889faf34",
    "slug": "6a26b9b5430694be889faf34",
    "name": "LED Bulb 160-240V 6000K 15W E27 A60",
    "code": "A0000002065",
    "category": "bulbs",
    "categoryName": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "subtitle": {
      "az": "Lampalar",
      "en": "Bulbs",
      "ru": "Лампы"
    },
    "image": "https://drive.google.com/thumbnail?id=1ABQvB2_ny0mxuBLDSuj0qLcFhxnDRdt2&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1ABQvB2_ny0mxuBLDSuj0qLcFhxnDRdt2&sz=w800"
    ],
    "description": {
      "az": "LED Bulb 160-240V 6000K 15W E27 A60 — Ecolife | Kod: A0000002065",
      "en": "LED Bulb 160-240V 6000K 15W E27 A60 — Ecolife | Code: A0000002065",
      "ru": "LED Bulb 160-240V 6000K 15W E27 A60 — Ecolife | Код: A0000002065"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Patron (E27/GU10)",
      "power": "15W",
      "cct": "6000K",
      "voltage": "240V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aed10f0275f9adae2e4",
    "slug": "6a265aed10f0275f9adae2e4",
    "name": "Panel 96W 6500K Square White 595x595 CLEAR",
    "code": "A0000001803",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1h7_VaxX1Bgm7ho9pBWxpGz43u2M_JWdH&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1h7_VaxX1Bgm7ho9pBWxpGz43u2M_JWdH&sz=w800"
    ],
    "description": {
      "az": "Panel 96W 6500K Square White 595x595 CLEAR — Ecolife | Kod: A0000001803",
      "en": "Panel 96W 6500K Square White 595x595 CLEAR — Ecolife | Code: A0000001803",
      "ru": "Panel 96W 6500K Square White 595x595 CLEAR — Ecolife | Код: A0000001803"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "96W",
      "cct": "6500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a0ecdb4e26bee7614ca0ce2",
    "slug": "6a0ecdb4e26bee7614ca0ce2",
    "name": "ECL_ FMS/A12437_TP1746",
    "code": "A0000012437",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=19jI27fY63y_Qk1QhpO3-cZvhxL-vlTfR&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=19jI27fY63y_Qk1QhpO3-cZvhxL-vlTfR&sz=w800"
    ],
    "description": {
      "az": "ECL_ FMS/A12437_TP1746 — Ecolife | Kod: A0000012437",
      "en": "ECL_ FMS/A12437_TP1746 — Ecolife | Code: A0000012437",
      "ru": "ECL_ FMS/A12437_TP1746 — Ecolife | Код: A0000012437"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af31eb09635e5236f1a",
    "slug": "6a265af31eb09635e5236f1a",
    "name": "Panel 60W 3000K 595x595 Backlit",
    "code": "A0000016390",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1UI4yzw0S5b9wIsEOsyNza-1Afv38Bj2t&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1UI4yzw0S5b9wIsEOsyNza-1Afv38Bj2t&sz=w800"
    ],
    "description": {
      "az": "Panel 60W 3000K 595x595 Backlit — Ecolife | Kod: A0000016390",
      "en": "Panel 60W 3000K 595x595 Backlit — Ecolife | Code: A0000016390",
      "ru": "Panel 60W 3000K 595x595 Backlit — Ecolife | Код: A0000016390"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "60W",
      "cct": "3000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aedd8faacb4717746e1",
    "slug": "6a265aedd8faacb4717746e1",
    "name": "Panel 96W 4000K Square White 595x595 CLEAR",
    "code": "A0000001802",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1dL1UaEmiZ69_pqrlz8klWVrFyGkfXdXc&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1dL1UaEmiZ69_pqrlz8klWVrFyGkfXdXc&sz=w800"
    ],
    "description": {
      "az": "Panel 96W 4000K Square White 595x595 CLEAR — Ecolife | Kod: A0000001802",
      "en": "Panel 96W 4000K Square White 595x595 CLEAR — Ecolife | Code: A0000001802",
      "ru": "Panel 96W 4000K Square White 595x595 CLEAR — Ecolife | Код: A0000001802"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "96W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2659209828ee795cfd3fe7",
    "slug": "6a2659209828ee795cfd3fe7",
    "name": "Magnetic TrackLight 10W 4000K Hanging",
    "code": "A0000012483",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=197WK-_-HTCyXynatsaCF7E62AT-tKPfP&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=197WK-_-HTCyXynatsaCF7E62AT-tKPfP&sz=w800"
    ],
    "description": {
      "az": "Magnetic TrackLight 10W 4000K Hanging — Ecolife | Kod: A0000012483",
      "en": "Magnetic TrackLight 10W 4000K Hanging — Ecolife | Code: A0000012483",
      "ru": "Magnetic TrackLight 10W 4000K Hanging — Ecolife | Код: A0000012483"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə",
      "power": "10W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aeef95c251cad896182",
    "slug": "6a265aeef95c251cad896182",
    "name": "Panel 10W 4000K Round Sidelit",
    "code": "A0000001907",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1MKng3xBkyameHgojpaCZGoUJj0btrPgZ&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1MKng3xBkyameHgojpaCZGoUJj0btrPgZ&sz=w800"
    ],
    "description": {
      "az": "Panel 10W 4000K Round Sidelit — Ecolife | Kod: A0000001907",
      "en": "Panel 10W 4000K Round Sidelit — Ecolife | Code: A0000001907",
      "ru": "Panel 10W 4000K Round Sidelit — Ecolife | Код: A0000001907"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "10W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265af3d9ad1397aaa41f37",
    "slug": "6a265af3d9ad1397aaa41f37",
    "name": "Panel 60W 4000K 595x595 Backlit",
    "code": "A0000011725",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1JWauEN9mzBvooX7BCBbEikS09oVacMGS&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1JWauEN9mzBvooX7BCBbEikS09oVacMGS&sz=w800"
    ],
    "description": {
      "az": "Panel 60W 4000K 595x595 Backlit — Ecolife | Kod: A0000011725",
      "en": "Panel 60W 4000K 595x595 Backlit — Ecolife | Code: A0000011725",
      "ru": "Panel 60W 4000K 595x595 Backlit — Ecolife | Код: A0000011725"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "60W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a27ef1d495a8b3e0829717d",
    "slug": "6a27ef1d495a8b3e0829717d",
    "name": "Floodlight 200W 6500K 120lum/w PF>0.9 IP65",
    "code": "A0000003293",
    "category": "decorative",
    "categoryName": {
      "az": "Dekorativ",
      "en": "Decorative",
      "ru": "Декоративные"
    },
    "subtitle": {
      "az": "Dekorativ",
      "en": "Decorative",
      "ru": "Декоративные"
    },
    "image": "https://drive.google.com/thumbnail?id=1Z2vmXB1X74M505OpaVvmP7k14VSA9fcX&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Z2vmXB1X74M505OpaVvmP7k14VSA9fcX&sz=w800"
    ],
    "description": {
      "az": "Floodlight 200W 6500K 120lum/w PF>0.9 IP65 — Ecolife | Kod: A0000003293",
      "en": "Floodlight 200W 6500K 120lum/w PF>0.9 IP65 — Ecolife | Code: A0000003293",
      "ru": "Floodlight 200W 6500K 120lum/w PF>0.9 IP65 — Ecolife | Код: A0000003293"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP65",
      "mounting": "Səthə / Asma",
      "power": "200W",
      "cct": "6500K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fe951b7b10204698c4866",
    "slug": "6a2fe951b7b10204698c4866",
    "name": "Downlight 3xGU10 Square Black",
    "code": "A0000002271",
    "category": "track-systems",
    "categoryName": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "subtitle": {
      "az": "Trek Sistemləri",
      "en": "Track Systems",
      "ru": "Трековые системы"
    },
    "image": "https://drive.google.com/thumbnail?id=1J4REA4HHXmOeBcS6AzCHUT21uE6zNsKD&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1J4REA4HHXmOeBcS6AzCHUT21uE6zNsKD&sz=w800"
    ],
    "description": {
      "az": "Downlight 3xGU10 Square Black — Ecolife | Kod: A0000002271",
      "en": "Downlight 3xGU10 Square Black — Ecolife | Code: A0000002271",
      "ru": "Downlight 3xGU10 Square Black — Ecolife | Код: A0000002271"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Trek relsi üzərində"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2664fa083db85a7ef7a6f9",
    "slug": "6a2664fa083db85a7ef7a6f9",
    "name": "Ultra Magnetic PowerConnector 180°",
    "code": "A0000001676",
    "category": "recessed",
    "categoryName": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "subtitle": {
      "az": "Gömülmüş",
      "en": "Recessed",
      "ru": "Встраиваемые"
    },
    "image": "https://drive.google.com/thumbnail?id=1CEFIN1__dqFfgB52qsPz5P5YO0RqUuQN&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1CEFIN1__dqFfgB52qsPz5P5YO0RqUuQN&sz=w800"
    ],
    "description": {
      "az": "Ultra Magnetic PowerConnector 180° — Ecolife | Kod: A0000001676",
      "en": "Ultra Magnetic PowerConnector 180° — Ecolife | Code: A0000001676",
      "ru": "Ultra Magnetic PowerConnector 180° — Ecolife | Код: A0000001676"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Gömülmə"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f9336d4daaa910dbc55d9",
    "slug": "6a2f9336d4daaa910dbc55d9",
    "name": "Flexstrip OSRAM 24V 28W 3000K 96 pcs 6m 15mm",
    "code": "A0000000423",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1Qny9-Z27doU0tgAnJpcUtf21KZXBIA20&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Qny9-Z27doU0tgAnJpcUtf21KZXBIA20&sz=w800"
    ],
    "description": {
      "az": "Flexstrip OSRAM 24V 28W 3000K 96 pcs 6m 15mm — Ecolife | Kod: A0000000423",
      "en": "Flexstrip OSRAM 24V 28W 3000K 96 pcs 6m 15mm — Ecolife | Code: A0000000423",
      "ru": "Flexstrip OSRAM 24V 28W 3000K 96 pcs 6m 15mm — Ecolife | Код: A0000000423"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "28W",
      "cct": "3000K",
      "voltage": "24V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2fa73530428bc37b9de7f8",
    "slug": "6a2fa73530428bc37b9de7f8",
    "name": "PCB SR5 OSRAM 5050 5X2W 4000K SET REFLECTOR",
    "code": "A0000000444",
    "category": "pcb-boards",
    "categoryName": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "subtitle": {
      "az": "PCB Platalar",
      "en": "PCB Boards",
      "ru": "PCB платы"
    },
    "image": "https://drive.google.com/thumbnail?id=11h7790ss3e39aP7jzRA2DyqCemZ1HKKF&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=11h7790ss3e39aP7jzRA2DyqCemZ1HKKF&sz=w800"
    ],
    "description": {
      "az": "PCB SR5 OSRAM 5050 5X2W 4000K SET REFLECTOR — Ecolife | Kod: A0000000444",
      "en": "PCB SR5 OSRAM 5050 5X2W 4000K SET REFLECTOR — Ecolife | Code: A0000000444",
      "ru": "PCB SR5 OSRAM 5050 5X2W 4000K SET REFLECTOR — Ecolife | Код: A0000000444"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Modul quraşdırma",
      "power": "2W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a265aeec255bb74dd274b7e",
    "slug": "6a265aeec255bb74dd274b7e",
    "name": "Panel 6W 4000K Round Sidelit",
    "code": "A0000001909",
    "category": "surface-mounted",
    "categoryName": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "subtitle": {
      "az": "Səthi Quraşdırma",
      "en": "Surface Mounted",
      "ru": "Накладные"
    },
    "image": "https://drive.google.com/thumbnail?id=1mMClgQHoG2MsjxJftGbMLkTO8_2LKGpY&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1mMClgQHoG2MsjxJftGbMLkTO8_2LKGpY&sz=w800"
    ],
    "description": {
      "az": "Panel 6W 4000K Round Sidelit — Ecolife | Kod: A0000001909",
      "en": "Panel 6W 4000K Round Sidelit — Ecolife | Code: A0000001909",
      "ru": "Panel 6W 4000K Round Sidelit — Ecolife | Код: A0000001909"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Səthə",
      "power": "6W",
      "cct": "4000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2665201092400cdc6d4efd",
    "slug": "6a2665201092400cdc6d4efd",
    "name": "Led Tracklight 30W 6000K White YUCCA",
    "code": "A0000001613",
    "category": "pendants",
    "categoryName": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "subtitle": {
      "az": "Asma İşıqlar",
      "en": "Pendant Lights",
      "ru": "Подвесные светильники"
    },
    "image": "https://drive.google.com/thumbnail?id=1kQR3udG8J7kZGbPro1tf1M9AY0OSj6zP&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1kQR3udG8J7kZGbPro1tf1M9AY0OSj6zP&sz=w800"
    ],
    "description": {
      "az": "Led Tracklight 30W 6000K White YUCCA — Ecolife | Kod: A0000001613",
      "en": "Led Tracklight 30W 6000K White YUCCA — Ecolife | Code: A0000001613",
      "ru": "Led Tracklight 30W 6000K White YUCCA — Ecolife | Код: A0000001613"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Tavandan asma",
      "power": "30W",
      "cct": "6000K"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  },
  {
    "id": "6a2f93337d933b4b46775b7f",
    "slug": "6a2f93337d933b4b46775b7f",
    "name": "NEON COLORS 12V 7W",
    "code": "A0000011537",
    "category": "strip-lights",
    "categoryName": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "subtitle": {
      "az": "Lent İşıqlar",
      "en": "LED Strips",
      "ru": "Светодиодные ленты"
    },
    "image": "https://drive.google.com/thumbnail?id=1Gdrqa8ZLXAxoFAfwozJ2kZz_tcYpZa6Q&sz=w800",
    "gallery": [
      "https://drive.google.com/thumbnail?id=1Gdrqa8ZLXAxoFAfwozJ2kZz_tcYpZa6Q&sz=w800"
    ],
    "description": {
      "az": "NEON COLORS 12V 7W — Ecolife | Kod: A0000011537",
      "en": "NEON COLORS 12V 7W — Ecolife | Code: A0000011537",
      "ru": "NEON COLORS 12V 7W — Ecolife | Код: A0000011537"
    },
    "specs": {
      "material": "Alüminium",
      "dimensions": "Sifarişə uyğun",
      "ipRating": "IP20",
      "mounting": "Yapışqanlı lent",
      "power": "7W",
      "voltage": "12V"
    },
    "files": [],
    "featured": false,
    "isNew": true,
    "applications": [
      "Ofislər",
      "Evlər",
      "Kommersiya sahələri"
    ]
  }
];
